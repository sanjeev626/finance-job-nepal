<?php $this->load->view('includes/header');?>
<?php $this->load->helper("view_helper"); ?>


<?php $this->load->view($main);?>

<?php $this->load->view('includes/footer');?>

