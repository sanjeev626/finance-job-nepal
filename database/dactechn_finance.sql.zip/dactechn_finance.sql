-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 20, 2019 at 02:36 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dactechn_finance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin` varchar(50) NOT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin`, `pass`, `email`, `fullname`, `title`) VALUES
(1, 'admin', 'ex+LDv3rDn1HXumipiwNkcnprH8kBEUhrKwvm2bDZXE=', 'info@globaljob.com.np', 'Global Jobs', 'Global Jobs'),
(1, 'admin', 'ex+LDv3rDn1HXumipiwNkcnprH8kBEUhrKwvm2bDZXE=', 'info@globaljob.com.np', 'Global Jobs', 'Global Jobs');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE `advertisement` (
  `id` int(11) NOT NULL,
  `addtitle` varchar(150) DEFAULT NULL,
  `image` varchar(220) DEFAULT NULL,
  `addtype` enum('type1','type2') DEFAULT NULL,
  `addstatus` enum('publish','unpublish') DEFAULT NULL,
  `website` varchar(100) NOT NULL,
  `background_color` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertisement`
--

INSERT INTO `advertisement` (`id`, `addtitle`, `image`, `addtype`, `addstatus`, `website`, `background_color`) VALUES
(10, 'Vacancy at Audit Firm', NULL, NULL, 'publish', 'https://dac.technocreates.net/finance-job-nepal/category/banks-finance', '#4da0b3'),
(11, 'Jobs for CA', NULL, NULL, 'publish', 'https://dac.technocreates.net/finance-job-nepal/category/banks-finance', '#37c863'),
(12, 'Jobs for Semi Qualified CA', NULL, NULL, 'publish', '', '#ff0000'),
(13, 'Jobs for Accountant', NULL, NULL, 'publish', '', '#840000');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `jid` int(11) DEFAULT NULL,
  `eid` int(11) NOT NULL,
  `appdate` date NOT NULL,
  `status` enum('0','shortlisted','rejected') NOT NULL DEFAULT '0',
  `remarks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `articles` text,
  `cr_date` varchar(20) DEFAULT NULL,
  `up_date` varchar(20) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `stat` enum('Y','N') DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `articles` text COLLATE utf8_unicode_ci,
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cr_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `up_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stat` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `cat_id`, `slug`, `title`, `articles`, `image`, `cr_date`, `up_date`, `author`, `stat`) VALUES
(11, NULL, 'talent-acquisition-in-the-digital-age', 'Talent Acquisition in the Digital Age', '<p>Talent acquisition is changing, and HR must change with it. In the process, TA costs have jumped by significantly over the last few years according to Gartner.&nbsp; How does HR respond to the shifting balance of power as it moves away from the employer to the candidate?</p>\r\n<p><strong>Talent Acquisition</strong></p>\r\n<p>We must first understand this simple reality for candidates.&nbsp; According to&nbsp;<a href=\"https://www.gartner.com/smarterwithgartner/a-new-talent-acquisition-approach-for-the-digital-age/\">Gartner</a>, candidates feel:</p>\r\n<ul>\r\n<li>The wealth of available information, meant to increase transparency, is overloading candidates and making it hard for them to decide on a job offer.</li>\r\n<li>It has become so easy to apply for jobs that the number of applications per job has soared, so candidates have to wait longer to hear back from employers, if they hear back at all.</li>\r\n<li>Increased demand for talent spells greater opportunity, but that is causing candidates to increasingly regret their decisions to accept offers.</li>\r\n</ul>\r\n<p>As a result, Gartner said 46% of new hires from the last 12 months say they would take employment again with their current employer given the chance.&nbsp; Furthermore, the research giant said 38% of new hires regret their decision to leave their job within 12 months, compared to 7% who don&rsquo;t regret their decision.</p>\r\n<p>So, how do HR professionals recruit these candidates?&nbsp; According to Gartner:</p>\r\n<ul>\r\n<li>Build a messaging strategy that creates value for candidates &mdash; starting right from the messaging in&nbsp;<a href=\"https://www.gartner.com/smarterwithgartner/5-must-haves-in-your-job-description/\">job descriptions</a>.</li>\r\n<li>Surface signals of&nbsp;<a href=\"https://www.gartner.com/smarterwithgartner/rethink-screening-of-job-applicants-to-identify-serious-candidates/\">candidate commitment</a>earlier in the process</li>\r\n<li>Guide candidates to make&nbsp;<a href=\"https://www.gartner.com/smarterwithgartner/make-sure-new-hires-dont-regret-taking-your-job-offer/\">confident decisions</a>they won&rsquo;t regret.</li>\r\n</ul>\r\n<p>Bottom line here, candidate regret is dangerous.&nbsp; It leads to lower productivity and lower engagement.</p>\r\n<p>Of course, some of this could be construed as being related to the generational impact of the worker.&nbsp; For more details, HR Exchange Network Contributor John Whitaker talks about the &ldquo;Look Down&rdquo; generation.</p>\r\n<p>The \"Look Down\" Generation</p>\r\n<p>It literally drives me crazy...driving in the morning/evening commute every day is a stressful task without&nbsp;added annoyances, but there it is, every.....single.....day. After finally navigating your way around the human impediment&nbsp;clogging traffic for the last five&nbsp;miles, you look over at the driver and you see it. The \"<strong><em>look down.</em></strong>\"</p>\r\n<p>You know the look-down, right? Phone in lap,&nbsp;<a href=\"http://www.huffingtonpost.com/2015/06/08/dangers-of-texting-and-driving-statistics_n_7537710.html\">texting/dialing/syncing</a>/selecting music, etc.? The \"<em>I\'m not even pretending to pay attention dude, just leave me alone and let me sit here in the left lane until I\'m good and ready to move over three lanes and exit</em>?\" It\'s maddening (especially knowing the blare of my horns is drowned out by the Beats headphones they are sporting.)</p>\r\n<p>It\'s hard not to notice, and truthfully it\'s hard not be hypocritical about it - I\'m just as guilty of taking a glance, answering a text, or managing my&nbsp;incredibly counter-productive&nbsp;<a href=\"http://www.waze.com/\">Waze app</a>&nbsp;which basically dares me to update traffic conditions&nbsp;<em>while</em>&nbsp;I\'m driving. So dangerous, stupid, self-absorbed, yada yada yada...until we finally have \"MADAT\" (Mothers Against Dumb-A** Texters), this is the world in which we live. For Millennials and GenX, it\'s an ever developing, constantly growing challenge. And we should be buggy-whipped for being drawn into technological retardation.</p>\r\n<p>But for the&nbsp;<em>younger</em>&nbsp;generation, it\'s even more problematic. With a constant distraction monopolizing their limited attention span from the day on whence they breathed life into their lungs, I\'m convinced \"Generation Z\" (or whatever kitschy name we start marketing) have lost the innate ability to know what the hell is going on around them. I\'ve got a 15-year old son learning to drive - he can expertly perform the act of navigating a vehicle, but the kid&nbsp;<strong><em>literally</em></strong><em>&nbsp;</em>couldn\'t find his way home with bread crumbs and a compass. Try this with your own kids - after you arrive at whatever intended destination you intended, ask them if they can tell you how they got there. You\'ll be amazed.</p>\r\n<p>That\'s because my kids (and many of yours) been in a \"look down\" mode for the last ten years - they don\'t know North, South, street names, nuances of short-cuts, etc. They know the destination, but they are completely missing the journey. Our kids are going to be different in many ways ~ in particular, they will be more technologically adept than we ever dreamed of being, but they are (generalization alert) by and large missing the world and the people&nbsp;<em>around&nbsp;</em>them.</p>\r\n<p>And here\'s the rub - as much as we would like to deny we ever&nbsp;<a href=\"http://www.forbes.com/sites/lisaquast/2011/08/29/should-you-trust-your-gut-testing-your-decision-making-instincts/\">use our \"gut\" in talent selection</a>, we have innately spent a lifetime&nbsp;<em>observing&nbsp;</em>the&nbsp;world around us. Years spent people-watching in airports, in restaurants, in class, at the ballpark - the exact kind of activity my kids would find boring. The \"people watching\" past-time that many of us have employed for our entire existence actually had/has benefits - huzzah!!</p>\r\n<p>Hell, our kids may be right, it still seems boring. But \"boring\" doesn\'t necessarily need to be a negative. Sometimes it really is the seemingly insignificant details along the way that make us wiser.</p>\r\n<p>So keep your head up, kiddo. There\'s actually more going on around you than it seems.</p>\r\n<p>Source: <a href=\"https://www.hrexchangenetwork.com/hr-talent-aquisition/articles/talent-acquisition-in-the-digital-age\">https://www.hrexchangenetwork.com/hr-talent-aquisition/articles/talent-acquisition-in-the-digital-age</a></p>\r\n<p>&nbsp;</p>', '5865talent.jpg', '2019-09-15 04:55:05', '2019-09-15 04:55:05', NULL, 'Y'),
(3, NULL, 'the-role-of-human-resources-management-in-business', 'व्यवसायमा मानव संसाधन व्यवस्थापनको भूमिका', '<p style=\"text-align: justify;\">कुनै पनि व्यवसाय सञ्चालनमा मानव संसाधन व्यवस्थापनको अग्रणी भूमिका रहन्छ। कारण स्पष्ट छ&ndash;सबै मेशिन, उपकरण, प्रणाली, नीति नियम, कार्यविधि आदि दुरुस्त भए तापनि त्यसलाई सञ्चालन गर्ने मानव संसाधन कमजोर भयो भने ती सबै चीज व्यर्थ रहन्छ। मानव संसाधनको यति गहन भूमिका हुँदाहुँदै पनि हामी कर्मचारी भर्ना गर्दा जति होशियार हुनुपर्ने हो त्यति हुँदैनौं। कर्मचारी भर्ना गरिसकेपछि कर्मचारीले सन्तोषजनक परिणाम दिएन भने हामी त्यति सजिलै उसको सेवा रद्द गर्न पनि सक्दैनौं। झन् स्थायी नियुक्ति दिएपछि सेवाबाट हटाउने कुराको त हामी कल्पनासम्म गर्न सक्दैनौं। अर्थात् ऊ सेवानिवृत्त नहुन्जेल ऋणभार भइरहन्छ। यस्तो ऋणभार थपिंदै गयो भने कुनै पनि व्यवसाय अन्ततोगत्वा लोप हुन्छ।</p>\r\n<p style=\"text-align: justify;\">कर्मचारी भर्ना गर्दा केवल उसको शैक्षिक योग्यता तथा सीपलाई मात्र ध्यान दिने हाम्रो चलन छ। यसमा सुधार गर्नु अति आवश्यक छ। कारण ऊ पढाइमा, सीपमा जतिसुकै सक्षम भए पनि आचरण, अनुशासन, इमान्दारिता, मिलनसारिता आदि मानवीय गुणमा कमजोर भयो भने भर्नाको लागि ऊ अनुपयुक्त नै ठहरिन्छ। सीप कम भयो भने तालिम दिएर सीप अभिवृद्धि गर्न सकिन्छ। शिक्षा कम भयो भने पनि थप शिक्षा लिन अभिप्रेरित गर्न सकिन्छ। तर उपरोक्त मानवीय गुणमा नै खोट देखियो भने यस्तो खोट हटाउन गार्&zwj;हो नै पर्छ। मानवीय गुण भनेको ऊ हुर्केको परिवेश, सामाजिक वातावरण, स्कूल/कलेजको वातावरण आदिले प्रदान गर्ने हो। जुन बालबालिका अस्वस्थ वातावरणमा हुर्केका हुन्छन् उनीहरू वयस्क भएपछि समाजलाई बलभन्दा पनि भार नै हुन पुग्छन्। यस्तालाई केवल शिक्षा तथा सीपको आधारमा मात्र भर्ना गरियो भने परिणाम दु:खदायी नै हुन्छ।</p>\r\n<p style=\"text-align: justify;\">भर्ना गरिसकेपछि कर्मचारीको काम गर्ने जोश, जाँगरमा अभिवृद्धि गर्न अति आवश्यक छ। मनै त हो, जाँगर चल्यो भने कर्मचारीहरूले चमत्कारी ढङगले काम गरी असोचनीय परिणाम दिन्छन् भने हताश अवस्थामा मुश्किलले काम गर्छन् र ऋणात्मक नै परिणाम दिए पनि अचम्म मान्नुपर्ने अवस्था हुँदैन। कर्मचारीलाई काममा समर्पित गर्नु/गराउनु नै मानव संसाधन व्यवस्थापनको प्रमुख चुनौती हो। यो काम त्यति सरल छैन। त्यसको लागि मानवीय संवेदनाको ज्ञान अपरिहार्य हुन जान्छ। उसको व्यक्तिगत समस्या हुन्छ, पारिवारिक समस्या हुन्छ, जागिरमा अघि बढ्ने इच्छा आकाङ्क्षा हुन्छ। साथै उसले पाउने तलब सुविधा, उसको प्रतिभाको कदर, उसलाई काम देखाउने अवसर, उसको दक्षता अभिवृद्धिको अवसर आदि कुराले पनि उसको काम प्रतिको जोश, जाँगर र हौसलालाई प्रभाव पारेको हुन्छ। मानव भएको नाताले कर्मचारीहरू कहिले प्रशंसाको भोको हुन्छ भने कहिले दया, माया प्राप्त गर्नका लागि लालायित भएको हुन्छ। कर्मचारीको यी सबै अदृश्य पक्षलाई व्यवस्थित ढङगले सम्बोधन गर्दै गइयो भने मानव संसाधन व्यवस्थापन बलियो हुँदै जान्छ। परम्परागत सोच राखी करकापको भरमा मात्र काम गर्नु/गराउनु वर्तमान परिप्रेक्ष्यमा व्यवसायिकता ठहर्दैन र यसले सोचेको परिणाम पनि ल्याउँदैन।</p>\r\n<p style=\"text-align: justify;\">मानव संसाधन व्यवस्थापन बलियो हुँदै गयो भने आफू कार्यरत व्यावसायिक प्रतिष्ठानलाई कसरी ठोस योगदान दिने भन्ने भित्री इच्छा आफैं जागेर आउँछ। सबै कर्मचारीहरूबाट यस्तो सकारात्मक सन्देश प्रवाह भयो भने त कुनै पनि व्यवसाय मानव संसाधनको कारणले सुदृढ हुन जान्छ। तर यस्तो परिस्थितीको सृजना स्वत: हुँदैन। यसको लागि दक्ष व्यावसायिक व्यवस्थापनको अति खाचो पर्दछ। यस्तो व्यवस्थापनबाट मात्र केही आशा गर्न सकिन्छ। सबै कर्मचारीहरूको भित्री मन बुझी, उनीहरूको दक्षताको कदर गरी, उनीहरूमा परिणाममूलक काम गर्ने सोचको विकास गर्नु आजको समयको माग हो। सुखी कर्मचारीहरू नै उत्पादनमूलक कर्मचारी हुन्। के गर्दा उनीहरू खुशी र सुखी हुन्छन् ? यो प्रश्नलाई केन्द्रबिन्दु बनाई कर्मचारीहरूलाई उत्पादनमूलक बनाऔं र मानव संशाधन व्यवस्थापनलाई अन्य व्यवस्थापनको पक्षभन्दा बलियो बनाऔं।</p>\r\n<p style=\"text-align: justify;\">Source: <a href=\"http://www.prateekdaily.com/2011/04/blog-post_5786.html\">http://www.prateekdaily.com/2011/04/blog-post_5786.html</a>&nbsp;</p>', '3813shakehands.jpg', '2019-09-01 12:11:48', '2019-09-16 04:24:40', NULL, 'Y'),
(4, NULL, 'what-is-sexual-harassment-at-work', 'What is sexual harassment at work?', '<p style=\"text-align: justify;\"><strong>How to tell when lines are crossed in the workplace</strong></p>\r\n<p style=\"text-align: justify;\">Picture this - you&rsquo;ve just started a job as the manager of a new bar. You&rsquo;re understandably a bit anxious about being the new boss, but a senior colleague seems more than happy to show you the ropes, and you don&rsquo;t think anything of it &ndash; why should you?</p>\r\n<p style=\"text-align: justify;\">Then, slowly you notice this colleague behaving in a way that starts to make you feel a bit uncomfortable &ndash; a comment here, a slip of a hand there. But you shrug it off and focus on doing your job - maybe you misunderstood? Until one day, something happens, a line is crossed and you can&rsquo;t ignore it anymore.</p>\r\n<p style=\"text-align: justify;\">That is the situation that BBC Three&rsquo;s new social experiment &lsquo;Is This Sexual Harassment?&rsquo; seeks to explore. Presenter, Ben Zand, leads an on-screen discussion with a group of around 20 young people about where the line is when it comes to sexual harassment, based on the various scenarios from the drama.</p>\r\n<p style=\"text-align: justify;\">Is leaning over someone at work okay? What about complimenting their appearance? Is it ever okay to try to kiss your colleague? Where is the line?</p>\r\n<p style=\"text-align: justify;\">Without giving too much away, the programme shows that despite the impact of the #MeToo and #TimesUp campaigns, more awareness is needed about what exactly is sexual harassment in everyday work situations.</p>\r\n<p style=\"text-align: justify;\">We spoke to the barrister who features in the BBC documentary, Ceri Widdett, who specialises in employment law. She believes that there is a distinct &ldquo;lack of education around the issue\".</p>\r\n<p style=\"text-align: justify;\">&ldquo;We have got to get young men and women talking about [sexual harassment],\" she says. \"They really do not know where the line is.\"</p>\r\n<p style=\"text-align: justify;\">With that in mind, we\'ve created a quiz so you can test how much you really know about sexual harassment.</p>\r\n<p style=\"text-align: justify;\"><strong>But first, how does the law actually define it?</strong></p>\r\n<p style=\"text-align: justify;\">Sexual harassment is defined as unwanted behaviour of a sexual nature (aka something sexual, or related to your gender), which does any of the following:</p>\r\n<p style=\"text-align: justify;\"><strong>Violates your dignity</strong></p>\r\n<p style=\"text-align: justify;\">For some of us, the language &lsquo;your dignity&rsquo; might sound old fashioned and a little bit confusing. Having &lsquo;dignity&rsquo; basically means being worthy of respect - which legally we are all entitled to be. So if you&rsquo;re treated in a way that violates your dignity, it&rsquo;s another way of saying you were, and feel, disrespected. Therefore, in terms of sexual harassment, it means experiencing disrespect because of something sex-related at work.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">It\'s important to note that, whether or not unwanted sexual conduct violates a person&rsquo;s dignity or creates an offensive environment depends on the victim&rsquo;s perspective and whether their reaction is reasonable. What this basically means is that an independent party would think that the victim\'s response is the same as any other \'ordinary person\'s\'.</p>\r\n<p style=\"text-align: justify;\"><strong>Makes you feel intimidated, degraded or humiliated</strong></p>\r\n<p style=\"text-align: justify;\">These are feelings that most of us will be able to identify with in some form. But notice, as with the entirety of the definition of sexual assault, the language hinges on how the behaviour &lsquo;makes you feel&rsquo;, not how the person doing it intends to make you feel.</p>\r\n<p style=\"text-align: justify;\">It doesn&rsquo;t matter if you meant to sexually harass someone, or thought it was just &lsquo;banter&rsquo; - it can still be sexual harassment. Ceri told BBC Three that, &ldquo;In terms of the law, all we have to do is show the effect of it upon that individual, so it doesn&rsquo;t matter whether you intended it or not.\"</p>\r\n<p style=\"text-align: justify;\"><strong>Creates a hostile or offensive environment</strong></p>\r\n<p style=\"text-align: justify;\">Nobody wants to work in an environment where they feel uncomfortable, and if your behaviour of a sexual nature is making someone reasonably feel like that, then it&rsquo;s sexual harassment. If a victim is treated in a way that fits these categories because of their gender, or treated less favourably because they reject or submit to unwanted conduct of a sexual nature &ndash; that\'s sexual harassment. For example, if you were fired because you rejected a colleague coming on to you.</p>\r\n<p style=\"text-align: justify;\">Like with the rest of the definition, to class something as sexual harassment, the behaviour only has to fit into one of these categories, and not all of them.</p>\r\n<p style=\"text-align: justify;\"><strong>How do you know for sure if you\'ve experienced it?</strong></p>\r\n<p style=\"text-align: justify;\">Anyone can experience sexual harassment, regardless of gender or sexuality; the unwanted conduct could be from someone of the same or different sex.</p>\r\n<p style=\"text-align: justify;\">Sexual harassment commonly involves a pattern of inappropriate behaviour, repeated by someone in a workplace, that the victim has asked to stop but continues anyway. However, one-offs can be sexual harassment too, and it doesn\'t matter if someone else doesn\'t take something the same way as you do.</p>\r\n<p style=\"text-align: justify;\">Examples of sexual harassment at work can include sexual comments or jokes, unwelcome sexual advances or touching, suggestive looks, staring or leering, intrusive sexual questions, spreading sexual rumours, and sending emails or pictures of a sexual nature.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\"><strong>And who should you tell?</strong></p>\r\n<p style=\"text-align: justify;\">The difficulties in reporting sexual harassment at work are widely documented &ndash; as essentially your employer can be liable if your case is proven.</p>\r\n<p style=\"text-align: justify;\">Ceri\'s advice to anyone who thinks they might have experienced it is to tell someone you trust about what is happening and how it is making you feel, even if you\'re not ready to make a formal complaint.</p>\r\n<p style=\"text-align: justify;\">Your workplace&rsquo;s sexual harassment policy should make it clear who to make your complaint to, such as your employer, manager or HR department.</p>', '9546sexx.jpg', '2019-09-01 12:13:48', '2019-09-01 12:37:34', NULL, 'Y'),
(9, NULL, '3-reasons-your-organization-should-focus-on-the-employee-experience', '3 Reasons Your Organization Should Focus On the Employee Experience', '<p>Work is an fundamentally important part of our lives. It&rsquo;s important for businesses because work is what helps them achieve their goals, mission, vision, etc. Work is important for employees because they spend a significant portion of their time doing work. They need work to pay the bills and provide for their family.</p>\r\n<p>So, organizations need to spend some time thinking about how employees want to work. And try to deliver that kind of employee experience. Because candidates are going to apply and accept job offers from companies that offer the type of work that they feel they will enjoy.</p>\r\n<p>Don&rsquo;t misunderstand the word &ldquo;enjoy&rdquo; in the last sentence. We&rsquo;re not talking about something frivolous or silly. There are plenty of employers that offer what might be considered hard work and employees love working there because the employee value proposition (EVP) aligns with their work wants and needs.</p>\r\n<p>Given today&rsquo;s competitive recruiting landscape, organizations can&rsquo;t simply set and forget their EVP. Companies might want to make the commitment to regularly audit or conduct an EVP pulse check. In fact, it could make some sense to even publicly announce to employees that the company is committed to doing so.</p>\r\n<p>I remember working for a company that told employees they would annually benchmark compensation and benefits to ensure they were paying wages that were internally fair and externally competitive. Conducting the benchmarking activity didn&rsquo;t always result in changes, but the company was very open about their commitment.</p>\r\n<p>For companies that might be sitting on the fence about this idea, there are three primary reasons that organizations need to regularly examine their employee experience:</p>\r\n<ol>\r\n<li>It&rsquo;s the right thing to do. I do not believe any organization sets out to create a crappy work environment. Unfortunately, it sometimes happens over time. Making the commitment to offering an excellent employee experience is simply the right thing to do. That includes taking action when things go astray.</li>\r\n<li><strong>It helps deliver good customer service</strong>. It&rsquo;s very difficult for unhappy, stressed, burned out employees to deliver exceptional customer service. There&rsquo;s a lot of truth in the statement that &ldquo;happy employees deliver good customer service&rdquo;. Creating a positive work environment helps the customer relationship.</li>\r\n<li><strong>It resonates with customers</strong>. Speaking of customers, there&rsquo;s a trend that organizations need to pay attention to.&nbsp;<a href=\"https://www.hrbartender.com/2013/leadership-and-management/the-customer-now-decides-if-companies-treat-employees-fairly/\">Customers are making buying decisions</a>based on the perception they have about the company as an employer. Treat employees badly and your customers might decide to go to your competition.</li>\r\n</ol>\r\n<p>Work continues to be an important part of our lives, so how we do the work is an important part of the employee experience. And that&rsquo;s a key factor not only in the area of employee recruitment and retention but also from the company&rsquo;s bottom-line results.</p>\r\n<p>From: <a href=\"https://www.hrbartender.com/2019/employee-engagement/focus-employee-experience/\">https://www.hrbartender.com/2019/employee-engagement/focus-employee-experience/</a></p>', '2385happy-customers-1024x683.jpg', '2019-09-15 04:52:28', '2019-09-15 04:52:28', NULL, 'Y'),
(10, NULL, 'leaders-can-shape-company-culture-through-their-behaviors', 'Leaders Can Shape Company Culture Through Their Behaviors', '<p>Leaders Can Shape Company Culture Through Their Behaviors</p>\r\n<p>One business buzzword we hear almost everyday is &ldquo;culture,&rdquo; as in, our organization has a &ldquo;strong&rdquo; or &ldquo;innovative&rdquo; or even a &ldquo;toxic&rdquo; culture. But what do we really mean when we say this?</p>\r\n<p>For me, an organizational culture is defined by how people inside the organization interact with each other. Culture is learned behavior &mdash; it&rsquo;s not a by-product of operations. It&rsquo;s not an overlay. We create our organizational culture by the actions we take; not the other way around.</p>\r\n<p>For example, I sit on the board of United Airlines. At the start of every board meeting, the first topic of discussion is about where the fire exits are, how to access the stairs, and where we will meet up afterward. Why would we bother starting every meeting that way? Because United&rsquo;s culture is built on safety. And the best way to cultivate and reinforce that culture is to lead with behaviors and take actions that promote the importance of safety.</p>\r\n<p>Another element of United&rsquo;s culture is timeliness. I am a punctual person by nature, but I recall dialing in to one board meeting a few seconds late. The other participants started a few minutes before I joined. They saw a chance to start early, so they did.</p>\r\n<p>I share these stories as a way to show that how we behave as leaders drives the kind of culture we end up with. But this is also why changing an existing culture can be so difficult.</p>\r\n<p>This is a topic fellow executives ask me about a lot. It&rsquo;s not easy to change a culture, because it involves changing how we behave. If you&rsquo;re running a company that has been doing something a certain way for a long time, it can be hard to get everyone on board with doing it differently. And that includes your organizational leaders.</p>\r\n<p>Picture the following scenario. A group of executives decides that their organizational culture needs to become more &ldquo;customer focused.&rdquo; But when you look at the agenda of their meetings, there&rsquo;s no time devoted to discussing how they can improve their customers&rsquo; experience. And how much time do those executives actually spend out in the field, visiting customers, let alone fielding calls from them? If these executives prioritize something other than customers in their behavior, don&rsquo;t you think the rest of the organization will follow suit?</p>\r\n<p>It&rsquo;s easy to think that building a culture is about other people&rsquo;s behaviors, not how you act as a leader. But I believe that culture change begins when leaders start to model the behavior they want the organization to emulate.</p>\r\n<p>Case in point: A lot of executives come to me for advice about how they can build a more innovative culture, like the one we have at Red Hat. Well, it&rsquo;s not as simple as telling everyone to &ldquo;go out there and innovate!&rdquo;</p>\r\n<p>Our innovative culture is a product of the behaviors that we embrace throughout our organization. One of those elements is a willingness to have open and frank discussions about what separates great ideas from bad ones. If you want to be innovative, you also need to accept failure. If our associates aren&rsquo;t pushing boundaries and sometimes failing along the way, we probably aren&rsquo;t pushing hard enough. But by accepting and even celebrating a failed effort, we promote innovation. We will reward someone who tries to climb the tallest mountain, even if they fall short of the summit, because they have created an experience we can learn from and build upon. That&rsquo;s what innovation is all about.</p>\r\n<p>Consider an example from Amazon, one of the world&rsquo;s most valuable companies. Jeff Bezos, Amazon&rsquo;s founder and CEO, has said that if his people have a one-in-10 chance of making a 100x return on an investment, he wants them to make that bet every time. But that means that to reap the reward Amazon needs to be willing to tolerate someone failing nine out of 10 times.</p>\r\n<p>That can be a hard concept for traditionally run companies to wrap their heads around. They are used to measuring objective outcomes and results. They might think that failing is not something to celebrate; it&rsquo;s to be punished. So, why would anyone be surprised when innovation stalls as a result? After all, who would be willing to stick their neck out to try something new if there wasn&rsquo;t any upside to doing so?</p>\r\n<p>The point is that building an innovative culture starts by looking at how you behave as a leader toward those trying to innovate. The same is true about any kind of culture: It all begins with the behavior of your leaders. To say that another way, if you are interested in changing the culture of your organization, your first step should be to look in the mirror and make sure you are setting the kind of behavioral example you want everyone else to follow.</p>\r\n<p>Source: <a href=\"https://hbr.org/2016/10/leaders-can-shape-company-culture-through-their-behaviors\">https://hbr.org/2016/10/leaders-can-shape-company-culture-through-their-behaviors</a></p>\r\n<p>&nbsp;</p>', '4289leaders_can.jpg', '2019-09-15 04:53:56', '2019-09-15 04:53:56', NULL, 'Y');
INSERT INTO `blog` (`id`, `cat_id`, `slug`, `title`, `articles`, `image`, `cr_date`, `up_date`, `author`, `stat`) VALUES
(6, NULL, 'how-to-answer-the-31-most-common-interview-questions', 'How to Answer the 31 Most Common Interview Questions?', '<p style=\"text-align: justify;\">Wouldn\'t it be great if you knew exactly what questions a hiring manager would be asking you in your next job interview?</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">While we unfortunately can\'t read minds, we\'ll give you the next best thing: a list of the 31 most commonly asked interview questions and answers.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">While we don\'t recommend having a canned response for every interview question (in fact, please don\'t), we do recommend spending some time getting comfortable with what you might be asked, what hiring managers are really looking for in your responses, and what it takes to show that you\'re the right man or woman for the job.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Consider this list your interview question study guide.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\">\r\n<li><strong> Can you tell me a little about yourself?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">This question seems simple, so many people fail to prepare for it, but it\'s crucial. Here\'s the deal: Don\'t give your complete employment (or personal) history. Instead give a pitch&mdash;one that&rsquo;s concise and compelling and that shows exactly why you&rsquo;re the right fit for the job. Start off with the 2-3 specific accomplishments or experiences that you most want the interviewer to know about, then wrap up talking about how that prior experience has positioned you for this specific role.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"2\">\r\n<li><strong> How did you hear about the position?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Another seemingly innocuous interview question, this is actually a perfect opportunity to stand out and show your passion for and connection to the company. For example, if you found out about the gig through a friend or professional contact, name drop that person, then share why you were so excited about it. If you discovered the company through an event or article, share that. Even if you found the listing through a random job board, share what, specifically, caught your eye about the role.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"3\">\r\n<li><strong> What do you know about the company?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Any candidate can read and regurgitate the company&rsquo;s &ldquo;About&rdquo; page. So, when interviewers ask this, they aren\'t necessarily trying to gauge whether you understand the mission&mdash;they want to know whether you care about it. Start with one line that shows you understand the company\'s goals, using a couple key words and phrases from the website, but then go on to make it personal. Say, &ldquo;I&rsquo;m personally drawn to this mission because&hellip;&rdquo; or &ldquo;I really believe in this approach because&hellip;&rdquo; and share a personal example or two.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"4\">\r\n<li><strong> Why do you want this job?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Again, companies want to hire people who are passionate about the job, so you should have a great answer about why you want the position. (And if you don\'t? You probably should apply elsewhere.) First, identify a couple of key factors that make the role a great fit for you (e.g., &ldquo;I love customer support because I love the constant human interaction and the satisfaction that comes from helping someone solve a problem\"), then share why you love the company (e.g., &ldquo;I&rsquo;ve always been passionate about education, and I think you guys are doing great things, so I want to be a part of it&rdquo;).</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"5\">\r\n<li><strong> Why should we hire you?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">This interview question seems forward (not to mention intimidating!), but if you\'re asked it, you\'re in luck: There\'s no better setup for you to sell yourself and your skills to the hiring manager. Your job here is to craft an answer that covers three things: that you can not only do the work, you can deliver great results; that you\'ll really fit in with the team and culture; and that you\'d be a better hire than any of the other candidates.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"6\">\r\n<li><strong> What are your greatest professional strengths?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">When answering this question, interview coach Pamela Skillings recommends being accurate (share your true strengths, not those you think the interviewer wants to hear); relevant (choose your strengths that are most targeted to this particular position); and specific (for example, instead of &ldquo;people skills,&rdquo; choose &ldquo;persuasive communication&rdquo; or &ldquo;relationship building&rdquo;). Then, follow up with an example of how you\'ve demonstrated these traits in a professional setting.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"7\">\r\n<li><strong> What do you consider to be your weaknesses?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">What your interviewer is really trying to do with this question&mdash;beyond identifying any major red flags&mdash;is to gauge your self-awareness and honesty. So, &ldquo;I can\'t meet a deadline to save my life&rdquo; is not an option&mdash;but neither is &ldquo;Nothing! I\'m perfect!&rdquo; Strike a balance by thinking of something that you struggle with but that you&rsquo;re working to improve. For example, maybe you&rsquo;ve never been strong at public speaking, but you\'ve recently volunteered to run meetings to help you be more comfortable when addressing a crowd.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"8\">\r\n<li><strong> What is your greatest professional achievement?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Nothing says &ldquo;hire me&rdquo; better than a track record of achieving amazing results in past jobs, so don\'t be shy when answering this interview question! A great way to do so is by using the S-T-A-R method: Set up the situation and the task that you were required to complete to provide the interviewer with background context (e.g., &ldquo;In my last job as a junior analyst, it was my role to manage the invoicing process&rdquo;), but spend the bulk of your time describing what you actually did (the action) and what you achieved (the result). For example, &ldquo;In one month, I streamlined the process, which saved my group 10 man-hours each month and reduced errors on invoices by 25%.&rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"9\">\r\n<li><strong> Tell me about a challenge or conflict you\'ve faced at work, and how you dealt with it.</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">In asking this behavioral interview question, &ldquo;your interviewer wants to get a sense of how you will respond to conflict. Anyone can seem nice and pleasant in a job interview, but what will happen if you&rsquo;re hired and Gladys in Compliance starts getting in your face?&rdquo; says Skillings. Again, you\'ll want to use the S-T-A-R method, being sure to focus on how you handled the situation professionally and productively, and ideally closing with a happy ending, like how you came to a resolution or compromise.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"10\">\r\n<li><strong> Where do you see yourself in five years?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">If asked this question, be honest and specific about your future goals, but consider this: A hiring manager wants to know a) if you\'ve set realistic expectations for your career, b) if you have ambition (a.k.a., this interview isn\'t the first time you\'re considering the question), and c) if the position aligns with your goals and growth. Your best bet is to think realistically about where this position could take you and answer along those lines. And if the position isn&rsquo;t necessarily a one-way ticket to your aspirations? It&rsquo;s OK to say that you&rsquo;re not quite sure what the future holds, but that you see this experience playing an important role in helping you make that decision.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"11\">\r\n<li><strong> What\'s your dream job?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Along similar lines, the interviewer wants to uncover whether this position is really in line with your ultimate career goals. While &ldquo;an NBA star&rdquo; might get you a few laughs, a better bet is to talk about your goals and ambitions&mdash;and why this job will get you closer to them.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"12\">\r\n<li><strong> What other companies are you interviewing with?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Companies ask this for a number of reasons, from wanting to see what the competition is for you to sniffing out whether you\'re serious about the industry. &ldquo;Often the best approach is to mention that you are exploring a number of other similar options in the company\'s industry,&rdquo; says job search expert Alison Doyle. &ldquo;It can be helpful to mention that a common characteristic of all the jobs you are applying to is the opportunity to apply some critical abilities and skills that you possess. For example, you might say \'I am applying for several positions with IT consulting firms where I can analyze client needs and translate them to development teams in order to find solutions to technology problems.\'&rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"13\">\r\n<li><strong> Why are you leaving your current job?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">This is a toughie, but one you can be sure you\'ll be asked. Definitely keep things positive&mdash;you have nothing to gain by being negative about your past employers. Instead, frame things in a way that shows that you\'re eager to take on new opportunities and that the role you&rsquo;re interviewing for is a better fit for you than your current or last position. For example, &ldquo;I&rsquo;d really love to be part of product development from beginning to end, and I know I&rsquo;d have that opportunity here.&rdquo; And if you were let go? Keep it simple: &ldquo;Unfortunately, I was let go,&rdquo; is a totally OK answer.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"14\">\r\n<li><strong> Why were you fired?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">OK, if you get the admittedly much tougher follow-up question as to why you were let go (and the truth isn\'t exactly pretty), your best bet is to be honest (the job-seeking world is small, after all). But it doesn\'t have to be a deal-breaker. Share how you&rsquo;ve grown and how you approach your job and life now as a result. If you can position the learning experience as an advantage for this next job, even better.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"15\">\r\n<li><strong> What are you looking for in a new position?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Hint: Ideally the same things that this position has to offer. Be specific.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"16\">\r\n<li><strong> What type of work environment do you prefer?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Hint: Ideally one that\'s similar to the environment of the company you\'re applying to. Be specific.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"17\">\r\n<li><strong> What\'s your management style?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">The best managers are strong but flexible, and that\'s exactly what you want to show off in your answer. (Think something like, &ldquo;While every situation and every team member requires a bit of a different strategy, I tend to approach my employee relationships as a coach...&rdquo;) Then, share a couple of your best managerial moments, like when you grew your team from five to 15 or coached an underperforming employee to become the company\'s top salesperson.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"18\">\r\n<li><strong> What\'s a time you exercised leadership?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Depending on what\'s more important for the the role, you\'ll want to choose an example that showcases your project management skills (spearheading a project from end to end, juggling multiple moving parts) or one that shows your ability to confidently and effectively rally a team. And remember: &ldquo;The best stories include enough detail to be believable and memorable,&rdquo; says Skillings. &ldquo;Show how you were a leader in this situation and how it represents your overall leadership experience and potential.&rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"19\">\r\n<li><strong> What\'s a time you disagreed with a decision that was made at work?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Everyone disagrees with the boss from time to time, but in asking this interview question, hiring managers want to know that you can do so in a productive, professional way. &ldquo;You don&rsquo;t want to tell the story about the time when you disagreed but your boss was being a jerk and you just gave in to keep the peace. And you don&rsquo;t want to tell the one where you realized you were wrong,&rdquo; says Peggy McKee of Career Confidential. &ldquo;Tell the one where your actions made a positive difference on the outcome of the situation, whether it was a work-related outcome or a more effective and productive working relationship.&rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"20\">\r\n<li><strong> How would your boss and co-workers describe you?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">First of all, be honest (remember, if you get this job, the hiring manager will be calling your former bosses and co-workers!). Then, try to pull out strengths and traits you haven\'t discussed in other aspects of the interview, such as your strong work ethic or your willingness to pitch in on other projects when needed.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"21\">\r\n<li><strong> Why was there a gap in your employment?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">If you were unemployed for a period of time, be direct and to the point about what you&rsquo;ve been up to (and hopefully, that&rsquo;s a litany of impressive volunteer and other mind-enriching activities, like blogging or taking classes). Then, steer the conversation toward how you will do the job and contribute to the organization: &ldquo;I decided to take a break at the time, but today I&rsquo;m ready to contribute to this organization in the following ways.&rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"22\">\r\n<li><strong> Can you explain why you changed career paths?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Don\'t be thrown off by this question&mdash;just take a deep breath and explain to the hiring manager why you\'ve made the career decisions you have. More importantly, give a few examples of how your past experience is transferrable to the new role. This doesn\'t have to be a direct connection; in fact, it\'s often more impressive when a candidate can make seemingly irrelevant experience seem very relevant to the role.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"23\">\r\n<li><strong> How do you deal with pressure or stressful situations?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">\"Choose an answer that shows that you can meet a stressful situation head-on in a productive, positive manner and let nothing stop you from accomplishing your goals,\" says McKee. A great approach is to talk through your go-to stress-reduction tactics (making the world\'s greatest to-do list, stopping to take 10 deep breaths), and then share an example of a stressful situation you navigated with ease.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"24\">\r\n<li><strong> What would your first 30, 60, or 90 days look like in this role?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Start by explaining what you\'d need to do to get ramped up. What information would you need? What parts of the company would you need to familiarize yourself with? What other employees would you want to sit down with? Next, choose a couple of areas where you think you can make meaningful contributions right away. (e.g., &ldquo;I think a great starter project would be diving into your email marketing campaigns and setting up a tracking system for them.&rdquo;) Sure, if you get the job, you (or your new employer) might decide there&rsquo;s a better starting place, but having an answer prepared will show the interviewer where you can add immediate impact&mdash;and that you&rsquo;re excited to get started.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"25\">\r\n<li><strong> What are your salary requirements?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">The #1 rule of answering this question is doing your research on what you should be paid by using sites like Payscale and Glassdoor. You&rsquo;ll likely come up with a range, and we recommend stating the highest number in that range that applies, based on your experience, education, and skills. Then, make sure the hiring manager knows that you\'re flexible. You\'re communicating that you know your skills are valuable, but that you want the job and are willing to negotiate.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"26\">\r\n<li><strong> What do you like to do outside of work?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Interviewers ask personal questions in an interview to &ldquo;see if candidates will fit in with the culture [and] give them the opportunity to open up and display their personality, too,&rdquo; says longtime hiring manager Mitch Fortner. &ldquo;In other words, if someone asks about your hobbies outside of work, it&rsquo;s totally OK to open up and share what really makes you tick. (Do keep it semi-professional, though: Saying you like to have a few beers at the local hot spot on Saturday night is fine. Telling them that Monday is usually a rough day for you because you&rsquo;re always hungover is not.)&rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"27\">\r\n<li><strong> If you were an animal, which one would you want to be?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Seemingly random personality-test type questions like these come up in interviews generally because hiring managers want to see how you can think on your feet. There\'s no wrong answer here, but you\'ll immediately gain bonus points if your answer helps you share your strengths or personality or connect with the hiring manager. Pro tip: Come up with a stalling tactic to buy yourself some thinking time, such as saying, &ldquo;Now, that is a great question. I think I would have to say&hellip; &rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"28\">\r\n<li><strong> How many tennis balls can you fit into a limousine?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">1,000? 10,000? 100,000? Seriously?</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Well, seriously, you might get asked brainteaser questions like these, especially in quantitative jobs. But remember that the interviewer doesn&rsquo;t necessarily want an exact number&mdash;he wants to make sure that you understand what&rsquo;s being asked of you, and that you can set into motion a systematic and logical way to respond. So, just take a deep breath, and start thinking through the math. (Yes, it&rsquo;s OK to ask for a pen and paper!)</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"29\">\r\n<li><strong> Are you planning on having children?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Questions about your family status, gender (&ldquo;How would you handle managing a team of all men?&rdquo;), nationality (&ldquo;Where were you born?&rdquo;), religion, or age, are illegal&mdash;but they still get asked (and frequently). Of course, not always with ill intent&mdash;the interviewer might just be trying to make conversation&mdash;but you should definitely tie any questions about your personal life (or anything else you think might be inappropriate) back to the job at hand. For this question, think: &ldquo;You know, I&rsquo;m not quite there yet. But I am very interested in the career paths at your company. Can you tell me more about that?&rdquo;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"30\">\r\n<li><strong> What do you think we could do better or differently?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">This is a common one at startups (and one of our personal favorites here at The Muse). Hiring managers want to know that you not only have some background on the company, but that you\'re able to think critically about it and come to the table with new ideas. So, come with new ideas! What new features would you love to see? How could the company increase conversions? How could customer service be improved? You don&rsquo;t need to have the company&rsquo;s four-year strategy figured out, but do share your thoughts, and more importantly, show how your interests and expertise would lend themselves to the job.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"31\">\r\n<li><strong> Do you have any questions for us?</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">You probably already know that an interview isn\'t just a chance for a hiring manager to grill you&mdash;it\'s your opportunity to sniff out whether a job is the right fit for you. What do you want to know about the position? The company? The department? The team?</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">You\'ll cover a lot of this in the actual interview, so have a few less-common questions ready to go. We especially like questions targeted to the interviewer (&ldquo;What\'s your favorite part about working here?\") or the company\'s growth (&ldquo;What can you tell me about your new products or plans for growth?\")</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Source: <a href=\"https://www.themuse.com/advice/how-to-answer-the-31-most-common-interview-questions\">https://www.themuse.com/advice/how-to-answer-the-31-most-common-interview-questions</a></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>', '1836candidate-tips-2-e1540551321919.jpg', '2019-09-01 12:18:04', '2019-09-01 12:46:53', NULL, 'Y'),
(7, NULL, '9-things-managers-do-that-make-good-employees-quit', '9 Things Managers Do That Make Good Employees QUIT !', '<p style=\"text-align: justify;\">It&rsquo;s pretty incredible how often you hear managers complaining about their best employees leaving, and they really do have something to complain about&mdash;few things are as costly and disruptive as good people walking out the door.</p>\r\n<p style=\"text-align: justify;\">Managers tend to blame their turnover problems on everything under the sun, while ignoring the crux of the matter: people don&rsquo;t leave jobs; they leave managers.</p>\r\n<p style=\"text-align: justify;\">The sad thing is that this can easily be avoided. All that&rsquo;s required is a new perspective and some extra effort on the manager&rsquo;s part.</p>\r\n<p style=\"text-align: justify;\">First, we need to understand the nine worst things that managers do that send good people packing.</p>\r\n<ol style=\"text-align: justify;\">\r\n<li><strong> They Overwork People</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Nothing burns good employees out quite like overworking them. It&rsquo;s so tempting to work your best people hard that managers frequently fall into this trap. Overworking good employees is perplexing; it makes them feel as if they&rsquo;re being punished for great performance. Overworking employees is also counterproductive. New research from Stanford shows that productivity per hour declines sharply when the workweek exceeds 50 hours, and productivity drops off so much after 55 hours that you don&rsquo;t get anything out of working more.</p>\r\n<p style=\"text-align: justify;\">If you must increase how much work your talented employees are doing, you&rsquo;d better increase their status as well. Talented employees will take on a bigger workload, but they won&rsquo;t stay if their job suffocates them in the process. Raises, promotions, and title-changes are all acceptable ways to increase workload. If you simply increase workload because people are talented, without changing a thing, they will seek another job that gives them what they deserve.</p>\r\n<ol style=\"text-align: justify;\" start=\"2\">\r\n<li><strong> They Don&rsquo;t Recognize Contributions and Reward Good Work</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">It&rsquo;s easy to underestimate the power of a pat on the back, especially with top performers who are intrinsically motivated. Everyone likes kudos, none more so than those who work hard and give their all. Managers need to communicate with their people to find out what makes them feel good (for some, it&rsquo;s a raise; for others, it&rsquo;s public recognition) and then to reward them for a job well done. With top performers, this will happen often if you&rsquo;re doing it right.</p>\r\n<ol style=\"text-align: justify;\" start=\"3\">\r\n<li><strong> They Don&rsquo;t Care about Their Employees</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">More than half of people who leave their jobs do so because of their relationship with their boss. Smart companies make certain their managers know how to balance being professional with being human. These are the bosses who celebrate an employee&rsquo;s success, empathize with those going through hard times, and challenge people, even when it hurts. Bosses who fail to really care will always have high turnover rates. It&rsquo;s impossible to work for someone eight-plus hours a day when they aren&rsquo;t personally involved and don&rsquo;t care about anything other than your production yield.</p>\r\n<ol style=\"text-align: justify;\" start=\"4\">\r\n<li>They Don&rsquo;t Honor Their Commitments</li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Making promises to people places you on the fine line that lies between making them very happy and watching them walk out the door. When you uphold a commitment, you grow in the eyes of your employees because you prove yourself to be trustworthy and honorable (two very important qualities in a boss). But when you disregard your commitment, you come across as slimy, uncaring, and disrespectful. After all, if the boss doesn&rsquo;t honor his or her commitments, why should everyone else?</p>\r\n<ol style=\"text-align: justify;\" start=\"5\">\r\n<li><strong> They Hire and Promote the Wrong People</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Good, hard-working employees want to work with like-minded professionals. When managers don&rsquo;t do the hard work of hiring good people, it&rsquo;s a major demotivator for those stuck working alongside them. Promoting the wrong people is even worse. When you work your tail off only to get passed over for a promotion that&rsquo;s given to someone who glad-handed their way to the top&shy;&shy;&shy;&shy;&shy;&shy;&shy;, it&rsquo;s a massive insult. No wonder it makes good people leave.</p>\r\n<ol style=\"text-align: justify;\" start=\"6\">\r\n<li><strong> They Don&rsquo;t Let People Pursue Their Passions</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Talented employees are passionate. Providing opportunities for them to pursue their passions improves their productivity and job satisfaction. But many managers want people to work within a little box. These managers fear that productivity will decline if they let people expand their focus and pursue their passions. This fear is unfounded. Studies show that people who are able to pursue their passions at work experience flow, a euphoric state of mind that is five times more productive than the norm.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"7\">\r\n<li><strong> They Fail to Develop People&rsquo;s Skills</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">When managers are asked about their inattention to employees, they try to excuse themselves, using words such as &ldquo;trust,&rdquo; &ldquo;autonomy,&rdquo; and &ldquo;empowerment.&rdquo; This is complete nonsense. Good managers manage, no matter how talented the employee. They pay attention and are constantly listening and giving feedback.</p>\r\n<p style=\"text-align: justify;\">Management may have a beginning, but it certainly has no end. When you have a talented employee, it&rsquo;s up to you to keep finding areas in which they can improve to expand their skill set. The most talented employees want feedback&mdash;more so than the less talented ones&mdash;and it&rsquo;s your job to keep it coming. If you don&rsquo;t, your best people will grow bored and complacent.</p>\r\n<ol style=\"text-align: justify;\" start=\"8\">\r\n<li><strong> They Fail to Engage Their Creativity</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">The most talented employees seek to improve everything they touch. If you take away their ability to change and improve things because you&rsquo;re only comfortable with the status quo, this makes them hate their jobs. Caging up this innate desire to create not only limits them, it limits you.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<ol style=\"text-align: justify;\" start=\"9\">\r\n<li><strong> They Fail to Challenge People Intellectually</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Great bosses challenge their employees to accomplish things that seem inconceivable at first. Instead of setting mundane, incremental goals, they set lofty goals that push people out of their comfort zones. Then, good managers do everything in their power to help them succeed. When talented and intelligent people find themselves doing things that are too easy or boring, they seek other jobs that will challenge their intellects.</p>\r\n<p style=\"text-align: justify;\"><strong>Bringing It All Together</strong></p>\r\n<p style=\"text-align: justify;\">If you want your best people to stay, you need to think carefully about how you treat them. While good employees are as tough as nails, their talent gives them an abundance of options. You need to make them want to work for you.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Source: <a href=\"https://www.huffpost.com/entry/9-things-that-make-good-e_b_8870074\">https://www.huffpost.com/entry/9-things-that-make-good-e_b_8870074</a></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>', '5546reasons-quitting-job-800x800.jpg', '2019-09-01 12:19:42', '2019-09-11 05:58:35', NULL, 'Y'),
(8, NULL, '6-soft-skills-accounting-and-finance-candidates-should-have', '6 Soft Skills Accounting and Finance Candidates Should Have', '<p style=\"text-align: justify;\">When you\'re looking to staff accounting and finance jobs at your firm, you search for candidates with the necessary education and certifications. That\'s to be expected. But degrees, diplomas and designations aren\'t everything. Your ideal hire will need great interpersonal skills and some general knowledge about the business world, too.</p>\r\n<p style=\"text-align: justify;\">In making your decision, look for accounting and finance professionals who possess these six soft skills:</p>\r\n<ol style=\"text-align: justify;\">\r\n<li><strong> Business knowledge</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">The scope of accounting and finance jobs is expanding. Candidates need astute business understanding if they are to successfully help develop strategy, inform key decisions and work on&nbsp;<a href=\"https://www.roberthalf.com/blog/salaries-and-skills/confronting-the-challenges-of-cross-departmental-collaboration\">cross-departmental collaboration</a>&nbsp;within your organization. They should be able to see the big picture and understand how their job impacts the company as a whole.</p>\r\n<ol style=\"text-align: justify;\" start=\"2\">\r\n<li><strong> Leadership capabilities</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">When you hire for accounting and finance jobs, look for professionals with strong&nbsp;<a href=\"https://www.roberthalf.com/blog/salaries-and-skills/5-tips-for-building-your-leadership-skills\">leadership skills</a>, who can step into more senior roles when the time is right. Look for ambitious self-starters who adapts well to change and embraces continuous learning and personal development. During the interview, assess whether a candidate is likely to be able to share new insights, generate fresh ideas, and motivate, engage and eventually mentor other members of your team.</p>\r\n<p style=\"text-align: justify;\">You can identify these qualities by asking open-ended questions. Inquire about how candidates have worked with others or times when they led project teams.</p>\r\n<p style=\"text-align: justify;\"><strong><em>Ready to hire? Use&nbsp;</em></strong><a href=\"https://www.roberthalf.com/browse-candidates\"><strong><em>Robert Half&rsquo;s candidate finder</em></strong></a><strong><em>.</em></strong></p>\r\n<ol style=\"text-align: justify;\" start=\"3\">\r\n<li><strong> Technical prowess</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Accounting and finance jobs often require strong skills in&nbsp;<a href=\"https://www.roberthalf.com/blog/salaries-and-skills/ima-president-risks-opportunities-in-accounting-technology\">accounting technology</a>. Proficiency using finance-specific software programs, such as Hyperion and QuickBooks, is a prerequisite in most cases. Cloud computing is also becoming increasingly popular at many companies. Look for accounting and finance professionals who are proficient in the latest database applications and enterprise resource planning (ERP) programs. </p>\r\n<ol style=\"text-align: justify;\" start=\"4\">\r\n<li><strong> Communication skills</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Accounting and finance staff need to be able to tell the story behind the numbers in an easy-to-digest manner. This is particularly true when it comes to informing colleagues in other departments or clients who may be unfamiliar with accounting principles and jargon. For this reason, written, verbal and even visual communication skills are critical for success in accounting and finance jobs today. </p>\r\n<ol style=\"text-align: justify;\" start=\"5\">\r\n<li><strong> Customer service orientation</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">\"How can I help you?\" is a phrase that should never be far from the minds of accounting and finance professionals. It\'s essential for staff at most organizations to be able to retain current customers, bring in new clients or, at the very least, keep internal customers happy &mdash; making solid customer service skills important.</p>\r\n<ol style=\"text-align: justify;\" start=\"6\">\r\n<li><strong> The best of the rest</strong></li>\r\n</ol>\r\n<p style=\"text-align: justify;\">Nearly all postings for finance and accounting jobs today include these abilities on their list of requirements:</p>\r\n<ul style=\"text-align: justify;\">\r\n<li>Planning and organizational abilities</li>\r\n<li>Multitasking</li>\r\n<li>Analytical and problem-solving skills</li>\r\n<li>The capacity to work without supervision and under pressure</li>\r\n<li>The ability to work well in teams and independently</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">Certainly, for accounting and finance professionals who manage company funds, qualities such as attention to detail, accuracy, and a highly developed sense of discretion and confidentiality are indispensable. For your own particular workplace, other qualities such as a sense of humor may be priorities.</p>\r\n<p style=\"text-align: justify;\">Be clear before you start the interviewing process about the&nbsp;<a href=\"https://www.roberthalf.com/blog/evaluating-job-candidates/spot-the-right-soft-skills-before-you-make-the-job-offer\">right soft skills</a>&nbsp;for your workplace, and you\'ll be more likely to end up hiring the right person for the job.</p>', '562170610951_23843810526890041_765104301583368192_n_png.jpg', '2019-09-01 12:21:13', '2019-09-12 05:09:00', NULL, 'Y'),
(12, NULL, 'talent-matters-to-all-stakeholders', 'Talent Matters to All Stakeholders', '<p>There is no question that talent matters to an organization&rsquo;s success. Talent (workforce, people, competence, skills) has been the bailiwick for HR, captured in the maxim, &ldquo;war for talent.&rdquo; This talent emphasis has led to innumerable innovations in how firms bring people into the organization, move them through the organization, and appropriately move them out of the organization.</p>\r\n<p>Today general managers and HR professionals need to help their organizations move beyond fighting the talent war to winning it. Winning talent wars requires creating great organizations, but it also requires a clarity about managing talent with a focus on outcomes that deliver value to the right recipients. For example, it is not enough to build on strengths, but individuals must use strengths to strengthen others. Measuring the amount of training or staffing is not enough; one must measure the impact of training or staffing on key organization outcomes.&nbsp; Competencies matter to the extent that they affect key business outcomes.</p>\r\n<p>The primary stakeholders for talent outcomes have traditionally been inside the organization; investments in talent resulted in greater employee productivity and well-being as well as organization strategic success. Going forward, the value of talent will also come from how talent choices affect those outside the organization, not just inside. Let me suggest three emerging stakeholders to focus on in shifting talent from being primarily an internal activity to one that provides valued outcomes outside the organization.</p>\r\n<p><strong>Talent Matters</strong></p>\r\n<p>Talent matters to boards of directors. In a recent meeting of the National Academy of Corporate Directors conference, a group proposed that the compensation committee of the board be expanded and changed to become the talent, leadership, and culture committee. This committee would have a charter to evaluate not only the organization&rsquo;s compensation practices but its processes around leadership, succession, talent review, culture, and talent risk management as well. A broader &ldquo;talent&rdquo; mandate at the board level signals its importance to business leaders throughout an organization.</p>\r\n<p>Talent matters to customers. In the past few years, we have argued that leaders are most effective when their behaviors reflect customer promises. When a firm brand translates to a leadership brand, leaders create more value for targeted customers as well as employees. The essence of a customer focus is that employee sentiment is a lead indicator of customer sentiment. We know that employee engagement (however measured) is a lead indicator of customer engagement. For example, customer net promoter scores are highly correlated with employee commitment scores. Employees should focus on delighting customers and developing the skills that customers value.</p>\r\n<p>Talent matters to investors. Many investors are increasingly looking to predict and capture long-term value from a company. To do so requires looking beyond financial results (e.g., earnings, EBIDTA) to intangibles (like strategy, brand, technology, and systems) and talent, leadership, and culture. In our research, we found that about 35 to 40 percent of a firm&rsquo;s market value was tied to financial results; 30 to 35 percent was tied to intangibles (like strategy, brand, and supply chain); and 25 to 30 percent related to the quality of leadership (surrogate for talent). A higher quality of talent should reflect a greater investor confidence that an organization can deliver intangibles and consistently create financial results.</p>\r\n<p>When we interviewed investors, they almost uniformly agreed that people matter and that talent management processes should affect their valuation of the firm. But even though they recognize the variance in market valuation due to talent, they often lack a rigorous way to understand and track talent. In the book Leadership Capital Index, we offer a framework and tool that investors and talent managers can use to measure the quality of an organization&rsquo;s leadership. Talent managers need to prepare a simple but robust way to discuss talent with investors, and they can rely on the Leadership Capital Index to give investors confidence in the quality of leadership overall and of talent in particular. Using this index, one firm reports employee productivity and well-being indicators to investors; another reports succession data; and another is working to report the entire Leadership Capital Index. Talent managers might prepare presentations on talent for investors, which then might compose 10 to 15 percent of investor calls or road shows. This could also include preparing talent metrics as part of the investor calls or it might be working to help investors recognize the quality of leadership within the organization.</p>\r\n<p><strong>Talent Matters Conclusion</strong></p>\r\n<p>Quality of talent clearly impacts employee and organization outcomes. In some cases, unique individual talent (e.g., a scientist, a rainmaker, or an innovator) helps organizations succeed. But, looking ahead, talent will also impact stakeholders outside the organization including boards of directors, customers, and investors and must go beyond individual talent. When talent ideas and tools connect to these stakeholders, more value is created for the stakeholders and the organization.</p>\r\n<p>Source: <a href=\"https://www.hrexchangenetwork.com/hr-talent-management/articles/talent-matters-to-all-stakeholders\">https://www.hrexchangenetwork.com/hr-talent-management/articles/talent-matters-to-all-stakeholders</a></p>\r\n<p>&nbsp;</p>', '1725talent_matters_to_all_stakeholders_business_man_moving_chess_pieces.jpg', '2019-09-15 04:56:00', '2019-09-15 04:56:00', NULL, 'Y'),
(13, NULL, 'when-we-tell-people-to-do-their-jobs', 'When we tell people to do their jobs', '<p>When we tell people to do their jobs, we get workers. When we trust people to get the job done, we get leaders.</p>\r\n<p>To become a leader, we have to go through a transition. Some go through it quickly. Some go through it slowly. And, unfortunately, some never go through it at all.</p>\r\n<p>When we are junior, our only job is to be good at our job. When we&rsquo;re junior, our companies will give us lots of training&mdash;how to use the software, how to sell, how to make a presentation&mdash;so that we will be good at our job. Some even get advanced degrees so they can be even better at their job&mdash; accountants or engineers, for example. And if we are good at our job, the company will promote us. And if we are really good at our job, eventually we get promoted to a position where we become responsible for the people who do the job we used to do. But very few companies teach us how to do that. Very few companies teach us how to lead. That&rsquo;s like putting someone at a machine and demanding results without showing them how the machine works.</p>\r\n<p>That&rsquo;s why we get managers and not leaders inside companies. Because the person who got promoted really does know how to do our job better than we do . . . that&rsquo;s what got them promoted in the first place. Of course they are going to tell us how we &ldquo;should&rdquo; do things. They manage us because no one taught them how to lead us.</p>\r\n<p>This is one of the hardest lessons to learn when we get promoted to a position of leadership&mdash;that we are no longer responsible for doing the job, we are now responsible for the people who do the job. There isn&rsquo;t a CEO on the planet who is responsible for the customer. CEOs are responsible for the people who are responsible for the customer. Get that right, and everybody wins&mdash;employees and customers.</p>\r\n<p>Leadership is hard work. Not the hard work of doing the job&mdash;it&rsquo;s the hard work of learning to let go. It&rsquo;s the hard work of training people, coaching people, believing in people and trusting people. Leadership is a human activity. And, unlike the job, leadership lasts beyond whatever happens during the workday.</p>\r\n<p>Source: <a href=\"https://www.linkedin.com/pulse/when-we-tell-people-do-jobs-get-workers-trust-job-done-simon-sinek\">https://www.linkedin.com/pulse/when-we-tell-people-do-jobs-get-workers-trust-job-done-simon-sinek</a></p>\r\n<p>&nbsp;</p>', '9019images.jpg', '2019-09-15 04:57:17', '2019-09-15 04:57:17', NULL, 'Y');
INSERT INTO `blog` (`id`, `cat_id`, `slug`, `title`, `articles`, `image`, `cr_date`, `up_date`, `author`, `stat`) VALUES
(14, NULL, 'human-resource-management-in-nepal', 'नेपालमा मानव संसाधन व्यवस्थापन', '<p>नेपालको व्यावसायिक क्षेत्रमा मानव संसाधन व्यवस्थापनका लागि छुट्टै निकाय (विभाग) गठन गर्ने प्रचलन शुरू भएको एक दशकभन्दा धेरै भएको छैन । यसअघि सामान्य प्रशासनिक र व्यक्तिगत तवरबाट मानव संसाधन व्यवस्थापन हुँदै आएको थियो । उत्पादन प्रणालीमा मानव संसाधनको महत्त्वबोध हुँदै गएपछि र अन्तरराष्ट्रिय बजारको प्रभाव पर्दै गएपछि अहिले प्रायः सबैजसो औपचारिक संस्थाहरूले मानव संसाधन व्यवस्थापनका लागि&nbsp; छुट्टै विभाग गठन गर्न थालेका छन् । तर पनि, कतिपय संस्थाहरूमा मानव संसाधन व्यवस्थापनलाई सामान्य प्रशासन विभाग वा त्यसको निर्देशकअन्तर्गत रहेर काम गर्नुपर्ने अवस्था छ । विश्वव्यापी रूपमा हेर्ने हो भने मानव संसाधनलाई छुट्टै व्यावसायिक र स्वायत्त विभागले व्यवस्थापन गर्ने प्रचलन स्थापित भइसकेको छ । यसले संस्थाको उत्पादकत्व र नाफामा पनि निकै ठूलो मात्रामा अभिवृद्धि भइरहेको छ ।&nbsp; यसो हुँदा त्यहाँको प्रतिव्यक्ति आयमा पनि निकै वृद्धि भएको छ । बाहिरी देशहरूमा मानव संसाधन विकासलाई संस्थाको व्यावसायिक रणनीति बनाएर व्यवस्थापन र सञ्चालक समितिमा समेत लैजाने गरिन्छ । त्यसको कार्यान्वयन पनि पूर्णरूपमा हुने गरेको छ ।</p>\r\n<p>नेपालमा पनि विस्तारै मानव संसाधन विकासले गति लिन शुरू गरेको छ । केही ठूला संस्थाहरूमा यसलाई व्यावसायिक रूपमा नै व्यवस्थापनको&nbsp; महत्त्वपूर्ण अङ्गका रूपमा स्थान दिन थालिएको छ । तर पनि, मानव संसाधन व्यवस्थापनलाई व्यावसायिक बनाउन अझै धेरै गर्न बाँकी छ । यसलाई संस्थाको महत्त्वपूर्ण र रणनीतिक विभागका&nbsp; रूपमा विकास गर्न आवश्यक छ । यसो गर्दा नेपालका व्यावसायिक संस्थाहरूलाई के फाइदा हुन्छ भन्ने कुरा महत्त्वपूर्ण छ । यसको मुख्य उद्देश्य संस्थाका कर्मचारीहरूको वृत्तिविकासमा सहयोग गर्नु हो । यसबाट कर्मचारीहरूको कार्यक्षमता र उत्पादकत्व वृद्धि हुन्छ । यसले व्यवसायी तथा संस्थाको छवि पनि बढाउँछ ।</p>\r\n<p>संस्थामा मानव संसाधन व्यवस्थापन विभाग राख्ने तर कुनै निर्णायक भूमिका र अधिकार नदिने पनि गरिएको पाइन्छ । तर, यसो गर्नुको कुनै अर्थ छैन । व्यावसायिक संस्थामा मानव संसाधन व्यवस्थापन विभागलाई सोसम्बन्धी सम्पूर्ण अधिकार दिनुपर्छ । यसरी अधिकार प्राप्त विभाग पनि पूर्ण जवाफदेही हुनुपर्छ । यसका लागि सञ्चालकले आवश्यक वातावरण तयार गरिदिनुपर्छ । मानव संसाधन विभागले पनि त्यो चुनौतीलाई आत्मसात् गर्दै अगाडि बढ्न सक्नुपर्छ । यो विभागमा व्यावसयिक चुस्तता हुनुपर्छ । यो संस्थाको संस्थागत वृद्धिका बारे सचेत रहनुपर्छ । संस्थाको उत्पादकत्व वृद्धिका लागि सधैं ध्यान पुर्याउनुपर्छ । कर्मचारीको स्तर सुधारमा ध्यान दिँदै कसरी अदक्ष कर्मचारीको दक्षता बनाउन सकिन्छ भन्ने विषयमा सधैं सजग रहनुपर्छ । उत्पादकत्व कम भएका वा सुधार गर्न नसक्ने कर्मचारीलाई नियमपूर्वक हटाउन पनि सक्नुपर्छ । यस्ता विषयमा समयमा नै उपयुक्त निर्णय लिन सक्ने क्षमता मानव संसाधन व्यवस्थापकसँग हुनुपर्छ । यसका लागि मानव संसाधन विभागको प्रतिनिधि संस्थाको व्यवस्थापन समूह वा सञ्चालक समितिमा हुन आवश्यक छ । किनभने व्यवस्थापन समितिमा उनीहरू हुन सकेनन् भने त्यहाँ आफ्नो विचार व्यक्त हुन सक्दैन ।</p>\r\n<p>निर्णायक ठाउँमा मानव संसाधन विभागको प्रतिनिधि मात्रै भएर पुग्दैन, उसले आफ्नो निर्णय प्रस्तुत गर्न सक्ने सहज वातावरण पनि हुनु जरुरी छ । संस्थाको बैठकमा आएका विभिन्न विचारमध्ये मानव संसाधन विभागका व्यावसायिक तथा रणनीतिक तर्कहरूले पनि स्थान पाउनुपर्छ । अनि मात्रै व्यावसायिक सङ्गठनको उत्पादकत्व बढ्न सक्छ । त्यति हुँदाहुँदै पनि नेपाली व्यवसायमा यसलाई नयाँ र नौलो मानेर उचित स्थान दिइएको पाइँदैन । नेपालका व्यावसायिक सङ्गठनहरूले यसको महत्त्व बुझे पनि यसलाई प्रभावकारी रूपमा लागू गर्न सकेका छैनन् ।</p>\r\n<p>नेपालमा परम्परागत व्यक्तिवादी साहूजी प्रथामा आधारित सङ्गठनहरूको बाहुल्यता छ । अहिले व्यावसायिक बनेका केही सङ्गठनहरू पनि यही अवस्थाबाट विकास हुँदै आएका हुन् । मानव संसाधनलाई श्रमसँग मात्रै जोडेर हेर्ने गरिएको छ । यसभित्र औद्योगिक तथा मानसिक श्रमका कुरा पनि आउँछन् । औद्योगिक क्षेत्रमा विभिन्न श्रमिक सङ्गठनहरूले पनि प्रभावकारी मानव संसाधन व्यवस्थापनमा बाधा पुर्याउने गरेका छन् । यसमा पनि राजनीतिक आस्थाले काम गर्ने गरेको छ । मानव संसाधन विभागले मात्रै यी सबै कुराको व्यवस्थापन गर्न सक्दैन । औद्योगिक क्षेत्रमा अहिले दक्ष मानव स्रोतको उपयोग हुन सकेको छैन । यसको मुख्य कारण मानव संसाधनसम्बन्धी जनचेतनाको&nbsp; अभाव नै हो ।</p>\r\n<p>मानव संसाधन व्यवस्थापन सुधारका लागि शैक्षिक संरचनामा पनि सुधार हुन आवश्यक छ । नेपालमा अहिलेसम्म सैद्धान्तिक पढाइ मात्रै बढी हुँदै आएको छ, जुन कम व्यावहारिक छ । पास/फेल वा प्रमाणपत्रका आधारमा मात्रै शिक्षाको स्तर निर्धारण गर्ने प्रचलन छ । यस्तो शिक्षा प्रणालीमा आमूल परिवर्तनको खाँचो छ । अहिलेको शिक्षाप्रणालीलाई परिवर्तन गरेर नेपालको वस्तुस्थिति तथा व्यवसाय सुहाउँदो प्रयोगात्मक शैक्षिक प्रणालीको विकास गर्नु जरुरी छ । विद्यालयस्तरबाट नै यस्तो शिक्षा प्रणालीको विकास गर्दै ल्याउनुपर्छ, जसले गर्दा दीर्घकालीन रूपमा दक्ष जनशक्ति उत्पादन गर्न सहयोग गर्छ । नेपालमा स्थायी जागीरमा जीवन खोज्ने प्रचलनको अन्त्य हुनुपर्छ तर कर्मचारीको अधिकारबारे भने सरकार जिम्मेवार हुनुपर्छ । नेपालमा प्रयोगात्मक शिक्षामा क्रान्तिकारी परिवर्तन आवश्यक छ ।</p>\r\n<p>नेपालमा उच्च माध्यमिक र कलेजस्तरको शिक्षामा मानव संसाधन व्यवस्थापनको पढाइलाई महत्त्व दिन सकिएको छैन । यो विषयलाई प्राथमिकतामा राखेर पाठ्यक्रम तयार गर्न सकिएको छैन । वित्त र बजारशास्त्र वा अन्य विषयलाई मात्रै बढी जोड दिएको पाइन्छ । अहिले केही निजी क्याम्पसहरूले यो विषयलाई पनि महत्त्व दिएर पढाउन थालेका छन् । यसलाई सकारात्मक मान्न सकिन्छ । तर पनि, यो जुन रूपमा अघि आउनुपर्ने हो, त्यसरी आउन सकेको छैन । विद्यार्थीलाई मानव संसाधन&nbsp; विषय पढ्नका लागि प्रेरित गर्नु अहिलेको आवश्यकता हो ।</p>\r\n<p>नेपालमा मानव संसाधनलाई व्यावसायिक रूपमा प्रयोग गर्ने पहिलो क्षेत्र बैङ्किङ हो । यही भएर नै यो क्षेत्रको प्रतिव्यक्ति आय र उत्पादकत्व अन्य क्षेत्रको भन्दा बढी छ । यो क्षेत्र तुलनात्मक रूपमा अन्य क्षेत्रभन्दा अगाडि छ । औद्योगिक क्षेत्रको मूल्याङ्कन गर्ने हो भने मानव संसाधनको भूमिकालाई चक्रीय प्रणलीका रूपमा विकास गर्न आवश्यक छ । एउटा संस्था र उद्योगमा मात्रै नभएर आर्थिक विकासका सबै क्षेत्रमा यसको व्यावसायिकतालाई चक्रीय रूपमा विकास गर्दै लैजान सक्नुपर्छ । कुनै पनि संस्थामा तल्लो तहका कर्मचारीदेखि सञ्चालकसम्मलाई परामर्शका लागि यस्ता&nbsp; विभागको आवश्यक छ ।</p>\r\n<p>नेपालमा जनशक्तिको होइन, दक्ष जनशक्तिको अभाव छ । वर्षेनी ४ लाख श्रमशक्ति नेपाली बजारमा आउने गरेको तथ्याङ्क छ । लामो समयको सशस्त्र द्वन्द्वपछि अहिले देश शान्ति प्रक्रियामा आएको छ । यसले गर्दा पनि नेपालमा धेरैको रोजगारीको अवसर गुमेको छ । अब त्यो समस्यालाई कसरी सम्बोधन गर्न सकिन्छ भन्ने तर्फसोच्नुपर्छ । यो राष्ट्रिय रणनीतिको कुरा पनि हो । यसका लागि मानव संसाधन विकासलाई पनि राष्ट्रिय विकासको रणनीतिको एक अङ्गका रूपमा स्वीकार्नुपर्छ । विकासका हिसाबले आगामी ५ वर्षका लागि नेपालमा कुनकुन उद्योगलाई प्राथमिकतामा राख्ने भन्ने निर्णय गर्नुपर्छ । ती क्षेत्रहरूलाई आवश्यक पर्ने जनशक्ति उत्पादन गर्नतिर लाग्नुपर्छ । पर्यटन, जलविद्युत्लगायत क्षेत्रमा कस्तो जनशक्ति आवश्यक पर्छ भन्नेतर्फ सरकार र सम्बन्धित क्षेत्र सचेत हुनुपर्छ । यसरी राष्ट्रिय विकासको लक्ष्यसँग मानव संसाधन विकासलाई जोडेर लैजान सकियो भने देशले उन्नतिको बाटो समात्नेछ ।</p>\r\n<p>Source: <a href=\"http://www.abhiyan.com.np/?p=2258\">http://www.abhiyan.com.np/?p=2258</a></p>', '72392146241925question-and-answer-prashna-uttar.jpeg', '2019-09-15 04:58:37', '2019-09-16 04:23:42', NULL, 'Y'),
(15, NULL, 'what-is-human-resource-planning', 'What is Human Resource Planning ?', '<p><strong>Human Resource Planning (HRP) is the process of forecasting the future human resource requirements of the organization and determining as to how the existing human resource capacity of the organization can be utilized to fulfill these requirements</strong>. It, thus, focuses on the basic economic concept of demand and supply in context to the human resource capacity of the organization.</p>\r\n<p>It is the HRP process which helps the management of the organization in meeting the future demand of human resource in the organization with the supply of the appropriate people in appropriate numbers at the appropriate time and place. Further, it is only after proper analysis of the HR requirements can the process of recruitment and selection be initiated by the management. Also, HRP is essential in successfully achieving the strategies and objectives of organization. In fact, with the element of strategies and long term objectives of the organization being widely associated with human resource planning these days, HR Planning has now became Strategic HR Planning.</p>\r\n<p>Though, HR Planning may sound quite simple a process of managing the numbers in terms of human resource requirement of the organization, yet, the actual activity may involve the HR manager to face many roadblocks owing to the effect of the current workforce in the organization, pressure to meet the business objectives and prevailing workforce market condition. HR Planning, thus, help the organization in many ways as follows:</p>\r\n<ul type=\"square\">\r\n<li>HR managers are in a stage of anticipating the workforce requirements rather than getting surprised by the change of events</li>\r\n<li>Prevent the business from falling into the trap of shifting workforce market, a common concern among all industries and sectors</li>\r\n<li>Work proactively as the expansion in the workforce market is not always in conjunction with the workforce requirement of the organization in terms of professional experience, talent needs, skills, etc.</li>\r\n<li>Organizations in growth phase may face the challenge of meeting the need for critical set of skills, competencies and talent to meet their strategic objectives so they can stand well-prepared to meet the HR needs</li>\r\n<li>Considering the organizational goals, HR Planning allows the identification, selection and development of required talent or competency within the organization.</li>\r\n</ul>\r\n<p>It is, therefore, suitable on the part of the organization to opt for HR Planning to prevent any unnecessary hurdles in its workforce needs. An HR Consulting Firm can provide the organization with a comprehensive HR assessment and planning to meet its future requirements in the most cost-effective and timely manner.</p>\r\n<p><strong>An HR Planning process simply involves the following four broad steps:</strong></p>\r\n<p>&nbsp;</p>\r\n<ul type=\"square\">\r\n<li><strong>Current HR Supply:</strong>&nbsp;Assessment of the current human resource availability in the organization is the foremost step in HR Planning. It includes a comprehensive study of the human resource strength of the organization in terms of numbers, skills, talents, competencies, qualifications, experience, age, tenures, performance ratings, designations, grades, compensations, benefits, etc. At this stage, the consultants may conduct extensive interviews with the managers to understand the critical HR issues they face and workforce capabilities they consider basic or crucial for various business processes.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<ul type=\"square\">\r\n<li><strong>Future HR Demand:</strong>&nbsp;Analysis of the future workforce requirements of the business is the second step in HR Planning. All the known HR variables like attrition, lay-offs, foreseeable vacancies, retirements, promotions, pre-set transfers, etc. are taken into consideration while determining future HR demand. Further, certain unknown workforce variables like competitive factors, resignations, abrupt transfers or dismissals are also included in the scope of analysis.\r\n<p>&nbsp;&nbsp;</p>\r\n</li>\r\n<li><strong>Demand Forecast:</strong>&nbsp;Next step is to match the current supply with the future demand of HR, and create a demand forecast. Here, it is also essential to understand the business strategy and objectives in the long run so that the workforce demand forecast is such that it is aligned to the organizational goals.\r\n<p>&nbsp;</p>\r\n</li>\r\n<li><strong>HR Sourcing Strategy and Implementation:</strong>&nbsp;After reviewing the gaps in the HR supply and demand, the HR Consulting Firm develops plans to meet these gaps as per the demand forecast created by them. This may include conducting communication programs with employees, relocation, talent acquisition, recruitment and outsourcing, talent management, training and coaching, and revision of policies. The plans are, then, implemented taking into confidence the mangers so as to make the process of execution smooth and efficient. Here, it is important to note that all the regulatory and legal compliances are being followed by the consultants to prevent any untoward situation coming from the employees.\r\n<p>&nbsp;</p>\r\n</li>\r\n</ul>\r\n<p>Hence, a properly conducted process of HR Planning by an HR Consulting Firm helps the organization in meeting its goals and objectives in timely manner with the right HR strength in action.</p>\r\n<p>Source:&nbsp;<a href=\"https://www.ukessays.com/essays/human-resources/human-resource-planning.php\">https://www.ukessays.com/essays/human-resources/human-resource-planning.php</a></p>', '2479hr-teamwork-image.jpg', '2019-09-15 05:02:03', '2019-09-15 05:02:03', NULL, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`, `slug`, `status`) VALUES
(1, 'For Employers', 'for-employers', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `checkvalue`
--

CREATE TABLE `checkvalue` (
  `id` int(11) NOT NULL,
  `attid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `funcareaid` int(11) NOT NULL,
  `chkvalue` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `clientname` varchar(200) NOT NULL,
  `image` varchar(220) DEFAULT NULL,
  `url` varchar(220) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `orderno` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `clientname`, `image`, `url`, `status`, `orderno`) VALUES
(16, 'Chaudhary Group', '3089cg_logo.jpg', '', NULL, 1),
(17, 'MAW', '7815maw.png', '', NULL, 2),
(18, 'Yamaha Nepal', '5681yamaha.jpg', '', NULL, 3),
(19, 'Pathao', '6186pathao.png', '', NULL, 4),
(20, 'Onetowatch', '4549one_to_watch.png', '', NULL, 5),
(21, 'Golyan Group', '3901golyan_group.png', '', NULL, 6),
(22, 'Vishal Group', '4006vishal_group.jpg', 'https://www.vishalgroup.com/', NULL, 7),
(23, 'LCLS Hospitality', '3429lcls_hospitality.jpg', '', NULL, 8),
(24, 'JCB', '8893jcb.jpg', '', NULL, 9),
(25, 'CAS Trading', '2763cas_trading.jpg', '', NULL, 10),
(26, 'Himal Hydro', '5646himal_hydro.png', '', NULL, 11),
(27, 'CG Cements', '7232cg_cements.jpg', '', NULL, 12),
(28, 'Lucky Group', '9085lucky_group.png', '', NULL, 13),
(29, 'Mangalam Group', '4588mangalam.jpg', '', NULL, 14),
(30, 'Red Mud Coffee', '8734red_mud.jpg', '', NULL, 15),
(31, 'The British School', '5415the_british_school_kathmandu_logo_1.png', '', NULL, 16),
(32, 'Varun Beverages', '4722varun.jpg', '', NULL, 17),
(33, 'Vespa Scooter', '4743vespa-scooters-price-nepal.jpg', '', NULL, 18),
(34, 'Jagadamba Steel', '9708jagadamba.jpg', '', NULL, 19),
(35, 'Komatsu Nepal', '6875komatus_nepal.png', '', NULL, 20),
(36, 'Surya Nepal', '3389surya_group.jpg', '', NULL, 21);

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `contents` text,
  `cr_date` varchar(20) DEFAULT NULL,
  `up_date` varchar(20) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `stat` enum('Y','N') DEFAULT 'N',
  `meta_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `slug`, `title`, `contents`, `cr_date`, `up_date`, `author`, `stat`, `meta_title`, `meta_keyword`, `meta_description`) VALUES
(1, 'seeker-terms-conditions', 'Seeker Terms & Conditions', '<p><strong>Terms of Use</strong><br />The website, www.financejob.com (\"Site\") is an electronic web based platform for exploring opportunities and enhancing outreach using the online search and other tools available for the job seekers. It is owned and managed by Finance Job Nepal Pvt. Ltd (\"Company\") with its registered office in Lalitpur, Nepal.</p>\r\n<p>Any and all use of this website is subject to, and constitutes acknowledgment and acceptance of, the following Terms and Conditions (\"Terms\"). It is mandatory for all Job Seekers of the Site to have read carefully, fully understood and be in total agreement to the below mentioned Terms before they proceed to use any of the services of the Site (\"Services\"). The Services are available only to those individuals who can form legally binding contracts under the Nepal laws. Finance Job Pvt. Ltd. may amend these Terms of Use at any time by posting the amended version on this site. Such amended version shall automatically be effective upon its posting on this site.</p>\r\n<p><strong>Definition Clauses</strong><br />The following expressions shall have the following meanings in the Agreement defined below:</p>\r\n<ul>\r\n<li><strong>DATE OF ACTIVATION:</strong> is defined as the date specified by the Finance Job in its notice to the Job Seeker either through email indicating the approval to the Job Seeker\'s registration and permission to access the Service.</li>\r\n<li><strong>EXPIRY DATE:</strong> is defined as the expiry date of the notice of termination of the services.</li>\r\n<li><strong>JOB SEEKER:</strong> is any person who accesses the Site for whatever purpose, regardless of whether said Job Seeker has registered with Financejob.com as a registered Job Seeker or whether said Job Seeker is a paying customer for a specific service provided by the Site. A Job Seeker includes the person using this Site to access any information on the Site.</li>\r\n<li><strong>SERVICES:</strong> is defined as the services to be provided by the Company to the Job Seeker at Financejob.com including the provision of facilities for the following:</li>\r\n<li>A Job Seeker who wishes to post a resume to seek employment.</li>\r\n<li>A Job Seeker who wishes to secure recruitment through Financejob.com.</li>\r\n<li>A Job Seeker who wishes to advertise at Financejob.com.</li>\r\n<li>Job Seeker who wishes to receive advertisements, newsletters and promotional messages on www.financejob.com and through emails.</li>\r\n<li><strong>REGISTRATION DATA:</strong> is defined as all the information and particulars of the Job Seeker requested on initial application and subscription, including but without limiting to the Job Seeker\'s name, mailing address, email address and telephone number. The words can be used either in the singular or plural sense and those implying one gender shall also include the other.</li>\r\n</ul>\r\n<p><strong>Commencement of Service:</strong><br />The Service shall commence on the Date of Activation after we have received the details required.</p>\r\n<p><strong>Job Seeker\'s Obligations</strong></p>\r\n<ul>\r\n<li>The Job Seeker agrees and expressly states that he/she is solely responsible for the accuracy and completeness of the Registration Data and other information given to the Company in the application for Job Seeker in order to use the Service. The Job Seeker will ensure that the data shared with Financejob.com doesn\'t contain any fraudulent, false, misleading or manipulated facts.</li>\r\n<li>The Job Seeker will comply with all notices or instructions given by the Company from time to time in respect of the use of the Service.</li>\r\n<li>The Job Seeker shall be solely responsible for all information retrieved, stored and transmitted through the Service by him.</li>\r\n<li>The Job Seeker is solely responsible for the maintenance of confidentiality of the login information.</li>\r\n<li>This would include the Job Seeker\'s password and Job Seeker Username and all activities and transmission performed by the Job Seeker at Financejob.com.</li>\r\n<li>The Job Seeker will immediately notify the Company of any unauthorized use of the Job Seeker\'s account or any other breach of security known to the Job Seeker.</li>\r\n<li>The Job Seeker will take all such measures as may be necessary (including without limitation changing his password from time to time) to protect the secrecy.</li>\r\n<li>With this registration, Job Seeker agree to accept communications (through Calls/Chat/ Mails/SMS) on the numbers made available during registration or subsequently irrespective of being on Do Not Call Registry; which include company / your number / an assigned point of contact; with respect to the subscribed services of Finance Job Pvt. Ltd.</li>\r\n</ul>\r\n<p><strong>Proprietary Rights in Content on Finance Job</strong><br />Financejob.com owns and retains other proprietary rights in the site as well as the services. The Site contains the copyrighted material, trademarks, and other proprietary information of Financejob.com. You may not copy, modify, publish, transmit, distribute, perform, display, or sell any such proprietary information, except for that information which is in the public domain or for which you have been given permission.</p>\r\n<p><strong>Intellectual Property Rights</strong><br />All logos, brands, trademarks, registered marks (\"Marks\") appearing in Financejob.com are the properties either owned or used under license by the Company and / or its associates. All the rights accruing from the same, statutory or otherwise and intellectual property rights wholly vest with the Company / its associates. All rights not otherwise claimed under this Agreement or by the Company / its associates are hereby reserved.</p>\r\n<p>The access to the Site does not confer upon the Job Seeker any license or right to use these Marks and therefore the use of these Marks in any form or manner whatsoever is strictly prohibited. Any violation of the above would constitute an offence under the prevailing laws of Nepal.</p>\r\n<p><strong>Prohibited Use</strong></p>\r\n<ul>\r\n<li>The Job Seeker will not allow any person other than the authorized person(s) named in the application form to use the Service.</li>\r\n<li>The Job Seeker shall use the Service only for the purpose for which it is subscribed.</li>\r\n<li>The Job Seeker will comply with all applicable laws and shall not contravene any applicable law of Nepal relating to the Services, including any regulation made pursuant thereto.</li>\r\n<li>The Job Seeker shall not to use the Service for any unlawful purpose including without limitation criminal purposes.</li>\r\n<li>The Job Seeker shall not to use the Service to send or receive any message, which is offensive on moral, religious, racial or political grounds or of an offensive, vulgar, obscene, malicious or menacing nature.</li>\r\n<li>The Job Seeker shall be prohibited in persistently sending messages or make postings on Financejob.com to any other Job Seeker or third party who access Financejob.com without reasonable cause or for causing any peril, harassment, annoyance, irritation, or anxiety to any person.</li>\r\n<li>The Job Seeker is prohibited to introduce, upload, post, distribute, publish or transmit any information or software that:<br />a) Contains a virus, worm or other harmful component into the Internet or Financejob.com network system.<br />b) Breaches on any intellectual property rights of any person or retain information in any computer system or otherwise with such intention.<br />c) Is unlawful, or which may potentially be perceived as being abusive, defamatory, libelous, harmful, threatening, harassing, vulgar, obscene, or racially, ethnically, or otherwise objectionable.<br />d) Is meant to mislead or deceive the other Job Seekers<br />e) Infringes any trademark, patent or copyright rights</li>\r\n</ul>\r\n<p>In the event of a violation of any of the above mentioned covenants by the Job Seeker, and same comes to the Company\'s knowledge, the Company shall have the right to delete any material relating to the violations without prior notice to the Job Seeker. The Company shall issue a warning to the Job Seeker to discontinue any activity, which leads to the said violations, and in the event the Job Seeker continues with such activity, the Company has the sole authority to terminate or suspend the Job Seeker at Financejob.com and/or any other related facility. In addition to the right to indemnity available to the Company, the Company shall have the right to any legal remedy, against the Job Seeker to recover the loss suffered by the Company and the harm caused to the goodwill of the Company, due to such violation by the Job Seeker.</p>\r\n<p><strong>Copyright Policy</strong><br />You may not post, distribute, or reproduce in any way any copyrighted material, trademarks, or other proprietary information without obtaining the prior written consent of the owner of such proprietary rights.</p>\r\n<p><strong>Confidentiality</strong><br />As Financejob.com is an online platform so it cannot guarantee confidentiality of information provided by Job Seekers who use the Site, so any breach in privacy due to technical fault or any other means is not the responsibility of Financejob.com.</p>\r\n<p>The agreement between Financejob.com and the Job Seeker can neither be deemed as \"non-poach agreement\" nor can the same be termed or used as an alternative to \"non-poach agreement\" as Financejob.com being a public site, all information posted by Job Seeker on the Site goes to the public domain except information / data which is specifically assigned as a non-public / private character.</p>\r\n<p>The Job Seeker is entitled access to his own data and information stored in the database at Financejob.com (subject to prior confirmation of identity) and may edit or amend such data and information at any time.</p>\r\n<p>The Job Seekers need to be aware that when they voluntarily reveal identification oriented information (name, e-mail address) in chat and bulletin board areas, such information may be collected by a third party resulting in unsolicited messages from third parties. Such interaction is beyond the control and liability of Financejob.com. Financejob.com is liable to share all information available with it in response to any legal proceedings including and not restricted to court orders, notices, subpoena, FIR etc.</p>\r\n<p><strong>Maintenance of Service</strong><br />The Company may at any time deactivate or suspend the Job Seeker\'s access to Financejob.com and/or the Services (as the case may be) without any prior notice in order to carry out system maintenance, upgrading, testing, repairs and other related work. Without prejudice to the other provisions of this Agreement, the Company shall not be liable for any loss and damage, costs and expense that the Job Seeker may suffer or incur, and no fees or charges payable by the Job Seeker to the Company shall be deducted, refunded or rebated, as a result of such deactivation or suspension.</p>\r\n<p><strong>Modification to Service</strong><br />The Company reserves the right to modify or discontinue the Service with or without notice to the Job Seeker. The Company shall not be liable to the Job Seeker or any third party should the Company exercise its right to modify or discontinue the Service.</p>\r\n<p><strong>Suspension of Service</strong><br />Without prejudice to any other rights or remedies of the Company, the Company may suspend the Service provided by the Company.</p>\r\n<p>Upon suspension, the Service shall be deemed to be terminated from the date stipulated by the Company.</p>\r\n<p>Finance Job reserves the right to block the Job Seeker, if Job Seeker places</p>\r\n<ul>\r\n<li>Objectionable Contents, including: Offensive, abusive, threatening, obscene, defamatory or libelous materials</li>\r\n<li>Multiple Profiles, including: Only a single profile is allowed for each job opening.</li>\r\n<li>False Contact Information, including: Any email address, phone numbers, postal address and any other means of contact material.</li>\r\n</ul>\r\n<p><strong>Termination of Service</strong><br />The Company may terminate this Agreement with immediate effect, without prior notice to the Job Seeker and without further prejudice to all other rights:</p>\r\n<ul>\r\n<li>If in the opinion of the Company, the Job Seeker has breached any of the terms or conditions of this agreement.</li>\r\n<li>If in the opinion of the Company or any regulatory authority, it is not in the public interest to continue providing the Service to the Job Seeker for any reason.</li>\r\n</ul>\r\n<p>The following could be deemed as the reason for the termination of the services:</p>\r\n<ul>\r\n<li>harasses or advocates harassment of another person;</li>\r\n<li>is patently offensive to the online community, any such content that promotes racism, bigotry, hatred or physical harm of any kind against any group or individual;</li>\r\n<li>involves unsolicited mass mailing or \"spamming\", the transmission of \"junk mail\", \"chain letters\";</li>\r\n<li>promotes any information that is misleading, is false or that promotes illegal activities or conduct that is abusive, threatening, obscene, defamatory or libelous;</li>\r\n<li>promotes unauthorized or an illegal copy of another person\'s copyrighted work, such as providing pirated computer programs or links to them, providing information to circumvent manufacture-installed copy-protect devices;</li>\r\n<li>contains restricted or password only access pages, or hidden pages or images (those not linked to or from another accessible page);</li>\r\n<li>displays pornographic or obscene or sexually explicit material of any kind;</li>\r\n<li>provides any kind of instructional information about illegal activities such as violating someone\'s privacy, making or buying illegal weapons, or providing or creating computer viruses, or hacking;</li>\r\n<li>solicits passwords or personal identifying information for commercial or unlawful purposes from other users; Finance Job Nepal also reserves all rights to suspend or terminate the services if found the services is not being used as per the mentioned instructions or the case may be.</li>\r\n</ul>\r\n<p><strong>Disclaimer</strong></p>\r\n<ul>\r\n<li>The Company shall not be liable for any loss of information howsoever caused whether as a result of any interruption, suspension, or termination of the Service or due to acts of God, natural calamities, virus / system attacks, hacking or otherwise, or for the contents, accuracy or quality of information available, received or transmitted through the Service.</li>\r\n<li>The Job Seeker shall be solely responsible, and the Company shall not be liable in any manner whatsoever, for ensuring that in using the Service, all applicable laws, rules and regulations for the use of systems, service or equipment shall be at all times complied with.</li>\r\n<li>The Company makes no representations and warranties of any kind, whether expressed or implied, for the Services and in relation to the accuracy or quality of any information transmitted or obtained through the Services of Financejob.com.</li>\r\n<li>The Company shall not be liable for any loss or damages sustained by reason of any disclosure (inadvertent or otherwise) of any information concerning the Job Seeker\'s account and particulars nor for any error, omission or inaccuracy with respect to any information so disclosed.</li>\r\n<li>The Company neither guarantees nor offers any warranty about the credentials, status or authenticity of the prospective employer/organization contacting the Job Seekers post download of the resume or by access to the information/data posted by the Job Seekers.</li>\r\n<li>The Company does not warrant that Financejob.com or any of the web sites linked to Financejob.com be free of any operational errors or that it will be free of any virus, worm, or other harmful component.</li>\r\n<li>The Job Seeker acknowledges that it is not the Company\'s policy to exercise editorial control over and to edit or amend any data or contents of any emails or posting or any information that may be inserted or made available or transmitted to a third party in or through Financejob.com. The Company may refuse, suspend, terminate, delete or amend any artwork, materials, information or content of any data or information or posting so as, in the sole opinion of the Company, to comply with the legal or moral obligations as placed on the Company and to avoid infringing a third party\'s rights or any other rules, standards or codes of practices that may be applicable to the posting or Financejob.com or the internet.</li>\r\n<li>The resume / data fed by the Job Seeker can be updated by the Job Seeker alone and is solely their liability.</li>\r\n<li>Financejob.Com offers neither any guarantee nor warranty that there would be a satisfactory response or any response at all once the resume / data is fed by the Job Seeker.</li>\r\n<li>It is the sole prerogative and responsibility of the Job Seeker to check the authenticity of all or any response received or information displayed. Financejob.Com is a public site with free access and assumes no liability for the quality and genuineness of responses.</li>\r\n<li>Financejob.Com neither guarantees nor offers any warranty about the credentials of the prospective employer / consultant / organization which down loads the information and uses it to contact the Job Seekers on the site including prospective employer / consultant / visitor / Job Seeker.</li>\r\n<li>Financejob.Com uses a tested and automated algorithm for forwarding / search however, makes no representations and warranties of any kind, whether expressed or implied, for the Services and in relation to the accuracy and suitability.</li>\r\n<li>Financejob.Com provides job-related information posted by Employers / Recruiters / Consultants registered with it. However, it also posts some additional jobs including government jobs by collecting relevant information from other websites which include the State &amp; Central Government official websites. The Job Seeker shall find links to the original source that showcase these Job Details. These Job postings with links have been placed only for convenience of the Job Seekers and not for any commercial gain or profit. Financejob.Com is not responsible for the contents and also for the actual availability of the said jobs so advertised. Financejob.Com grants its Job Seekers direct linking to the portals/sites/resources from which this information is collected and no prior permission is required for the same. However, we do not permit our pages to be loaded/displayed/copied by any Job Seeker/Visitor for commercial / personal purposes on their websites.</li>\r\n</ul>\r\n<p><strong>Indemnity</strong><br />You agree to indemnify and hold Financejob.com, its subsidiaries, affiliates, officers, agents, and other partners and employees, harmless from any loss, liability, claim, or demand, including reasonable attorney\'s fees, made by any third party due to or arising out of your use of the Service in violation of this Agreement and/or arising from a breach of these Terms of Use and/or any breach of your representations and warranties set forth above.</p>\r\n<p><strong>Variation</strong><br />The Company reserves the right to amend the terms and conditions contained herein and in the Services Guide at any time upon notice (in such form as may be determined by the Company) to the Job Seeker.</p>\r\n<p>The Terms and Conditions of this agreement will be updated from time to time and posted at Financejob.com. The Job Seeker should visit the site periodically to review the Terms and Conditions. For the avoidance of doubt, the Job Seeker\'s continued use of the Service constitutes an affirmation and acknowledgement of the amended terms and conditions.</p>\r\n<p><strong>Limitation of Liability</strong></p>\r\n<ul>\r\n<li>Financejob.com only offers a platform to showcase the openings and the resumes and has no role in any transaction or communications and hence shall not be liable for any loss or damage of any sort arising out of the use and/or temporary or permanent discontinuation of its services.</li>\r\n<li>Financejob.com being a public site with free access assumes no liability for the quality and genuineness of responses. Finance Job cannot monitor the responses received by any Job Seeker in response to the information posted by them and so displayed on the site. Job Seeker should conduct its own background checks on the bonafide nature of all response(s). Financejob.com will not be liable for any inaccuracy of information on this website.</li>\r\n<li>Financejob.com expressly disclaims any liability arising due to presence of any fraudulent information published on the site.</li>\r\n<li>The Job Seeker is warned against disclosure of any personal / confidential / sensitive information to any previous or current employee of the company. The Job Seeker would do so solely at his / her own risk and</li>\r\n<li>Financejob.com shall not be liable for the outcome of any such transaction of information including and not limited to damages for loss of profits or savings, business interruption, loss of information or repute.</li>\r\n<li>That there are certain free and paid features which may not be incorporated in the mobile application version though they are a part of the original website since the mobile apps are designed to be compact and light to ensure a smooth experience. Each Job Seeker hereby represents, warrants and agrees that the same shall be acceptable as a matter of fact and no requests to incorporate any such feature in the mobile app version would be initiated by the Job Seekers.</li>\r\n<li>The Job Seeker hereby agrees to take full responsibility to research well before making using of any information on the Site. Financejob.com shall not be liable for any loss or damage of any sort arising out of the use and/or temporary or permanent discontinuation of its services.</li>\r\n</ul>\r\n<p><strong>Job Seeker Disputes</strong><br />The Job Seekers are solely responsible for your interactions at Financejob.com and Financejob.com reserves the right, but has no obligation, to monitor disputes between Job Seekers.</p>\r\n<p>Financejob.com will not be party to any legal proceedings between Job Seeker and any other registered or free Job Seeker for any transactions through the Site. Financejob.com will always abide by governing / legal authorities order and cooperate fully through the process, but the costs of the same shall be recovered from the party that has implicated financejobnepal.com in such case.</p>\r\n<p>Matter of Disputes and Jurisdictional Aspects<br />For any kind of legal dispute related to Financejob.com would be dealt in only territory of Kathmandu. All the legal issues are subjected only to pertinent contemporary\'s laws in force at Kathmandu to the jurisdiction of courts located in Kathmandu only.</p>\r\n<p><strong>Governing Law and Jurisdiction</strong><br />This Agreement and any dispute or matter arising from incidental use Financejob.com is governed by the laws of Nepal and the Job Seeker and the Company hereby submit to the exclusive jurisdiction of the courts at Kathmandu, Nepal. This Agreement, accepted upon use of the Site and further affirmed by becoming a Job Seeker of the Financejob.com, contains the entire agreement between you and Financejob.com regarding the use of the Site and/or the Service. If any provision of this Agreement is held invalid, the remainder of this Agreement shall continue in full force and effect.</p>', '2019-06-03 12:36:44', '2019-06-04 02:33:12', NULL, 'Y', 'Terms & Conditions for Jobseekers', 'Terms & Conditions for Jobseekers', 'Terms & Conditions for Jobseekers');
INSERT INTO `content` (`id`, `slug`, `title`, `contents`, `cr_date`, `up_date`, `author`, `stat`, `meta_title`, `meta_keyword`, `meta_description`) VALUES
(2, 'employer-terms-conditions', 'Employer Terms & Conditions', '<p><strong>Terms of Use</strong><br />The website, www.financejobnepal.com (\"Site\") is an electronic web based platform for exploring opportunities and enhancing outreach using the online search and other tools available for the Employers / Recruiters / Consultants / Members.It is owned and managed by Finance Job Nepal Pvt. Ltd. (\"Company\") with its registered office in Lalitpur, Nepal.</p>\r\n<p>Any and all use of this website is subject to, and constitutes acknowledgment and acceptance of, the following Terms and Conditions (\"Terms\").</p>\r\n<p><strong>Definition Clauses:</strong><br />The following expressions shall have the following meanings in the Agreement defined below:</p>\r\n<ul>\r\n<li><strong>DATE OF ACTIVATION:</strong> is defined as the date specified by the Finance Job Nepal in its notice to the Member either through email indicating the approval to the Member\'s registration and permission to access the Service.</li>\r\n<li><strong>EXPIRY DATE:</strong> is defined as the expiry date of the notice of termination of the services.</li>\r\n<li><strong>MEMBER:</strong> is any person who accesses the Site for whatever purpose, regardless of whether said Member has registered with www.financejobnepal.com as a registered Member or whether said Member is a paying customer for a specific service provided by the Site. A Member includes the person using this Site to access any information on the Site.</li>\r\n<li><strong>FINANCEJOBNEPAL.COM:</strong> is defined as the Internet web site of the Company at www.financejobnepal.com</li>\r\n<li><strong>SERVICES:</strong> is defined as the services to be provided by the Company to the Member at FinanceJobNepal.com including the provision of facilities for the following:<br />A Member who wishes to reach a job seeker.<br />A Member who wishes to hire a job seeker through FinanceJobNepal.com.<br />A Member who wishes to advertise at FinanceJobNepal.com.<br />Member who wishes to receive advertisements, newsletters and promotional messages on www.financejobnepal.com and through emails.</li>\r\n<li><strong>SUBSCRIPTION FEES:</strong> is defined as the payment that has to be made to FinanceJobNepal.com to access the services.</li>\r\n<li><strong>REGISTRATION DATA:</strong> is defined as all the information and particulars of the Member requested on initial application and subscription, including but without limiting to the Member\'s name, mailing address, email address, account and telephone number. The words can be used either in the singular or plural sense and those implying one gender shall also include the other.</li>\r\n<li><strong>RATES:</strong> The subscription rates for the Services shall be at the price indicated in the Rate Card or the Company may prescribe such other rates from time to time. Liability for the Subscription Fees shall accrue from the Date of Activation.</li>\r\n</ul>\r\n<p><strong>Commencement of Service</strong><br />The Service shall commence on the Date of Activation after we have received the necessary payment.</p>\r\n<p>Member\'s Obligations</p>\r\n<ul>\r\n<li>The Member agrees and expressly states that he/she is solely responsible for the accuracy and completeness of the Registration Data and other information given to the Company in the application for membership in order to use the Service. The Member will ensure that the data shared with Finance Job Nepal.Com doesn&rsquo;t contain any fraudulent, false, misleading or manipulated facts.</li>\r\n<li>The Member is responsible for the set-up or configuration of all the necessary equipment required to access the Service.</li>\r\n<li>The Member will comply with all notices or instructions given by the Company from time to time in respect of the use of the Service.</li>\r\n<li>The Member shall be solely responsible for all information retrieved, stored and transmitted through the Service by him.</li>\r\n<li>The Member is solely responsible for the maintenance of confidentiality of the login information.</li>\r\n<li>This would include the Member\'s password and Member name and all activities and transmission performed by the Member at FinanceJobNepal.com.</li>\r\n<li>The Member will immediately notify the Company of any unauthorized use of the Member\'s account or any other breach of security known to the Member.</li>\r\n<li>The Member will pay promptly the Subscription Fees as required by the Company from time to time.</li>\r\n<li>The Member will take all such measures as may be necessary (including without limitation changing his password from time to time) to protect the secrecy.</li>\r\n<li>In case you chose to discontinue your association with us, you can unsubscribe / remove your account by completing the delisting procedure using the Remove Account link available in your folder.</li>\r\n<li>With this registration, you agree to accept communications (through Calls/Chat/ Mails/SMS) on the numbers made available during registration or subsequently irrespective of being on Do Not Call Registry; which include company / your number / an assigned point of contact; with respect to the subscribed services of FinanceJobNepal.com, Finance Job Nepal Pvt. Ltd.</li>\r\n</ul>\r\n<p><strong>Proprietary Rights in Content on Finance Job Nepal</strong><br />FinanceJobNepal.com owns and retains other proprietary rights in the site as well as the services. The Site contains the copyrighted material, trademarks, and other proprietary information of FinanceJobNepal.com. You may not copy, modify, publish, transmit, distribute, perform, display, or sell any such proprietary information, except for that information which is in the public domain or for which you have been given permission.</p>\r\n<p><strong>Intellectual Property Rights</strong><br />All logos, brands, trademarks, registered marks (\"Marks\") appearing in FinanceJobNepal.Com are the properties either owned or used under license by the Company and / or its associates. All the rights accruing from the same, statutory or otherwise and intellectual property rights wholly vest with the Company / its associates. All rights not otherwise claimed under this Agreement or by the Company / its associates are hereby reserved. The access to the Site does not confer upon the Member any license or right to use these Marks and therefore the use of these Marks in any form or manner whatsoever is strictly prohibited. Any violation of the above would constitute an offence under the prevailing laws of Nepal.</p>\r\n<p><strong>Prohibited Use</strong></p>\r\n<ul>\r\n<li>The Member will not allow any person other than the authorized person(s) named in the application form to use the Service.</li>\r\n<li>The Member shall use the Service only for the purpose for which it is subscribed.</li>\r\n<li>The Member will comply with all applicable laws and shall not contravene any applicable law of Nepal relating to the Services, including any regulation made pursuant thereto.</li>\r\n<li>The Member shall not to use the Service for any unlawful purpose including without limitation criminal purposes.</li>\r\n<li>The Member shall not to use the Service to send or receive any message, which is offensive on moral, religious, racial or political grounds or of an offensive, vulgar, obscene, malicious or menacing nature.</li>\r\n<li>The Member shall be prohibited in persistently sending messages or make postings on FinanceJobNepal.com to any other Member or third party who access FinanceJobNepal.com without reasonable cause or for causing any peril, harassment, annoyance, irritation, or anxiety to any person.</li>\r\n<li>The Member is prohibited to introduce, upload, post, distribute, publish or transmit any information or software that:<br />a) Contains a virus, worm or other harmful component into the Internet or FinanceJobNepal.com network system.<br />b) Breaches on any intellectual property rights of any person or retain information in any computer system or otherwise with such intention.<br />c) Is unlawful, or which may potentially be perceived as being abusive, defamatory, libelous, harmful, threatening, harassing, vulgar, obscene, or racially, ethnically, or otherwise objectionable. <br />d) Is meant to mislead or deceive the other Members<br />e) Infringes any trademark, patent or copyright rights</li>\r\n</ul>\r\n<p>In the event of a violation of any of the above mentioned covenants by the Member, and same comes to the Company\'s knowledge, the Company shall have the right to delete any material relating to the violations without prior notice to the Member. The Company shall issue a warning to the Member to discontinue any activity, which leads to the said violations, and in the event the Member continues with such activity, the Company has the sole authority to terminate or suspend the membership at FinanceJobNepal.com and/or any other related facility. In addition to the right to indemnity available to the Company, the Company shall have the right to any legal remedy, against the Member to recover the loss suffered by the Company and the harm caused to the goodwill of the Company, due to such violation by the Member.</p>\r\n<p><strong>Copyright Policy</strong><br />You may not post, distribute, or reproduce in any way any copyrighted material, trademarks, or other proprietary information without obtaining the prior written consent of the owner of such proprietary rights. Without limiting the foregoing, if you believe that your work has been copied and posted on the FinanceJobNepal.com service in a way that constitutes copyright infringement, please inform us with the following information: an electronic or physical signature of the person authorized to act on behalf of the owner of the copyright interest; a description of the copyrighted work that you claim has been infringed; a description of where the material that you claim is infringing is located on the our Site; your address, telephone number, and email address; a written statement by you that you have a good faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law; a statement by you, made under penalty of perjury, that the above information in your Notice is accurate and that you are the copyright owner or authorized to act on the copyright owner\'s behalf.</p>\r\n<p><strong>Payment and Refund Policy</strong><br /><strong>Payment for memberships:</strong> <br />All payments for services at FinanceJobNepal.Com have to be made in favour of \"Finance Job Nepal Pvt. Ltd.\" only.</p>\r\n<p>We have not authorized any individual or organization to collect payments in any other name (i.e. any other individual or organization name) or via personal Western Union or personal electronic Accounts for any services rendered by FinanceJobNepal.Com. You are informed that under no circumstances will FinanceJobNepal.Com be liable for any damage caused due to your transactions / payments made to / in favor of such fraudulent individuals or organizations. To protect your interests, please contact us immediately if any such fraudulent individual or organization tries to mislead you.</p>\r\n<p>The Member, who is liable to pay Subscription Fees, shall pay it on demand even if the Member disputes the same for any reason. In the event that the Company deciding the dispute to be in the Member\'s favor, the Company shall refund to the Member any excess amount paid by the Member free of interest. In the event of late payment by the Member of any sums due under this Agreement, the Membership and the services would stand terminated.</p>\r\n<p><strong>Confidentiality</strong><br />As FinanceJobNepal.com is an online platform so it cannot guarantee confidentiality of information provided by Members who use the Site, so any breach in privacy due to technical fault or any other means is not the responsibility of FinanceJobNepal.com.</p>\r\n<p>The agreement between Finance Job Nepal.com and the Member can neither be deemed as \"non-poach agreement\" nor can the same be termed or used as an alternative to \"non-poach agreement\" as FinanceJobNepal.com being a public site, all information posted by Member on the Site goes to the public domain except information / data which is specifically assigned as a non-public / private character.</p>\r\n<p>The Member is entitled access to his own data and information stored in the database at FinanceJobNepal.com (subject to prior confirmation of identity) and may edit or amend such data and information at any time.</p>\r\n<p>The Members need to be aware that when they voluntarily reveal identification oriented information (name, e-mail address) in chat and bulletin board areas, such information may be collected by a third party resulting in unsolicited messages from third parties. Such interaction is beyond the control and liability of FinanceJobNepal.com. FinanceJob Nepal.com is liable to share all information available with it in response to any legal proceedings including and not restricted to court orders, notices, subpoena, FIR etc.</p>\r\n<p>The copyright, know how or any other related intellectual property to the Service or FinanceJobNepal.com shall be the sole and exclusive property of the Company. In the event the Member has contributed any content to FinanceJobNepal.com in any manner whatsoever, the intellectual property of the same shall stand automatically assigned to the Company and the Member shall have no right or claim over the same. In the event the Member during the term of his agreement or any time thereafter, uses such intellectual property in any other website or related activity, the same can be construed to be an infringement of the intellectual property belonging to the Company and the Company shall have the right to legal recourse in this regard.</p>\r\n<p><strong>Maintenance of Service</strong><br />The Company may at any time deactivate or suspend the Member\'s access to FinanceJobNepal.com and/or the Services (as the case may be) without any prior notice in order to carry out system maintenance, upgrading, testing, repairs and other related work. Without prejudice to the other provisions of this Agreement, the Company shall not be liable for any loss and damage, costs and expense that the Member may suffer or incur, and no fees or charges payable by the Member to the Company shall be deducted, refunded or rebated, as a result of such deactivation or suspension.</p>\r\n<p><strong>Modification to Service</strong><br />The Company reserves the right to modify or discontinue the Service with or without notice to the Member. Same for paid service, a pro-rated refund shall be effected for the remaining unused period.</p>\r\n<p>The Company shall not be liable to the Member or any third party should the Company exercise its right to modify or discontinue the Service.</p>\r\n<p><strong>Suspension of Service</strong><br />Without prejudice to any other rights or remedies of the Company, the Company may suspend the Service provided by the Company in the event that any dues payable by the Member are not paid.</p>\r\n<p>Upon suspension, the Service shall be deemed to be terminated from the date stipulated by the Company and the Member shall be liable for all charges and fees incurred until that date.</p>\r\n<p>Upon subsequent payment by the Member of the requisite payment as per the Company\'s demands, the Company may at its sole discretion and subject to such terms as it deems proper, reconnect the Service.</p>\r\n<p>FinanceJobNepal reserves the right to block the job posted by the Member in case, any of the following is found:</p>\r\n<ul>\r\n<li>Objectionable Contents includes: Offensive, abusive, threatening, obscene, defamatory or libelous materials.</li>\r\n<li>Multiple Profiles includes: A job opening would cater to a single requirement only. The Member is being allowed to post a single requirement in multiple categories, however only a single profile is allowed for each job opening.</li>\r\n<li>Contact Information includes: Any email address, phone numbers, postal address and any other means of contact material is prohibited in job details.</li>\r\n</ul>\r\n<p><strong>Termination of Service</strong><br />The Company may terminate this Agreement with immediate effect, without prior notice to the Member and without further prejudice to all other rights:</p>\r\n<ul>\r\n<li>If in the opinion of the Company, the Member has breached any of the terms or conditions of this agreement.</li>\r\n<li>If in the opinion of the Company or any regulatory authority, it is not in the public interest to continue providing the Service to the Member for any reason.</li>\r\n<li>If the Member is declared bankrupt or the Member enters into any compromise or arrangement with its creditors.</li>\r\n<li>The Member hereby undertakes that :<br />\r\n<ul>\r\n<li>They are fully authorized and solely responsible for all the job openings and associated information advertised by them at FinanceJobNepal.Com.</li>\r\n<li>They would ensure that all job openings advertised or sought to be filled by using the Services of FinanceJobNepal.Com are genuine and in existence.</li>\r\n<li>The Services of FinanceJobNepal.Com would be used for solely fulfilling genuine job openings and never be exploited for any other commercial purpose.</li>\r\n<li>All correspondence with the jobseekers would be done on ethical grounds without any sort of impersonation or provision of fraudulent information.</li>\r\n</ul>\r\n</li>\r\n<li>In case any Member is found to be in violation of the above undertaken, then FinanceJobNepal.Com is fully authorized to terminate the membership / suspend any or all the services and take any necessary legal action befitting the situation.</li>\r\n<li>The following could be deemed as the reason for the termination of the services:<br />\r\n<ul>\r\n<li>harasses or advocates harassment of another person;</li>\r\n<li>is patently offensive to the online community, any such content that promotes racism, bigotry, hatred or physical harm of any kind against any group or individual;</li>\r\n<li>involves unsolicited mass mailing or \"spamming\", the transmission of \"junk mail\", \"chain letters\", &ldquo;Unsolicited Bulk Messages&rdquo;, &ldquo;Unsolicited Commercial Communications&rdquo;, &ldquo;Non-job related mails&rdquo;, &ldquo;Mails soliciting payments&rdquo;, &ldquo;Fraudulent Mails&rdquo;</li>\r\n<li>promotes any information that is misleading, is false or that promotes illegal activities or conduct that is abusive, threatening, obscene, defamatory or libelous;</li>\r\n<li>promotes unauthorized or an illegal copy of another person\'s copyrighted work, such as providing pirated computer programs or links to them, providing information to circumvent manufacture-installed copy-protect devices;</li>\r\n<li>contains restricted or password only access pages, or hidden pages or images (those not linked to or from another accessible page);</li>\r\n<li>displays pornographic or obscene or sexually explicit material of any kind;<br />provides any kind of instructional information about illegal activities such as violating someone\'s privacy, making or buying illegal weapons, or providing or creating computer viruses, or hacking;</li>\r\n<li>solicits passwords or personal identifying information for commercial or unlawful purposes from other Members;</li>\r\n</ul>\r\n</li>\r\n<li>Finance Job Nepal also reserves all rights to suspend or terminate the services if found the services is not being used as per the mentioned instructions or the case may be.</li>\r\n</ul>\r\n<p>Disclaimer</p>\r\n<ul>\r\n<li>The Company shall not be liable for any loss of information howsoever caused whether as a result of any interruption, suspension, or termination of the Service or otherwise, or for the contents, accuracy or quality of information available, received or transmitted through the Service.</li>\r\n<li>The Member shall be solely responsible, and the Company shall not be liable in any manner whatsoever, for ensuring that in using the Service, all applicable laws, rules and regulations for the use of systems, service or equipment shall be at all times complied with.</li>\r\n<li>The Company makes no representations and warranties of any kind, whether expressed or implied, for the Services and in relation to the accuracy or quality of any information transmitted or obtained through the Services of FinanceJobNepal.com.</li>\r\n<li>The Company\'s liability under this Agreement shall not in any event exceed the total amount of fees and charges paid by the Member to the Company for the period immediately preceding two (2) months prior to the incident that has resulted in the relevant claim.</li>\r\n<li>The Company shall not be liable for any loss or damages sustained by reason of any disclosure (inadvertent or otherwise) of any information concerning the Member\'s account and particulars nor for any error, omission or inaccuracy with respect to any information so disclosed.</li>\r\n<li>The Company neither guarantees nor offers any warranty about the credentials, status or authenticity of the prospective employer/organization contacting the Members post download of the resume or by access to the information/data posted by the Members.</li>\r\n<li>The Company does not warrant that FinanceJobNepal.com or any of the web sites linked to FinanceJobNepal.com be free of any operational errors or that it will be free of any virus, worm, or other harmful component.</li>\r\n<li>The Member acknowledges that it is not the Company\'s policy to exercise editorial control over and to edit or amend any data or contents of any emails or posting or any information that may be inserted or made available or transmitted to a third party in or through FinanceJobNepal.com. The Company may refuse, suspend, terminate, delete or amend any artwork, materials, information or content of any data or information or posting so as, in the sole opinion of the Company, to comply with the legal or moral obligations as placed on the Company and to avoid infringing a third party\'s rights or any other rules, standards or codes of practices that may be applicable to the posting or FinanceJobNepal.com or the internet.</li>\r\n<li>It is the sole prerogative and responsibility of the Member to check the authenticity of all or any response/ inquiry received or information displayed. FinanceJobNepal.Com is a public site with free access and assumes no liability for the quality and genuineness of responses.</li>\r\n<li>FinanceJobNepal.Com neither guarantees nor offers any warranty about the credentials of the contacted parties including prospective employer / consultant / visitor / job seeker / Member and it is for the members to test, analyze and verify the same at their own end.</li>\r\n<li>The resume / data fed by the Member can be updated by the Member alone and is solely their liability so FinanceJobNepal.com is not responsible for the updated status of the information.</li>\r\n</ul>\r\n<p><strong>Use of Data</strong><br />The Member hereby agrees and irrevocably authorizes the Company to:</p>\r\n<ul>\r\n<li>Use any data and information supplied by the Member in connection with this Agreement for the Company\'s own purpose, to the company supplying such data and information to any other associated companies or selected third parties including search engines.</li>\r\n<li>Use any data furnished by the Member in order to float offers or send mails regarding specific services and such mails may not been proclaimed or deemed to be unsolicited communique.</li>\r\n<li>Allow all data and information supplied by the Member in using the Service to remain at FinanceJobNepal.com for the use of the Company in accordance with service agreement with the Member, notwithstanding the termination or suspension of the Service to the Member herein. Unless the Member informs the Company to delete all such dataand information following the termination or suspension of the Service to the Member, such data and information remain in the Company\'s property, records and databases.</li>\r\n</ul>\r\n<p><strong>Indemnity</strong><br />You agree to indemnify and hold Finance Job Nepal.com, its subsidiaries, affiliates, officers, agents, and other partners and employees, harmless from any loss, liability, claim, or demand, including reasonable attorney\'s fees, made by any third party due to or arising out of your use of the Service in violation of this Agreement and/or arising from a breach of these Terms of Use and/or any breach of your representations and warranties set forth above.</p>\r\n<p><strong>Variation</strong><br />The Company reserves the right to amend the terms and conditions contained herein and in the Services Guide at any time upon notice (in such form as may be determined by the Company) to the Member.</p>\r\n<p>The Terms and Conditions of this agreement will be updated from time to time and posted at Finance Job Nepal.com. The Member should visit the site periodically to review the Terms and Conditions. For the avoidance of doubt, the Member\'s continued use of the Service constitutes an affirmation and acknowledgement of the amended terms and conditions.</p>\r\n<p><strong>RSS</strong><br />Finance Job Nepal.Com claims proprietary rights over the content being made available as RSS feeds from FinanceJob Nepal.Com, including the copyrights, trademarks etc. The Members would need to provide an acknowledgement to Finance Job Nepal.Com in connection with use of RSS feeds obtained from the website.</p>\r\n<p><strong>Limitation of Liability</strong></p>\r\n<ul>\r\n<li>FinanceJobNepal.com only offers a platform to showcase the openings and the resumes and has no role in any transaction or communications and hence shall not be liable for any loss or damage of any sort arising out of the use and/or temporary or permanent discontinuation of its services. Notwithstanding anything to the contrary contained herein, FinanceJobNepal.com, liability to you for any cause whatsoever, and regardless of the form of the action, will at all times be limited to the amount paid, if any, by you to Finance Job Nepal.com, for the Service during the term of membership.</li>\r\n<li>FinanceJobNepal.com being a public site with free access assumes no liability for the quality and genuineness of responses. Finance Job Nepal cannot monitor the responses received by any Member in response to the information posted by them and so displayed on the site. Member should conduct its own background checks on the bonafide nature of all response(s). FinanceJobNepal.com will not be liable for any inaccuracy of information on this website.</li>\r\n<li>FinanceJobNepal.com expressly disclaims any liability arising due to presence of any fraudulent information published on the site.</li>\r\n<li>The Member is warned against disclosure of any personal / confidential / sensitive information to any previous or current employee of the company. The Member would do so solely at his / her own risk and Site / Company shall not be liable for the outcome of any such transaction of information including and not limited to damages for loss of profits or savings, business interruption, loss of information or repute.</li>\r\n<li>That there are certain free and paid features which may not be incorporated in the mobile application version though they are a part of the original website since the mobile apps are designed to be compact and light to ensure a smooth experience. Each Member hereby represents, warrants and agrees that the same shall be acceptable as a matter of fact and no requests to incorporate any such feature in the mobile app version would be initiated by the Members.</li>\r\n<li>The Member hereby agrees to take full responsibility to research well before making using of any information on the Site. FinanceJobNepal.com shall not be liable for any loss or damage of any sort arising out of the use and/or temporary or permanent discontinuation of its services. Notwithstanding anything to the contrary contained herein, FinanceJobNepal.com, liability to you for any cause whatsoever, and regardless of the form of the action, will at all times be limited to the amount paid, if any, by you to FinanceJobNepal.com, for the Service during the term of membership.</li>\r\n</ul>\r\n<p><strong>Member Disputes</strong><br />The Members are solely responsible for your interactions at Finance Job Nepal.com and FinanceJobNepal.com reserves the right, but has no obligation, to monitor disputes between Members.</p>\r\n<p>FinanceJobNepal.com will not be party to any legal proceedings between Member and any other registered or free Member for any transactions through the Site. FinanceJobNepal.com will always abide by governing / legal authorities order and cooperate fully through the process, but the costs of the same shall be recovered from the party that has implicated FinanceJobNepal.com in such case.</p>\r\n<p><strong>Matter of Disputes and Jurisdictional Aspects</strong><br />For any kind of legal dispute related to FinanceJobNepal.com would be dealt in only territory of Kathmandu. All the legal issues are subjected only to pertinent contemporary\'s laws in force at Kathmandu to the jurisdiction of courts located in Kathmandu only.</p>\r\n<p><strong>Governing Law and Jurisdiction</strong><br />This Agreement and any dispute or matter arising from incidental use FinanceJobNepal.com is governed by the laws of Nepal and the Member and the Company hereby submit to the exclusive jurisdiction of the courts at Kathmandu, Nepal. This Agreement, accepted upon use of the Site and further affirmed by becoming a Member of the FinanceJobNepal.com, contains the entire agreement between you and FinanceJobNepal.com regarding the use of the Site and/or the Service. If any provision of this Agreement is held invalid, the remainder of this Agreement shall continue in full force and effect.</p>', '2019-06-03 12:37:15', '2019-06-04 11:57:38', NULL, 'Y', 'Terms & Conditions for Employers', 'Terms & Conditions for Employers', 'Terms & Conditions for Employers'),
(3, 'privacy-and-policy', 'Privacy and Policy', '<p><strong>Overview</strong></p>\r\n<p>Finance Job Nepal Pvt. Ltd, and www.financejobnepal.com, are committed to respecting the privacy of our users. We strive to provide a safe, secure user experience. This Privacy Statement sets forth the online data collection and usage policies and practices that apply to the www.financejobnepal.com (sometimes referred to herein as the \"Finance Job Nepal Portal\") and does not apply to information we collect in any other fashion.</p>\r\n<p>Your data will be stored and processed in whole or in part in the United States. The information we gather on the www.financejobnepal.com will not be shared with any Third Party, without explicit written consent by you.</p>\r\n<p>The www.financejobnepal.com contains links to other Web sites over which we have no control. We are not responsible for the privacy policies or practices of other Web sites to which you choose to link from our Sites. We encourage you to review the privacy policies of those other Web sites so you can understand how they collect, use and share your information.</p>\r\n<p><strong>Collection and Use of Information by www.financejobnepal.com</strong></p>\r\n<p>In some areas of www.financejobnepal.com, we request or may request that you provide personal information, including your name, address, e-mail address, telephone number, credit card number, social security number, contact information, billing information and any other information from which your identity is discernible. In other areas, we collect or may collect demographic information that is not unique to you such as your ZIP code, age, preferences, gender, interests and favorites. Sometimes we collect or may collect a combination of the two types of information.</p>\r\n<p>We also gather or may gather general information about your use of www.financejobnepal.com such as what areas you visit and what services you access. Moreover, there is basic information about your computer hardware and software that is or may be collected by us. This information can include without limitation: your IP address, browser type, domain names, access times and referring Web site addresses, but is&nbsp;not linked&nbsp;to your personal information.</p>\r\n<p>We may sometimes afford you the opportunity to provide descriptive, cultural, behavioral, and preferential and/or life style information about yourself, but it is solely up to you whether you furnish such information. If you do provide such information, you are thereby consenting to the use of that information in accordance with the policies and practices described in this Privacy Statement. For example, such information may be used for the purpose of determining your potential interest in receiving e-mail or other communications about particular products or services.</p>\r\n<p><strong>Our Use of Your Information</strong></p>\r\n<p>We use the information we gather on www.financejobnepal.com, whether personal, demographic, collective or technical, for the purpose of operating and improving the www.financejobnepal.com, fostering a positive user experience, and delivering the products and services that we offer.</p>\r\n<p>If you have provided consent for us to do so, we may also use the information we gather to inform you of other products or services available from us or our affiliated companies or to contact you about your opinion of current products and services or potential new products and services that may be offered.</p>\r\n<p>We may use your contact information in order to send you e-mail or other communications regarding updates at the www.financejobnepal.com, and if you have requested, information on new www.financejobnepal.com opportunities and additional job postings which may be of interest to you. The nature and frequency of these messages will vary depending upon the information we have about you.</p>\r\n<p>In addition, at the time of registration, you have the option to elect to receive additional communications, information and promotions, including without limitation, free informational newsletters from us relating to topics that may be of special interest to you.</p>\r\n<p>We have areas on the www.financejobnepal.com where you can submit feedback. Any feedback you submit in these areas becomes our property, and we can use such feedback (such as success stories) for marketing purposes or to contact you for further information.</p>\r\n<p><strong>Choices Regarding the Disclosure of Personal Information to Others</strong></p>\r\n<p>We do not disclose your personal information to third parties, or your combined personal and demographic information or information about your use of www.financejobnepal.com (such as the areas you visit or the services you access), except as set forth below.</p>\r\n<ul>\r\n<li>We disclose information to companies and individuals we employ to perform functions on our behalf. Examples include hosting our Web servers, analyzing data, providing marketing assistance, processing credit card payments, and providing customer service. These companies and individuals will have access to your personal information as necessary to perform their functions, but they may not share that information with any other third party.</li>\r\n<li>We disclose information if legally required to do so, if requested to do so by a governmental entity or if we believe in good faith that such action is necessary to: (a) conform to legal requirements or comply with legal process; (b) protect our rights or property; (c) prevent a crime or protect national security; or (d) protect the personal safety of users or the public.</li>\r\n</ul>\r\n<p><strong>Other Uses of Information</strong></p>\r\n<p>We also share aggregated anonymous information about visitors to www.financejobnepal.com (for example, the number of visitors) with its clients, partners and other third parties so that they can understand the kinds of visitors to the www.financejobnepal.com and how those visitors use the www.financejobnepal.com.</p>\r\n<p>If you apply for a position via a contact listed on the www.financejobnepal.com, you may be asked to provide information on your gender, race or other protected status where permitted by applicable law. Some employers are required by law to gather this information from job applicants for reporting and record-keeping requirements. You should understand that if provided, this information will be used by employers only in accordance with applicable law and will not be used in making any negative employment decisions. All information provided will be kept separate from your expression of interest in any job opportunity. Providing this information is strictly voluntary and you will not be subject to any adverse action or treatment if you choose not to provide this information.</p>\r\n<p><strong>Use of Cookies</strong></p>\r\n<p>We use \"cookies\" to help personalize and maximize your online experience and time online. A cookie is a text file that is placed on your hard drive by a Web page server. Cookies are not used to run programs or deliver viruses to your computer. Cookies are uniquely assigned to your computer, and can only be read by a Web server in the domain that issued the cookie to you.</p>\r\n<p>One of the primary purposes of cookies is to provide a convenience feature to save you time. The purpose of a cookie is to tell the Web server that you have returned to a specific page. For example, if you register, a cookie helps us to recall your specific information (such as user name, password and preferences). Because of our use of cookies, we can deliver faster and more accurate results and a more personalized site experience. When you return to www.financejobnepal.com, the information you previously provided can be retrieved, so you can easily use the features that you customized. We also use cookies to track click streams and for load balancing.</p>\r\n<p>You may have the ability to accept or decline cookies. Most Web browsers automatically accept cookies, but you can usually modify your browser setting to decline all cookies if you prefer. Alternatively, you may be able to modify your browser setting to notify you each time a cookie is tendered and permit you to accept or decline cookies on an individual basis. If you choose to decline cookies, however, that may hinder performance and negatively impact your experience on www.financejobnepal.com.</p>\r\n<p><strong>Access to and Modification of Your Information</strong></p>\r\n<p>You may review, correct, update or change your account information at www.financejobnepal.com at any time.</p>\r\n<p><strong>Security of the Personal Information</strong></p>\r\n<p>We have implemented commercially reasonable technical and organizational measures designed to secure your personal information from accidental loss and from unauthorized access, use, alteration or disclosure. However, we cannot guarantee that unauthorized third parties will never be able to defeat those measures or use your personal information for improper purposes.</p>\r\n<p><strong>Changes to Privacy Statement</strong></p>\r\n<p>If we decide to materially change our Privacy Statement for the www.financejobnepal.com, we will post those changes through a prominent notice on the web site so that you will always know what information we gather, how we might use that information, and to whom we will disclose it.</p>\r\n<p>If at any time, you have questions or concerns about this Privacy Statement or believe that we have not adhered to this Privacy Statement, please feel free to email us at&nbsp;info@financejobnepal.com&nbsp;or call us at +9779851186360. We will use commercially reasonable efforts to promptly answer your question or resolve your problem.</p>\r\n<p><strong>Contact Information</strong></p>\r\n<p>www.financejobnepal.com is the name under which Finance Job Nepal Pvt. Ltd.,&nbsp;registered under Company Act, 2063 having office located at Bagdole, Lalitpur, Nepal.</p>\r\n<p>Thank you for using www.financejobnepal.com.</p>', '2019-06-04 11:29:50', '2019-06-04 11:31:42', NULL, 'Y', 'Privacy and Policy', 'Privacy and Policy', 'Privacy and Policy'),
(4, 'about-finance-job-nepal', 'About Finance Job Nepal', '<p>We are one of the leading HR Services company of Nepal managed by group of Chartered Accountants &amp; HR Experts. We combine our passion for people with intelligent technology to help organizations and talent convert potential into performance.</p>\r\n<p>Good relationships can start from a chance meeting or a shared interest. A true bond though, is built over time, by talking to one another, understanding each other, and sharing a dream or vision. You&rsquo;re probably thinking that you&rsquo;ve heard it all before and believe recruitment consultants are all the same &ndash; impersonal with a one size fits all approach, and yeah you&rsquo;re probably right, but we\'re here to change your mind.</p>\r\n<p>Our unique, ethically led approach to Accounts &amp; Finance recruitment meets the Industry expectations &amp; requirement for a truly sustainable recruitment solution. We have Profile of More than 10,000+ Accounts &amp; Finance People, Profile Includes experienced candidates holding degrees like (CA, ACCA, CFA, MBA, MBS, CPA, CFA, BBA, BBS etc.,) which can be best suited for your requirements.</p>\r\n<p>We&rsquo;re not just going to flick you CVs. Whatever your industry, whether it is an Entry level or C-suite position, our aim is to minimize your hiring risk, save you time and get to know your business. We want to understand the skill sets and experience that drive your workforce to succeed.</p>\r\n<p>Our people try, improve and perfect. We value open and honest communication with you. We believe our industry needs to move forward, and we want to be the ones who push the boundaries and challenge the somewhat low expectations of our profession. Being a partner rather than just a supplier will get the best out of us. Then we won&rsquo;t just recruit, we&rsquo;ll also be an extension of your employer brand. We&rsquo;ll think up the best ways to tell your story and customize our recruitment process in order to attract the right talent in Accounts &amp; Finance Domain.</p>', '2019-06-04 12:00:08', '2019-06-04 12:00:29', NULL, 'Y', 'About Finance Job Nepal', 'About Finance Job Nepal', 'About Finance Job Nepal');

-- --------------------------------------------------------

--
-- Table structure for table `country2code`
--

CREATE TABLE `country2code` (
  `id` int(11) NOT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `country_code2` varchar(5) DEFAULT NULL,
  `country_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country2code`
--

INSERT INTO `country2code` (`id`, `country_code`, `country_code2`, `country_name`) VALUES
(1, 'GB', 'GBR', 'UNITED KINGDOM'),
(2, 'US', 'USA', 'UNITED STATES'),
(3, 'BM', 'BMU', 'BERMUDA'),
(5, 'SE', 'SWE', 'SWEDEN'),
(7, 'IT', 'ITA', 'ITALY'),
(12, 'CA', 'CAN', 'CANADA'),
(17, 'PR', 'PRI', 'PUERTO RICO'),
(46, 'BO', 'BOL', 'BOLIVIA'),
(98, 'NL', 'NLD', 'NETHERLANDS'),
(105, 'DE', 'DEU', 'GERMANY'),
(107, 'CH', 'CHE', 'SWITZERLAND'),
(121, 'FR', 'FRA', 'FRANCE'),
(123, 'IL', 'ISR', 'ISRAEL'),
(127, 'ES', 'ESP', 'SPAIN'),
(236, 'CL', 'CHL', 'CHILE'),
(269, 'BS', 'BHS', 'BAHAMAS'),
(272, 'AR', 'ARG', 'ARGENTINA'),
(284, 'DM', 'DMA', 'DOMINICA'),
(298, 'BE', 'BEL', 'BELGIUM'),
(310, 'IE', 'IRL', 'IRELAND'),
(316, 'BZ', 'BLZ', 'BELIZE'),
(317, 'BR', 'BRA', 'BRAZIL'),
(319, 'MX', 'MEX', 'MEXICO'),
(349, 'JP', 'JPN', 'JAPAN'),
(359, 'IN', 'IND', 'INDIA'),
(361, 'AU', 'AUS', 'AUSTRALIA'),
(362, 'TH', 'THA', 'THAILAND'),
(364, 'CN', 'CHN', 'CHINA'),
(365, 'MY', 'MYS', 'MALAYSIA'),
(366, 'PK', 'PAK', 'PAKISTAN'),
(367, 'NZ', 'NZL', 'NEW ZEALAND'),
(368, 'KR', 'KOR', 'REPUBLIC OF KOREA'),
(371, 'HK', 'HKG', 'HONG KONG'),
(372, 'SG', 'SGP', 'SINGAPORE'),
(376, 'BD', 'BGD', 'BANGLADESH'),
(378, 'ID', 'IDN', 'INDONESIA'),
(383, 'PH', 'PHL', 'PHILIPPINES'),
(395, 'TW', 'TWN', 'TAIWAN'),
(432, 'AF', 'AFG', 'AFGHANISTAN'),
(453, 'VN', 'VNM', 'VIET NAM'),
(515, 'PA', 'PAN', 'PANAMA'),
(546, 'NC', 'NCL', 'NEW CALEDONIA'),
(549, 'BN', 'BRN', 'BRUNEI DARUSSALAM'),
(790, 'GR', 'GRC', 'GREECE'),
(792, 'SA', 'SAU', 'SAUDI ARABIA'),
(799, 'PL', 'POL', 'POLAND'),
(861, 'CZ', 'CZE', 'CZECH REPUBLIC'),
(864, 'RU', 'RUS', 'RUSSIAN FEDERATION'),
(874, 'DK', 'DNK', 'DENMARK'),
(875, 'NG', 'NGA', 'NIGERIA'),
(876, 'ZW', 'ZWE', 'ZIMBABWE'),
(882, 'IQ', 'IRQ', 'IRAQ'),
(886, 'FI', 'FIN', 'FINLAND'),
(888, 'IR', 'IRN', 'ISLAMIC REPUBLIC OF IRAN'),
(897, 'AE', 'ARE', 'UNITED ARAB EMIRATES'),
(903, 'GH', 'GHA', 'GHANA'),
(904, 'GA', 'GAB', 'GABON'),
(907, 'UG', 'UGA', 'UGANDA'),
(910, 'SD', 'SDN', 'SUDAN'),
(912, 'CY', 'CYP', 'CYPRUS'),
(917, 'NO', 'NOR', 'NORWAY'),
(923, 'AT', 'AUT', 'AUSTRIA'),
(925, 'UA', 'UKR', 'UKRAINE'),
(927, 'TJ', 'TJK', 'TAJIKISTAN'),
(2277, 'PT', 'PRT', 'PORTUGAL'),
(2278, 'TR', 'TUR', 'TURKEY'),
(2287, 'GE', 'GEO', 'GEORGIA'),
(2290, 'BY', 'BLR', 'BELARUS'),
(2311, 'AM', 'ARM', 'ARMENIA'),
(2322, 'LB', 'LBN', 'LEBANON'),
(2326, 'MD', 'MDA', 'REPUBLIC OF MOLDOVA'),
(2398, 'BG', 'BGR', 'BULGARIA'),
(2479, 'MZ', 'MOZ', 'MOZAMBIQUE'),
(2502, 'AO', 'AGO', 'ANGOLA'),
(2507, 'KE', 'KEN', 'KENYA'),
(2509, 'CD', 'COD', 'THE DEMOCRATIC REPUBLIC OF THE CONGO'),
(2510, 'MG', 'MDG', 'MADAGASCAR'),
(2512, 'TZ', 'TZA', 'UNITED REPUBLIC OF TANZANIA'),
(2515, 'TG', 'TGO', 'TOGO'),
(2523, 'ZM', 'ZMB', 'ZAMBIA'),
(2530, 'CM', 'CMR', 'CAMEROON'),
(3828, 'OM', 'OMN', 'OMAN'),
(3853, 'LV', 'LVA', 'LATVIA'),
(3856, 'KZ', 'KAZ', 'KAZAKHSTAN'),
(3879, 'EE', 'EST', 'ESTONIA'),
(3882, 'SK', 'SVK', 'SLOVAKIA'),
(3949, 'BA', 'BIH', 'BOSNIA AND HERZEGOVINA'),
(3951, 'HU', 'HUN', 'HUNGARY'),
(3955, 'KW', 'KWT', 'KUWAIT'),
(4192, 'AL', 'ALB', 'ALBANIA'),
(4264, 'LT', 'LTU', 'LITHUANIA'),
(4427, 'SM', 'SMR', 'SAN MARINO'),
(5143, 'RO', 'ROM', 'ROMANIA'),
(5178, 'CS', 'SCG', 'SERBIA AND MONTENEGRO'),
(5683, 'MA', 'MAR', 'MOROCCO'),
(5731, 'LU', 'LUX', 'LUXEMBOURG'),
(5767, 'DZ', 'DZA', 'ALGERIA'),
(5792, 'IS', 'ISL', 'ICELAND'),
(5883, 'CR', 'CRI', 'COSTA RICA'),
(6017, 'MK', 'MKD', 'THE FORMER YUGOSLAV REPUBLIC OF MACEDONIA'),
(6245, 'MT', 'MLT', 'MALTA'),
(6252, 'GM', 'GMB', 'GAMBIA'),
(6286, 'SZ', 'SWZ', 'SWAZILAND'),
(6491, 'ZA', 'ZAF', 'SOUTH AFRICA'),
(7222, 'MW', 'MWI', 'MALAWI'),
(7457, 'FK', 'FLK', 'FALKLAND ISLANDS (MALVINAS)'),
(7514, 'BH', 'BHR', 'BAHRAIN'),
(7537, 'UZ', 'UZB', 'UZBEKISTAN'),
(7552, 'AZ', 'AZE', 'AZERBAIJAN'),
(7563, 'EG', 'EGY', 'EGYPT'),
(7740, 'MC', 'MCO', 'MONACO'),
(7790, 'HT', 'HTI', 'HAITI'),
(7795, 'GU', 'GUM', 'GUAM'),
(7801, 'FM', 'FSM', 'FEDERATED STATES OF MICRONESIA'),
(7809, 'CO', 'COL', 'COLOMBIA'),
(7821, 'LR', 'LBR', 'LIBERIA'),
(7831, 'EC', 'ECU', 'ECUADOR'),
(7872, 'KY', 'CYM', 'CAYMAN ISLANDS'),
(7875, 'PE', 'PER', 'PERU'),
(7919, 'HN', 'HND', 'HONDURAS'),
(7923, 'SL', 'SLE', 'SIERRA LEONE'),
(7991, 'ML', 'MLI', 'MALI'),
(8005, 'LC', 'LCA', 'SAINT LUCIA'),
(8055, 'NI', 'NIC', 'NICARAGUA'),
(8057, 'DO', 'DOM', 'DOMINICAN REPUBLIC'),
(8063, 'AN', 'ANT', 'NETHERLANDS ANTILLES'),
(8073, 'GT', 'GTM', 'GUATEMALA'),
(8206, 'TT', 'TTO', 'TRINIDAD AND TOBAGO'),
(8354, 'BV', 'BVT', 'BOUVET ISLAND'),
(8377, 'VE', 'VEN', 'VENEZUELA'),
(8416, 'WS', 'WSM', 'SAMOA'),
(8421, 'MH', 'MHL', 'MARSHALL ISLANDS'),
(8504, 'PW', 'PLW', 'PALAU'),
(8558, 'BB', 'BRB', 'BARBADOS'),
(8618, 'MP', 'MNP', 'NORTHERN MARIANA ISLANDS'),
(8792, 'GD', 'GRD', 'GRENADA'),
(8793, 'VC', 'VCT', 'SAINT VINCENT AND THE GRENADINES'),
(8968, 'SV', 'SLV', 'EL SALVADOR'),
(8973, 'JM', 'JAM', 'JAMAICA'),
(8997, 'CU', 'CUB', 'CUBA'),
(9017, 'TC', 'TCA', 'TURKS AND CAICOS ISLANDS'),
(9061, 'CG', 'COG', 'CONGO'),
(9318, 'PY', 'PRY', 'PARAGUAY'),
(9326, 'RW', 'RWA', 'RWANDA'),
(9336, 'SR', 'SUR', 'SURINAME'),
(9339, 'GY', 'GUY', 'GUYANA'),
(9577, 'PG', 'PNG', 'PAPUA NEW GUINEA'),
(9647, 'KN', 'KNA', 'SAINT KITTS AND NEVIS'),
(9675, 'AG', 'ATG', 'ANTIGUA AND BARBUDA'),
(9689, 'GI', 'GIB', 'GIBRALTAR'),
(9775, 'AW', 'ABW', 'ARUBA'),
(9820, 'UY', 'URY', 'URUGUAY'),
(9893, 'JO', 'JOR', 'JORDAN'),
(10238, 'SY', 'SYR', 'SYRIAN ARAB REPUBLIC'),
(10364, 'UM', 'UMI', 'UNITED STATES MINOR OUTLYING ISLANDS'),
(11042, 'SI', 'SVN', 'SLOVENIA'),
(11133, 'MU', 'MUS', 'MAURITIUS'),
(11176, 'NE', 'NER', 'NIGER'),
(11476, 'KG', 'KGZ', 'KYRGYZSTAN'),
(11477, 'TM', 'TKM', 'TURKMENISTAN'),
(11524, 'HR', 'HRV', 'CROATIA'),
(12106, 'GN', 'GIN', 'GUINEA'),
(12108, 'MM', 'MMR', 'MYANMAR'),
(12118, 'BJ', 'BEN', 'BENIN'),
(12120, 'CF', 'CAF', 'CENTRAL AFRICAN REPUBLIC'),
(12122, 'ET', 'ETH', 'ETHIOPIA'),
(12123, 'NP', 'NPL', 'NEPAL'),
(12126, 'BT', 'BTN', 'BHUTAN'),
(12155, 'QA', 'QAT', 'QATAR'),
(12176, 'NA', 'NAM', 'NAMIBIA'),
(12409, 'BW', 'BWA', 'BOTSWANA'),
(12434, 'TD', 'TCD', 'CHAD'),
(12992, 'RE', 'REU', 'REUNION'),
(13016, 'SO', 'SOM', 'SOMALIA'),
(13034, 'BI', 'BDI', 'BURUNDI'),
(13044, 'FO', 'FRO', 'FAROE ISLANDS'),
(13111, 'LS', 'LSO', 'LESOTHO'),
(13115, 'MR', 'MRT', 'MAURITANIA'),
(13124, 'NR', 'NRU', 'NAURU'),
(13862, 'LY', 'LBY', 'LIBYAN ARAB JAMAHIRIYA'),
(13937, 'KM', 'COM', 'COMOROS'),
(14077, 'LI', 'LIE', 'LIECHTENSTEIN'),
(14349, 'SC', 'SYC', 'SEYCHELLES'),
(14537, 'LA', 'LAO', 'LAO PEOPLES DEMOCRATIC REPUBLIC'),
(14539, 'LK', 'LKA', 'SRI LANKA'),
(15134, 'TN', 'TUN', 'TUNISIA'),
(15377, 'MQ', 'MTQ', 'MARTINIQUE'),
(15386, 'GP', 'GLP', 'GUADELOUPE'),
(15881, 'VA', 'VAT', 'HOLY SEE (VATICAN CITY STATE)'),
(16119, 'YE', 'YEM', 'YEMEN'),
(17815, 'YT', 'MYT', 'MAYOTTE'),
(17955, 'BF', 'BFA', 'BURKINA FASO'),
(19155, 'AQ', 'ATA', 'ANTARCTICA'),
(19367, 'KH', 'KHM', 'CAMBODIA'),
(19382, 'MV', 'MDV', 'MALDIVES'),
(19572, 'MO', 'MAC', 'MACAO'),
(19665, 'WF', 'WLF', 'WALLIS AND FUTUNA'),
(19927, 'MN', 'MNG', 'MONGOLIA'),
(20046, 'FJ', 'FJI', 'FIJI'),
(20343, 'VU', 'VUT', 'VANUATU'),
(20502, 'PF', 'PYF', 'FRENCH POLYNESIA'),
(37111, 'GQ', 'GNQ', 'EQUATORIAL GUINEA'),
(37537, 'DJ', 'DJI', 'DJIBOUTI'),
(39188, 'GW', 'GNB', 'GUINEA-BISSAU'),
(39980, 'SN', 'SEN', 'SENEGAL'),
(41750, 'PS', 'PSE', 'PALESTINIAN TERRITORY, OCCUPIED'),
(41824, 'AD', 'AND', 'ANDORRA'),
(44897, 'GL', 'GRL', 'GREENLAND'),
(46296, 'CV', 'CPV', 'CAPE VERDE'),
(46297, 'ST', 'STP', 'SAO TOME AND PRINCIPE'),
(57574, 'MS', 'MSR', 'MONTSERRAT'),
(58292, 'TF', 'ATF', 'FRENCH SOUTHERN TERRITORIES'),
(58517, 'GF', 'GUF', 'FRENCH GUIANA'),
(59439, 'GS', 'SGS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS'),
(59511, 'SB', 'SLB', 'SOLOMON ISLANDS'),
(59525, 'TV', 'TUV', 'TUVALU'),
(59615, 'KI', 'KIR', 'KIRIBATI'),
(59968, 'TO', 'TON', 'TONGA'),
(59991, 'IO', 'IOT', 'BRITISH INDIAN OCEAN TERRITORY'),
(60199, 'CK', 'COK', 'COOK ISLANDS'),
(60249, 'AS', 'ASM', 'AMERICAN SAMOA'),
(60276, 'TL', 'TLS', 'TIMOR-LESTE'),
(60278, 'TK', 'TKL', 'TOKELAU'),
(61485, 'NF', 'NFK', 'NORFOLK ISLAND'),
(62134, 'VG', 'VGB', 'VIRGIN ISLANDS, BRITISH'),
(62156, 'VI', 'VIR', 'VIRGIN ISLANDS, U.S.'),
(62261, 'AI', 'AIA', 'ANGUILLA'),
(72662, 'ER', 'ERI', 'ERITREA'),
(73648, 'CI', 'CIV', 'COTE D IVOIRE'),
(1, 'GB', 'GBR', 'UNITED KINGDOM'),
(2, 'US', 'USA', 'UNITED STATES'),
(3, 'BM', 'BMU', 'BERMUDA'),
(5, 'SE', 'SWE', 'SWEDEN'),
(7, 'IT', 'ITA', 'ITALY'),
(12, 'CA', 'CAN', 'CANADA'),
(17, 'PR', 'PRI', 'PUERTO RICO'),
(46, 'BO', 'BOL', 'BOLIVIA'),
(98, 'NL', 'NLD', 'NETHERLANDS'),
(105, 'DE', 'DEU', 'GERMANY'),
(107, 'CH', 'CHE', 'SWITZERLAND'),
(121, 'FR', 'FRA', 'FRANCE'),
(123, 'IL', 'ISR', 'ISRAEL'),
(127, 'ES', 'ESP', 'SPAIN'),
(236, 'CL', 'CHL', 'CHILE'),
(269, 'BS', 'BHS', 'BAHAMAS'),
(272, 'AR', 'ARG', 'ARGENTINA'),
(284, 'DM', 'DMA', 'DOMINICA'),
(298, 'BE', 'BEL', 'BELGIUM'),
(310, 'IE', 'IRL', 'IRELAND'),
(316, 'BZ', 'BLZ', 'BELIZE'),
(317, 'BR', 'BRA', 'BRAZIL'),
(319, 'MX', 'MEX', 'MEXICO'),
(349, 'JP', 'JPN', 'JAPAN'),
(359, 'IN', 'IND', 'INDIA'),
(361, 'AU', 'AUS', 'AUSTRALIA'),
(362, 'TH', 'THA', 'THAILAND'),
(364, 'CN', 'CHN', 'CHINA'),
(365, 'MY', 'MYS', 'MALAYSIA'),
(366, 'PK', 'PAK', 'PAKISTAN'),
(367, 'NZ', 'NZL', 'NEW ZEALAND'),
(368, 'KR', 'KOR', 'REPUBLIC OF KOREA'),
(371, 'HK', 'HKG', 'HONG KONG'),
(372, 'SG', 'SGP', 'SINGAPORE'),
(376, 'BD', 'BGD', 'BANGLADESH'),
(378, 'ID', 'IDN', 'INDONESIA'),
(383, 'PH', 'PHL', 'PHILIPPINES'),
(395, 'TW', 'TWN', 'TAIWAN'),
(432, 'AF', 'AFG', 'AFGHANISTAN'),
(453, 'VN', 'VNM', 'VIET NAM'),
(515, 'PA', 'PAN', 'PANAMA'),
(546, 'NC', 'NCL', 'NEW CALEDONIA'),
(549, 'BN', 'BRN', 'BRUNEI DARUSSALAM'),
(790, 'GR', 'GRC', 'GREECE'),
(792, 'SA', 'SAU', 'SAUDI ARABIA'),
(799, 'PL', 'POL', 'POLAND'),
(861, 'CZ', 'CZE', 'CZECH REPUBLIC'),
(864, 'RU', 'RUS', 'RUSSIAN FEDERATION'),
(874, 'DK', 'DNK', 'DENMARK'),
(875, 'NG', 'NGA', 'NIGERIA'),
(876, 'ZW', 'ZWE', 'ZIMBABWE'),
(882, 'IQ', 'IRQ', 'IRAQ'),
(886, 'FI', 'FIN', 'FINLAND'),
(888, 'IR', 'IRN', 'ISLAMIC REPUBLIC OF IRAN'),
(897, 'AE', 'ARE', 'UNITED ARAB EMIRATES'),
(903, 'GH', 'GHA', 'GHANA'),
(904, 'GA', 'GAB', 'GABON'),
(907, 'UG', 'UGA', 'UGANDA'),
(910, 'SD', 'SDN', 'SUDAN'),
(912, 'CY', 'CYP', 'CYPRUS'),
(917, 'NO', 'NOR', 'NORWAY'),
(923, 'AT', 'AUT', 'AUSTRIA'),
(925, 'UA', 'UKR', 'UKRAINE'),
(927, 'TJ', 'TJK', 'TAJIKISTAN'),
(2277, 'PT', 'PRT', 'PORTUGAL'),
(2278, 'TR', 'TUR', 'TURKEY'),
(2287, 'GE', 'GEO', 'GEORGIA'),
(2290, 'BY', 'BLR', 'BELARUS'),
(2311, 'AM', 'ARM', 'ARMENIA'),
(2322, 'LB', 'LBN', 'LEBANON'),
(2326, 'MD', 'MDA', 'REPUBLIC OF MOLDOVA'),
(2398, 'BG', 'BGR', 'BULGARIA'),
(2479, 'MZ', 'MOZ', 'MOZAMBIQUE'),
(2502, 'AO', 'AGO', 'ANGOLA'),
(2507, 'KE', 'KEN', 'KENYA'),
(2509, 'CD', 'COD', 'THE DEMOCRATIC REPUBLIC OF THE CONGO'),
(2510, 'MG', 'MDG', 'MADAGASCAR'),
(2512, 'TZ', 'TZA', 'UNITED REPUBLIC OF TANZANIA'),
(2515, 'TG', 'TGO', 'TOGO'),
(2523, 'ZM', 'ZMB', 'ZAMBIA'),
(2530, 'CM', 'CMR', 'CAMEROON'),
(3828, 'OM', 'OMN', 'OMAN'),
(3853, 'LV', 'LVA', 'LATVIA'),
(3856, 'KZ', 'KAZ', 'KAZAKHSTAN'),
(3879, 'EE', 'EST', 'ESTONIA'),
(3882, 'SK', 'SVK', 'SLOVAKIA'),
(3949, 'BA', 'BIH', 'BOSNIA AND HERZEGOVINA'),
(3951, 'HU', 'HUN', 'HUNGARY'),
(3955, 'KW', 'KWT', 'KUWAIT'),
(4192, 'AL', 'ALB', 'ALBANIA'),
(4264, 'LT', 'LTU', 'LITHUANIA'),
(4427, 'SM', 'SMR', 'SAN MARINO'),
(5143, 'RO', 'ROM', 'ROMANIA'),
(5178, 'CS', 'SCG', 'SERBIA AND MONTENEGRO'),
(5683, 'MA', 'MAR', 'MOROCCO'),
(5731, 'LU', 'LUX', 'LUXEMBOURG'),
(5767, 'DZ', 'DZA', 'ALGERIA'),
(5792, 'IS', 'ISL', 'ICELAND'),
(5883, 'CR', 'CRI', 'COSTA RICA'),
(6017, 'MK', 'MKD', 'THE FORMER YUGOSLAV REPUBLIC OF MACEDONIA'),
(6245, 'MT', 'MLT', 'MALTA'),
(6252, 'GM', 'GMB', 'GAMBIA'),
(6286, 'SZ', 'SWZ', 'SWAZILAND'),
(6491, 'ZA', 'ZAF', 'SOUTH AFRICA'),
(7222, 'MW', 'MWI', 'MALAWI'),
(7457, 'FK', 'FLK', 'FALKLAND ISLANDS (MALVINAS)'),
(7514, 'BH', 'BHR', 'BAHRAIN'),
(7537, 'UZ', 'UZB', 'UZBEKISTAN'),
(7552, 'AZ', 'AZE', 'AZERBAIJAN'),
(7563, 'EG', 'EGY', 'EGYPT'),
(7740, 'MC', 'MCO', 'MONACO'),
(7790, 'HT', 'HTI', 'HAITI'),
(7795, 'GU', 'GUM', 'GUAM'),
(7801, 'FM', 'FSM', 'FEDERATED STATES OF MICRONESIA'),
(7809, 'CO', 'COL', 'COLOMBIA'),
(7821, 'LR', 'LBR', 'LIBERIA'),
(7831, 'EC', 'ECU', 'ECUADOR'),
(7872, 'KY', 'CYM', 'CAYMAN ISLANDS'),
(7875, 'PE', 'PER', 'PERU'),
(7919, 'HN', 'HND', 'HONDURAS'),
(7923, 'SL', 'SLE', 'SIERRA LEONE'),
(7991, 'ML', 'MLI', 'MALI'),
(8005, 'LC', 'LCA', 'SAINT LUCIA'),
(8055, 'NI', 'NIC', 'NICARAGUA'),
(8057, 'DO', 'DOM', 'DOMINICAN REPUBLIC'),
(8063, 'AN', 'ANT', 'NETHERLANDS ANTILLES'),
(8073, 'GT', 'GTM', 'GUATEMALA'),
(8206, 'TT', 'TTO', 'TRINIDAD AND TOBAGO'),
(8354, 'BV', 'BVT', 'BOUVET ISLAND'),
(8377, 'VE', 'VEN', 'VENEZUELA'),
(8416, 'WS', 'WSM', 'SAMOA'),
(8421, 'MH', 'MHL', 'MARSHALL ISLANDS'),
(8504, 'PW', 'PLW', 'PALAU'),
(8558, 'BB', 'BRB', 'BARBADOS'),
(8618, 'MP', 'MNP', 'NORTHERN MARIANA ISLANDS'),
(8792, 'GD', 'GRD', 'GRENADA'),
(8793, 'VC', 'VCT', 'SAINT VINCENT AND THE GRENADINES'),
(8968, 'SV', 'SLV', 'EL SALVADOR'),
(8973, 'JM', 'JAM', 'JAMAICA'),
(8997, 'CU', 'CUB', 'CUBA'),
(9017, 'TC', 'TCA', 'TURKS AND CAICOS ISLANDS'),
(9061, 'CG', 'COG', 'CONGO'),
(9318, 'PY', 'PRY', 'PARAGUAY'),
(9326, 'RW', 'RWA', 'RWANDA'),
(9336, 'SR', 'SUR', 'SURINAME'),
(9339, 'GY', 'GUY', 'GUYANA'),
(9577, 'PG', 'PNG', 'PAPUA NEW GUINEA'),
(9647, 'KN', 'KNA', 'SAINT KITTS AND NEVIS'),
(9675, 'AG', 'ATG', 'ANTIGUA AND BARBUDA'),
(9689, 'GI', 'GIB', 'GIBRALTAR'),
(9775, 'AW', 'ABW', 'ARUBA'),
(9820, 'UY', 'URY', 'URUGUAY'),
(9893, 'JO', 'JOR', 'JORDAN'),
(10238, 'SY', 'SYR', 'SYRIAN ARAB REPUBLIC'),
(10364, 'UM', 'UMI', 'UNITED STATES MINOR OUTLYING ISLANDS'),
(11042, 'SI', 'SVN', 'SLOVENIA'),
(11133, 'MU', 'MUS', 'MAURITIUS'),
(11176, 'NE', 'NER', 'NIGER'),
(11476, 'KG', 'KGZ', 'KYRGYZSTAN'),
(11477, 'TM', 'TKM', 'TURKMENISTAN'),
(11524, 'HR', 'HRV', 'CROATIA'),
(12106, 'GN', 'GIN', 'GUINEA'),
(12108, 'MM', 'MMR', 'MYANMAR'),
(12118, 'BJ', 'BEN', 'BENIN'),
(12120, 'CF', 'CAF', 'CENTRAL AFRICAN REPUBLIC'),
(12122, 'ET', 'ETH', 'ETHIOPIA'),
(12123, 'NP', 'NPL', 'NEPAL'),
(12126, 'BT', 'BTN', 'BHUTAN'),
(12155, 'QA', 'QAT', 'QATAR'),
(12176, 'NA', 'NAM', 'NAMIBIA'),
(12409, 'BW', 'BWA', 'BOTSWANA'),
(12434, 'TD', 'TCD', 'CHAD'),
(12992, 'RE', 'REU', 'REUNION'),
(13016, 'SO', 'SOM', 'SOMALIA'),
(13034, 'BI', 'BDI', 'BURUNDI'),
(13044, 'FO', 'FRO', 'FAROE ISLANDS'),
(13111, 'LS', 'LSO', 'LESOTHO'),
(13115, 'MR', 'MRT', 'MAURITANIA'),
(13124, 'NR', 'NRU', 'NAURU'),
(13862, 'LY', 'LBY', 'LIBYAN ARAB JAMAHIRIYA'),
(13937, 'KM', 'COM', 'COMOROS'),
(14077, 'LI', 'LIE', 'LIECHTENSTEIN'),
(14349, 'SC', 'SYC', 'SEYCHELLES'),
(14537, 'LA', 'LAO', 'LAO PEOPLES DEMOCRATIC REPUBLIC'),
(14539, 'LK', 'LKA', 'SRI LANKA'),
(15134, 'TN', 'TUN', 'TUNISIA'),
(15377, 'MQ', 'MTQ', 'MARTINIQUE'),
(15386, 'GP', 'GLP', 'GUADELOUPE'),
(15881, 'VA', 'VAT', 'HOLY SEE (VATICAN CITY STATE)'),
(16119, 'YE', 'YEM', 'YEMEN'),
(17815, 'YT', 'MYT', 'MAYOTTE'),
(17955, 'BF', 'BFA', 'BURKINA FASO'),
(19155, 'AQ', 'ATA', 'ANTARCTICA'),
(19367, 'KH', 'KHM', 'CAMBODIA'),
(19382, 'MV', 'MDV', 'MALDIVES'),
(19572, 'MO', 'MAC', 'MACAO'),
(19665, 'WF', 'WLF', 'WALLIS AND FUTUNA'),
(19927, 'MN', 'MNG', 'MONGOLIA'),
(20046, 'FJ', 'FJI', 'FIJI'),
(20343, 'VU', 'VUT', 'VANUATU'),
(20502, 'PF', 'PYF', 'FRENCH POLYNESIA'),
(37111, 'GQ', 'GNQ', 'EQUATORIAL GUINEA'),
(37537, 'DJ', 'DJI', 'DJIBOUTI'),
(39188, 'GW', 'GNB', 'GUINEA-BISSAU'),
(39980, 'SN', 'SEN', 'SENEGAL'),
(41750, 'PS', 'PSE', 'PALESTINIAN TERRITORY, OCCUPIED'),
(41824, 'AD', 'AND', 'ANDORRA'),
(44897, 'GL', 'GRL', 'GREENLAND'),
(46296, 'CV', 'CPV', 'CAPE VERDE'),
(46297, 'ST', 'STP', 'SAO TOME AND PRINCIPE'),
(57574, 'MS', 'MSR', 'MONTSERRAT'),
(58292, 'TF', 'ATF', 'FRENCH SOUTHERN TERRITORIES'),
(58517, 'GF', 'GUF', 'FRENCH GUIANA'),
(59439, 'GS', 'SGS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS'),
(59511, 'SB', 'SLB', 'SOLOMON ISLANDS'),
(59525, 'TV', 'TUV', 'TUVALU'),
(59615, 'KI', 'KIR', 'KIRIBATI'),
(59968, 'TO', 'TON', 'TONGA'),
(59991, 'IO', 'IOT', 'BRITISH INDIAN OCEAN TERRITORY'),
(60199, 'CK', 'COK', 'COOK ISLANDS'),
(60249, 'AS', 'ASM', 'AMERICAN SAMOA'),
(60276, 'TL', 'TLS', 'TIMOR-LESTE'),
(60278, 'TK', 'TKL', 'TOKELAU'),
(61485, 'NF', 'NFK', 'NORFOLK ISLAND'),
(62134, 'VG', 'VGB', 'VIRGIN ISLANDS, BRITISH'),
(62156, 'VI', 'VIR', 'VIRGIN ISLANDS, U.S.'),
(62261, 'AI', 'AIA', 'ANGUILLA'),
(72662, 'ER', 'ERI', 'ERITREA'),
(73648, 'CI', 'CIV', 'COTE D IVOIRE');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown`
--

CREATE TABLE `dropdown` (
  `id` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `dropvalue` varchar(50) NOT NULL,
  `ordering` int(11) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dropdown`
--

INSERT INTO `dropdown` (`id`, `fid`, `dropvalue`, `ordering`, `slug`, `image`) VALUES
(2, 9, 'Banks & Finance', 0, 'banks-finance', '3645banks-and-financial-institutions.jpg'),
(3, 9, 'FMCG Sector', 0, 'fmcg-sector', '7173fmcg-sector.jpg'),
(4, 9, 'Manufacturing', 0, 'manufacturing', '8310manufacturing.jpg'),
(5, 9, 'Education Sector', 0, 'education-sector', '6341education.jpg'),
(6, 9, 'Training & Consulting', 0, 'training-consulting', '9342training-and-consulting.jpg'),
(7, 9, 'Hospitality Sector', 0, 'hospitality-sector', '7017hospitality.jpg'),
(8, 9, 'Construction ', 0, 'construction', '8705construction.jpg'),
(9, 9, 'Agro-based Industry ', 0, 'agro-based-industry', '8963agro-based-industry.jpg'),
(10, 3, 'CA', 0, 'ca', ''),
(11, 3, 'MBA', 0, 'mba', ''),
(12, 3, 'Semi Qualified CA', 0, 'semi-qualified-ca', ''),
(13, 3, 'Master', 0, '', ''),
(14, 3, 'Bachelor', 0, 'bachelor', ''),
(15, 3, 'Intermediate (Plus 2)', 0, 'intermediate-plus-2', ''),
(17, 17, 'Entry Level', 0, '', ''),
(18, 17, 'Mid Level', 0, '', ''),
(19, 17, 'Senior Level', 0, '', ''),
(20, 17, 'Top Level', 0, '', ''),
(45, 2, 'Butwal', 0, 'butwal', ''),
(22, 16, 'Internship', 0, '', ''),
(23, 16, 'Full Time', 0, '', ''),
(24, 16, 'Part Time', 0, '', ''),
(25, 16, 'Contract', 0, '', ''),
(27, 7, 'No. of Employees (1-10)', 0, 'no-of-employees-1-10', ''),
(28, 4, 'No limit for deserving candidate', 0, 'no-limit-for-deserving-candidate', ''),
(29, 4, 'Rs. 15,000-Rs.30,000', 0, 'rs-15000-rs30000', ''),
(30, 4, 'Rs. 30,000-Rs. 50,000', 0, 'rs-30000-rs-50000', ''),
(31, 4, 'Rs. 50,000-Rs. 80,000', 0, 'rs-50000-rs-80000', ''),
(32, 4, 'Rs. 80,000-Rs. 1,20,000', 0, 'rs-80000-rs-120000', ''),
(33, 4, 'Rs. 1,20,000-Rs.1,50,000', 0, 'rs-120000-rs150000', ''),
(35, 7, 'No. of Employees (11-20)', 0, 'no-of-employees-11-20', ''),
(36, 7, 'No. of Employees (21-50)', 0, 'no-of-employees-21-50', ''),
(37, 7, 'No. of Employees (51-100)', 0, 'no-of-employees-51-100', ''),
(38, 7, 'No. of Employees (101-200)', 0, 'no-of-employees-101-200', ''),
(41, 2, 'Kathmandu', 0, 'kathmandu', ''),
(42, 2, 'Biratnagar', 0, 'biratnagar', ''),
(43, 2, 'Bhairawaha', 0, 'bhairawaha', ''),
(44, 2, 'Chitwan', 0, 'chitwan', ''),
(46, 2, 'Nepalgunj', 0, 'nepalgunj', ''),
(47, 2, 'Pokhara', 0, 'pokhara', ''),
(48, 2, 'Janakpur', 0, 'janakpur', ''),
(49, 2, 'Ghorahi	', 0, 'ghorahi', ''),
(50, 2, 'Hetauda	', 0, 'hetauda', ''),
(51, 2, 'Dhangadhi	', 0, 'dhangadhi', ''),
(52, 2, 'Tulsipur	', 0, 'tulsipur', ''),
(53, 2, 'Itahari	', 0, 'itahari', ''),
(54, 2, 'Dharan	', 0, 'dharan', ''),
(55, 2, 'Kalaiya	', 0, 'kalaiya', ''),
(56, 2, 'Jitpur Simara	', 0, 'jitpur-simara', ''),
(57, 2, 'Jhapa', 0, 'jhapa', ''),
(58, 2, 'Lalitpur', 0, 'lalitpur', ''),
(59, 2, 'Bhaktapur', 0, 'bhaktapur', ''),
(60, 2, 'Birendranagar	', 0, 'birendranagar', ''),
(61, 2, 'Godawari	', 0, 'godawari', ''),
(62, 2, 'Province No. 1	', 0, 'province-no-1', ''),
(63, 2, 'Province No. 2	', 0, 'province-no-2', ''),
(64, 2, 'Province No. 3	', 0, 'province-no-3', ''),
(65, 2, 'Province No. 4 (Gandaki)	', 0, 'province-no-4-gandaki', ''),
(66, 2, 'Province No. 5	', 0, 'province-no-5', ''),
(67, 2, 'Province No. 6 (Karnali)	', 0, 'province-no-6-karnali', ''),
(68, 2, 'Province No. 7 (Sudurpashchim)', 0, 'province-no-7-sudurpashchim', ''),
(69, 2, 'Mechi Zone', 0, 'mechi-zone', ''),
(70, 2, 'Koshi Zone', 0, 'koshi-zone', ''),
(71, 2, 'Sagarmatha Zone', 0, 'sagarmatha-zone', ''),
(72, 2, 'Janakpur Zone', 0, 'janakpur-zone', ''),
(73, 2, 'Bagmati Zone', 0, 'bagmati-zone', ''),
(74, 2, 'Narayani Zone', 0, 'narayani-zone', ''),
(75, 2, 'Gandaki Zone', 0, 'gandaki-zone', ''),
(76, 2, 'Lumbini Zone', 0, 'lumbini-zone', ''),
(77, 2, 'Dhaulagiri Zone', 0, 'dhaulagiri-zone', ''),
(78, 2, 'Rapti Zone', 0, 'rapti-zone', ''),
(79, 2, 'Karnali Zone', 0, 'karnali-zone', ''),
(80, 2, 'Bheri Zone', 0, 'bheri-zone', ''),
(81, 2, 'Seti Zone', 0, 'seti-zone', ''),
(82, 2, 'Mahakali Zone', 0, 'mahakali-zone', ''),
(83, 2, 'Bhojpur', 0, 'bhojpur', ''),
(84, 2, 'Dhankuta	', 0, 'dhankuta', ''),
(85, 2, 'Ilam', 0, 'ilam', ''),
(86, 2, 'Khotang', 0, 'khotang', ''),
(87, 2, 'Morang', 0, 'morang', ''),
(88, 2, 'Okhaldhunga', 0, 'okhaldhunga', ''),
(89, 2, 'Panchthar', 0, 'panchthar', ''),
(90, 2, 'Sankhuwasabha', 0, 'sankhuwasabha', ''),
(91, 2, 'Solukhumbu', 0, 'solukhumbu', ''),
(92, 2, 'Sunsari', 0, 'sunsari', ''),
(93, 2, 'Taplejung', 0, 'taplejung', ''),
(94, 2, 'Terhathum', 0, 'terhathum', ''),
(95, 2, 'Udayapur', 0, 'udayapur', ''),
(96, 2, 'Bara', 0, 'bara', ''),
(97, 2, 'Dhanusa', 0, 'dhanusa', ''),
(98, 2, 'Mahottari', 0, 'mahottari', ''),
(99, 2, 'Parsa', 0, 'parsa', ''),
(100, 2, 'Rautahat', 0, 'rautahat', ''),
(101, 2, 'Saptari', 0, 'saptari', ''),
(102, 2, 'Sarlahi', 0, 'sarlahi', ''),
(103, 2, 'Siraha', 0, 'siraha', ''),
(104, 2, 'Dhading', 0, 'dhading', ''),
(105, 2, 'Dolakha', 0, 'dolakha', ''),
(106, 2, 'Kavrepalanchok', 0, 'kavrepalanchok', ''),
(107, 2, 'Makwanpur', 0, 'makwanpur', ''),
(108, 2, 'Nuwakot', 0, 'nuwakot', ''),
(109, 2, 'Ramechhap', 0, 'ramechhap', ''),
(110, 2, 'Rasuwa', 0, 'rasuwa', ''),
(111, 2, 'Sindhuli', 0, 'sindhuli', ''),
(112, 2, 'Sindhupalchok', 0, 'sindhupalchok', ''),
(113, 2, 'Baglung', 0, 'baglung', ''),
(114, 2, 'Gorkha', 0, 'gorkha', ''),
(115, 2, 'Kaski', 0, 'kaski', ''),
(116, 2, 'Lamjung', 0, 'lamjung', ''),
(117, 2, 'Manang', 0, 'manang', ''),
(118, 2, 'Mustang', 0, 'mustang', ''),
(119, 2, 'Myagdi', 0, 'myagdi', ''),
(120, 2, 'Nawalpur', 0, 'nawalpur', ''),
(121, 2, 'Parbat', 0, 'parbat', ''),
(122, 2, 'Syangja', 0, 'syangja', ''),
(123, 2, 'Tanahun', 0, 'tanahun', ''),
(124, 2, 'Arghakhanchi', 0, 'arghakhanchi', ''),
(125, 2, 'Banke', 0, 'banke', ''),
(126, 2, 'Bardiya', 0, 'bardiya', ''),
(127, 2, 'Dang', 0, 'dang', ''),
(128, 2, 'Eastern Rukum	', 0, 'eastern-rukum', ''),
(129, 2, 'Gulmi', 0, 'gulmi', ''),
(130, 2, 'Kapilvastu', 0, 'kapilvastu', ''),
(131, 2, 'Palpa', 0, 'palpa', ''),
(132, 2, 'Parasi', 0, 'parasi', ''),
(133, 2, 'Pyuthan', 0, 'pyuthan', ''),
(134, 2, 'Rolpa	', 0, 'rolpa', ''),
(135, 2, 'Rupandehi', 0, 'rupandehi', ''),
(136, 2, 'Dailekh', 0, 'dailekh', ''),
(137, 2, 'Dolpa', 0, 'dolpa', ''),
(138, 2, 'Humla', 0, 'humla', ''),
(139, 2, 'Jajarkot', 0, 'jajarkot', ''),
(140, 2, 'Jumla', 0, 'jumla', ''),
(141, 2, 'Kalikot', 0, 'kalikot', ''),
(142, 2, 'Mugu', 0, 'mugu', ''),
(143, 2, 'Salyan	', 0, 'salyan', ''),
(144, 2, 'Surkhet', 0, 'surkhet', ''),
(145, 2, 'Western Rukum	', 0, 'western-rukum', ''),
(146, 2, 'Achham	', 0, 'achham', ''),
(147, 2, 'Baitadi', 0, 'baitadi', ''),
(148, 2, 'Bajhang', 0, 'bajhang', ''),
(149, 2, 'Bajura', 0, 'bajura', ''),
(150, 2, 'Dadeldhura', 0, 'dadeldhura', ''),
(151, 2, 'Darchula', 0, 'darchula', ''),
(152, 2, 'Doti	', 0, 'doti', ''),
(153, 2, 'Doti	', 0, 'doti', ''),
(154, 2, 'Kailali	', 0, 'kailali', ''),
(155, 2, 'Kanchanpur	', 0, 'kanchanpur', ''),
(156, 2, 'India', 0, 'india', ''),
(157, 2, 'Delhi', 0, 'delhi', ''),
(158, 2, 'Calcutta', 0, 'calcutta', ''),
(159, 2, 'Mumbai', 0, 'mumbai', ''),
(160, 2, 'Banglore', 0, 'banglore', ''),
(161, 2, 'Dubai', 0, 'dubai', ''),
(162, 2, 'Chennai', 0, 'chennai', ''),
(163, 2, 'Goa', 0, 'goa', ''),
(164, 9, 'Advertising Agency', 0, 'advertising-agency', ''),
(165, 9, 'Distribution Companies / Wholesale', 0, 'distribution-companies-wholesale', ''),
(166, 9, 'Engineering Firms', 0, 'engineering-firms', ''),
(167, 9, 'Finance Companies', 0, 'finance-companies', ''),
(168, 9, 'Hospital / Clinic / Diagnostic Centre', 0, 'hospital-clinic-diagnostic-centre', ''),
(169, 9, 'Information / Computer / Technology (IT)', 0, 'information-computer-technology-it', ''),
(170, 9, 'Insurance Companies', 0, 'insurance-companies', ''),
(171, 9, 'ISP (Internet Service Provider)', 0, 'isp-internet-service-provider', ''),
(172, 9, 'Multinational Companies', 0, 'multinational-companies', ''),
(173, 9, 'Retail / Shops', 0, 'retail-shops', ''),
(174, 9, 'Software Companies', 0, 'software-companies', ''),
(175, 9, 'Trading - Export / Import / Merchandising', 0, 'trading-export-import-merchandising', ''),
(176, 9, 'Banquet / Catering', 0, 'banquet-catering', ''),
(177, 9, 'Electronic Company', 0, 'electronic-company', ''),
(178, 9, 'Audit Firm', 0, 'audit-firm', ''),
(179, 9, 'Law Firm', 0, 'law-firm', ''),
(180, 9, 'Telecommunication', 0, 'telecommunication', ''),
(181, 9, 'NGO/INGO', 0, 'ngoingo', ''),
(182, 9, 'HR Companies', 0, 'hr-companies', ''),
(183, 9, 'Government Job', 0, 'government-job', ''),
(184, 9, 'Travel & Ticketing', 0, 'travel-ticketing', ''),
(185, 9, 'Interior Design', 0, 'interior-design', ''),
(186, 9, 'Ecommerce', 0, 'ecommerce', ''),
(187, 9, 'Supply Chain & Management (Cargo)', 0, 'supply-chain-management-cargo', ''),
(188, 9, 'Airlines', 0, 'airlines', ''),
(189, 4, 'As per company\'s rule', 0, 'as-per-companys-rule', ''),
(190, 4, 'Rs. 1,50,000 - Rs. 1,80,000', 0, 'rs-150000-rs-180000', ''),
(191, 4, 'Rs. 1,80,000 - Rs. 2,00,000', 0, 'rs-180000-rs-200000', ''),
(192, 4, 'Rs. 2,00,000 - Rs. 2,25,000', 0, 'rs-200000-rs-225000', ''),
(193, 4, 'Rs. 2,25,000 - Rs. 2,50,000', 0, 'rs-225000-rs-250000', ''),
(194, 4, 'Rs. 2,50,000 - Rs. 3,00,000', 0, 'rs-250000-rs-300000', ''),
(195, 4, 'Rs. 3,00,000 - Rs. 4,00,000', 0, 'rs-300000-rs-400000', ''),
(196, 4, 'Rs. 4,00,000 - Rs. 5,00,000', 0, 'rs-400000-rs-500000', ''),
(197, 4, 'Above Rs. 5,00,000', 0, 'above-rs-500000', ''),
(198, 3, 'ACCA', 0, 'acca', ''),
(199, 3, 'CFA', 0, 'cfa', ''),
(200, 3, 'CPA', 0, 'cpa', ''),
(201, 3, 'CA/ACCA/CFA/CPA/MBA', 0, 'caaccacfacpamba', ''),
(202, 3, 'CA/ACCA', 0, 'caacca', ''),
(203, 3, 'CA/MBA', 0, 'camba', ''),
(204, 3, 'CA/ACCA/CPA', 0, 'caaccacpa', ''),
(205, 3, 'CA/LLB', 0, 'callb', ''),
(206, 3, 'LLB', 0, 'llb', ''),
(207, 3, 'BBA', 0, 'bba', ''),
(208, 5, 'Sole Proprietorship', 0, 'sole-proprietorship', ''),
(209, 5, 'Private Limited', 0, 'private-limited', ''),
(210, 5, 'Public Limited', 0, 'public-limited', ''),
(211, 5, 'NGO/INGO', 0, 'ngoingo', ''),
(212, 5, 'Trust', 0, 'trust', ''),
(213, 5, 'Co-operative', 0, 'co-operative', ''),
(214, 5, 'Government Organization', 0, 'government-organization', ''),
(215, 5, 'NRB', 0, 'nrb', ''),
(216, 5, 'Insurance Board (Beema Samiti)', 0, 'insurance-board-beema-samiti', ''),
(217, 5, 'Banks', 0, 'banks', ''),
(218, 5, 'Insurance', 0, 'insurance', ''),
(219, 5, 'Finance Companies', 0, 'finance-companies', ''),
(220, 5, 'Development Bank', 0, 'development-bank', ''),
(221, 5, 'Hydropower', 0, 'hydropower', ''),
(222, 5, 'NEA', 0, 'nea', ''),
(223, 8, 'Nepali', 0, 'nepali', ''),
(224, 8, 'Indian', 0, 'indian', ''),
(225, 8, 'SAARC Country', 0, 'saarc-country', ''),
(226, 8, 'Europe', 0, 'europe', ''),
(227, 8, 'America', 0, 'america', ''),
(228, 8, 'Australia', 0, 'australia', ''),
(229, 8, 'Africa', 0, 'africa', ''),
(230, 8, 'Asia', 0, 'asia', ''),
(231, 8, 'North America', 0, 'north-america', ''),
(232, 8, 'South America', 0, 'south-america', ''),
(233, 11, 'CA', 0, 'ca', ''),
(234, 11, 'MBA', 0, 'mba', ''),
(235, 11, 'Semi Qualified CA', 0, 'semi-qualified-ca', ''),
(236, 11, 'Master', 0, 'master', ''),
(237, 11, 'Bachelor', 0, 'bachelor', ''),
(238, 11, 'Intermediate (Plus 2)	', 0, 'intermediate-plus-2', ''),
(239, 11, 'ACCA', 0, 'acca', ''),
(240, 11, 'CFA	', 0, 'cfa', ''),
(241, 11, 'CPA', 0, 'cpa', ''),
(242, 11, 'CA/ACCA/CFA/CPA/MBA	', 0, 'caaccacfacpamba', ''),
(243, 11, 'CA/ACCA	', 0, 'caacca', ''),
(244, 11, 'CA/MBA	', 0, 'camba', ''),
(245, 11, 'CA/ACCA/CPA	', 0, 'caaccacpa', ''),
(246, 11, 'CA/LLB	', 0, 'callb', ''),
(247, 11, 'LLB	', 0, 'llb', ''),
(248, 11, 'BBA', 0, 'bba', ''),
(249, 11, 'BIM', 0, 'bim', ''),
(250, 3, 'BIM', 0, 'bim', ''),
(251, 3, 'PHD', 0, 'phd', ''),
(252, 11, 'PHD', 0, 'phd', ''),
(253, 11, 'EMBA', 0, 'emba', ''),
(254, 3, 'EMBA', 0, 'emba', ''),
(255, 15, 'Eastern Development Region	', 0, 'eastern-development-region', ''),
(256, 15, 'Central Development Region	', 0, 'central-development-region', ''),
(257, 15, 'Western Development Region	', 0, 'western-development-region', ''),
(258, 15, 'Mid-Western Development Region	', 0, 'mid-western-development-region', ''),
(259, 15, 'Far-Western Development Region	', 0, 'far-western-development-region', ''),
(260, 17, 'Board Level', 0, 'board-level', ''),
(261, 17, 'Jr. Assistant Level', 0, 'jr-assistant-level', ''),
(262, 17, 'Sr. Assistant Level', 0, 'sr-assistant-level', ''),
(263, 17, 'Jr. Officer', 0, 'jr-officer', ''),
(264, 17, 'Sr. Officer', 0, 'sr-officer', ''),
(265, 17, 'Manager Level', 0, 'manager-level', ''),
(266, 17, 'Sr. Manager Level', 0, 'sr-manager-level', ''),
(267, 17, 'Deputy Manager Level', 0, 'deputy-manager-level', ''),
(268, 17, 'CFO', 0, 'cfo', ''),
(269, 17, 'Accountant', 0, 'accountant', ''),
(270, 17, 'Sr. Accountant', 0, 'sr-accountant', ''),
(271, 17, 'Jr. Accountant', 0, 'jr-accountant', ''),
(272, 17, 'General Manager', 0, 'general-manager', ''),
(273, 16, 'Consultant', 0, 'consultant', ''),
(274, 7, 'No. of Employees (201-300)	', 0, 'no-of-employees-201-300', ''),
(275, 7, 'No. of Employees (301-400)	', 0, 'no-of-employees-301-400', ''),
(276, 7, 'No. of Employees (401-500)	', 0, 'no-of-employees-401-500', ''),
(277, 7, 'No. of Employees (500+)	', 0, 'no-of-employees-500', ''),
(278, 9, 'Hydropower', 0, 'hydropower', ''),
(279, 2, 'Birgunj', 0, 'birgunj', '');

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `orgname` varchar(200) NOT NULL,
  `organization_code` varchar(255) NOT NULL,
  `organization_name` varchar(200) DEFAULT NULL,
  `organization_type` int(50) DEFAULT NULL,
  `organization_address` varchar(100) DEFAULT NULL,
  `organization_size` varchar(100) NOT NULL,
  `organization_description` text NOT NULL,
  `organization_phone` varchar(50) DEFAULT NULL,
  `organization_fax` varchar(25) DEFAULT NULL,
  `organization_pobox` varchar(25) DEFAULT NULL,
  `organization_website` varchar(50) DEFAULT NULL,
  `organization_logo` varchar(50) DEFAULT NULL,
  `organization_banner` varchar(100) DEFAULT NULL,
  `organization_facebook` varchar(200) NOT NULL,
  `organization_linkedin` varchar(200) NOT NULL,
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_designation` varchar(50) DEFAULT NULL,
  `contact_email` varchar(50) DEFAULT NULL,
  `contact_mobile` varchar(50) DEFAULT NULL,
  `alternate_contact_name` varchar(50) DEFAULT NULL,
  `alternate_contact_designatioin` varchar(50) NOT NULL,
  `alternate_contact_email` varchar(50) NOT NULL,
  `alternate_contact_mobile` varchar(20) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime NOT NULL,
  `last_accessed` datetime NOT NULL,
  `isActivated` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `activation_code` varchar(50) NOT NULL,
  `token` varchar(150) DEFAULT NULL,
  `joindate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`id`, `username`, `email`, `password`, `orgname`, `organization_code`, `organization_name`, `organization_type`, `organization_address`, `organization_size`, `organization_description`, `organization_phone`, `organization_fax`, `organization_pobox`, `organization_website`, `organization_logo`, `organization_banner`, `organization_facebook`, `organization_linkedin`, `contact_name`, `contact_designation`, `contact_email`, `contact_mobile`, `alternate_contact_name`, `alternate_contact_designatioin`, `alternate_contact_email`, `alternate_contact_mobile`, `date_created`, `date_modified`, `last_accessed`, `isActivated`, `activation_code`, `token`, `joindate`) VALUES
(2, 'dac@info.com', 'dac@info.com', '25f9e794323b453885f5181f1b624d0b', 'Digital Agency Catmandu Pvt', 'testing-for-org-19', 'Digital Agency Catmandu Pvt', 26, 'Baluwatar', '35', '<p>One of the leading digital agencies in Nepal, Digital Agency Catmandu is a strategic creative agency, with digital at the core of its heart.</p>\r\n<p>We offer smarter ways to help you connect and create a meaningful relation with audiences across various digital platforms. At Digital Agency Catmandu, we tend to think out of the box and there&rsquo;s not limitation on our imagination.</p>\r\n<p>We know this fact, influencing and changing people&rsquo;s perception are only possible with reason and encouragement, and at Digital Agency Catmandu we provide both.</p>\r\n<p>We discover ideas that motivates people to feel, think and act.</p>', '9841267335', NULL, '00977', 'digitalagencycatmandu.com', '1810dac-banner-small.jpg', '1810dac-banner-small1.jpg', 'https://www.facebook.com/dackathmandunepal/', 'https://www.linkedin.com/', 'Sanjeev Singh', 'MD', 'info@digitalagencycatmandu.com', '9841267335', 'Sanjeev Singh', 'test', 'test', 'test', '2019-03-14 10:30:32', '0000-00-00 00:00:00', '2019-09-18 15:21:00', 'Yes', '', NULL, '2019-03-14'),
(18, 'agro@financejobnepal.com', 'agro@financejobnepal.com', '25f9e794323b453885f5181f1b624d0b', 'Financejob', 'testing-for-org-19', 'Financejob', 9, NULL, '', '', '9851186360', NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, '', '', '', '2019-09-11 10:01:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Yes', '', NULL, '2019-09-11'),
(11, 'sanjeev@onlineaushadhi.com', 'sanjeev@onlineaushadhi.com', '25f9e794323b453885f5181f1b624d0b', 'Online Aushadhi Pvt Ltd', 'testing-for-org-19', 'Online Aushadhi Pvt Ltd', 40, 'Baluwatar, Kathmandu', '27', '<p><strong>Online Aushadhi</strong>&nbsp;is a loacally owned, independent and licensed online pharmacy system which aims to provide high quality medical care within Ringroad, kathmandu. Our main goal to provide safe prescription drugs at the most competetive price and to provide quick and efficient customer service. We provide services like any other retail pharmacy near your home, the only difference is, you do not have to come to us, rather we dispense your medications at your doorstep.</p>', '9841568568', NULL, '', '', '3739logo-oa.png', NULL, 'https://www.facebook.com/healthtips.onlineaushadhi/', '', 'Sabi Singh', 'CEO', '', '', '', '', '', '', '2019-06-14 04:47:22', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Yes', '', NULL, '2019-06-14'),
(12, 'info@easymandu.com', 'info@easymandu.com', 'ee22b05cf33defac4ef0639eeb69f636', 'Easymandu Pvt Ltd', 'testing-for-org-19', 'Easymandu Pvt Ltd', 39, 'Baluwatar, Kathmandu', '', '<p>Easymandu is Nepal\'s online store for baby and kids clothing and accessories. We cater to the needs of our buyers (parent buying for their kids) from two years to his/her early teens.</p>', '9863334405', NULL, '', 'https://www.easymandu.com', '9306logo.png', NULL, 'https://www.facebook.com/easymandu11/', '', 'Sanjeev Singh', 'Technical Manager', 'masanjeev@gmail.com', '9841267335', '', '', '', '', '2019-06-20 16:07:24', '0000-00-00 00:00:00', '2019-06-21 11:37:08', 'Yes', '', NULL, '2019-06-20'),
(17, 'fmcg@financejobnepal.com', 'fmcg@financejobnepal.com', '25f9e794323b453885f5181f1b624d0b', '	 A Reputed FMCG', 'testing-for-org-19', 'A Reputed FMCG', 39, NULL, '', '', '9851186360', NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, '', '', '', '2019-09-11 09:51:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Yes', '', NULL, '2019-09-11');

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fields`
--

INSERT INTO `fields` (`id`, `title`) VALUES
(2, 'Job Location'),
(3, 'Education'),
(4, 'Salary Range'),
(5, 'Ownership'),
(6, 'Organization Industry Type'),
(7, 'Organization Size'),
(8, 'Nationality'),
(9, 'Job Category'),
(11, 'Education Level'),
(15, 'Job Region'),
(16, 'Job Type'),
(17, 'Job Level');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User'),
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `eid` int(11) DEFAULT NULL,
  `displayname` varchar(150) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `jobtitle` varchar(150) DEFAULT NULL,
  `jobcategory` int(11) DEFAULT NULL,
  `preferredgender` enum('Male','Female','Male/Female','Both','Others') NOT NULL DEFAULT 'Male',
  `requiredno` varchar(150) DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pmm` int(11) DEFAULT NULL,
  `pdd` int(11) DEFAULT NULL,
  `pyy` int(11) DEFAULT NULL,
  `post_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedate` date NOT NULL,
  `apmm` int(11) DEFAULT NULL,
  `apdd` int(11) DEFAULT NULL,
  `apyy` int(11) DEFAULT NULL,
  `applybefore` date NOT NULL,
  `salaryrange` varchar(25) DEFAULT NULL,
  `exprequire` varchar(10) NOT NULL,
  `noexperience` varchar(100) DEFAULT NULL,
  `education` int(11) DEFAULT NULL,
  `joblevel` varchar(15) DEFAULT NULL,
  `jobtype` varchar(250) DEFAULT NULL,
  `jobtype2` varchar(250) DEFAULT NULL,
  `jobtype3` varchar(250) DEFAULT NULL,
  `jobtype4` varchar(250) DEFAULT NULL,
  `otherstype` varchar(50) NOT NULL,
  `joblocation` varchar(250) DEFAULT NULL,
  `brief` text,
  `background` text,
  `specification` text,
  `requirements` text,
  `howtoapply` text,
  `acceptonline` enum('Yes','No') DEFAULT 'No',
  `onlineap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `emailap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `postap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `video_cv` varchar(10) NOT NULL,
  `isNewspaperJob` text,
  `job_display_in` varchar(50) DEFAULT '',
  `isWalkin` enum('0','1') NOT NULL DEFAULT '0',
  `pobox` text,
  `adminPosted` enum('1','0') NOT NULL DEFAULT '0',
  `complogo` varchar(150) NOT NULL,
  `banner_image` varchar(200) DEFAULT NULL,
  `post_status` varchar(100) NOT NULL,
  `apply_by_faculty` varchar(100) DEFAULT NULL,
  `apply_by_age` varchar(100) NOT NULL,
  `from_age` int(11) NOT NULL,
  `to_age` int(11) NOT NULL,
  `postedin` varchar(100) NOT NULL,
  `orgemail` varchar(100) NOT NULL,
  `no_of_views` varchar(100) DEFAULT NULL,
  `required_education` varchar(200) NOT NULL,
  `expected_faculty` text NOT NULL,
  `other_faculty` varchar(200) DEFAULT NULL,
  `slc_docs` int(11) DEFAULT NULL,
  `docs_11_12` int(11) DEFAULT NULL,
  `bachelor_docs` int(11) DEFAULT NULL,
  `masters_docs` int(11) DEFAULT NULL,
  `isEmailed` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `eid`, `displayname`, `slug`, `jobtitle`, `jobcategory`, `preferredgender`, `requiredno`, `date_added`, `pmm`, `pdd`, `pyy`, `post_date`, `updatedate`, `apmm`, `apdd`, `apyy`, `applybefore`, `salaryrange`, `exprequire`, `noexperience`, `education`, `joblevel`, `jobtype`, `jobtype2`, `jobtype3`, `jobtype4`, `otherstype`, `joblocation`, `brief`, `background`, `specification`, `requirements`, `howtoapply`, `acceptonline`, `onlineap`, `emailap`, `postap`, `video_cv`, `isNewspaperJob`, `job_display_in`, `isWalkin`, `pobox`, `adminPosted`, `complogo`, `banner_image`, `post_status`, `apply_by_faculty`, `apply_by_age`, `from_age`, `to_age`, `postedin`, `orgemail`, `no_of_views`, `required_education`, `expected_faculty`, `other_faculty`, `slc_docs`, `docs_11_12`, `bachelor_docs`, `masters_docs`, `isEmailed`) VALUES
(49, 18, '', 'senior-tax-consultant', 'Senior Tax Consultant', 5, 'Male/Female', '1', '2019-09-11 12:43:05', NULL, NULL, NULL, '2019-09-11 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-14', '28', '', '2', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>ACCA/ CA/ CPA/ MBA qualified/semi-qualified with extensive personal and corporate tax experience</li>\r\n<li>Strong technical experience, gained within a tax department, audit firm and/or financial accounting team for UK Clients</li>\r\n<li>Maintain up to date knowledge of tax and tax legislation across the board&nbsp;</li>\r\n<li>Excellent time management skills and being able to deliver engagements under pressure to strict deadlines</li>\r\n<li>Team management experience</li>\r\n<li>Ability to communicate effectively and appropriately at all levels, both within and outside the firm</li>\r\n</ul>', '<div class=\"card-group\">\r\n<div class=\"card border-0\">\r\n<div class=\"card-body p-0 table-responsive\">\r\n<div class=\"card-group\">\r\n<div class=\"card border-0\">\r\n<div class=\"card-text p-2\">\r\n<ul>\r\n<li>Have basic knowledge of VT and IRIS</li>\r\n<li>Proficient in Microsoft Office programs, with excellent Excel spreadsheet skill</li>\r\n<li>Experience of working with companies in UK</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '66998ec92b70-18d6-4fd8-b3d9-22289aabe4c1.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', 'ACCA/ CA/ CPA/ MBA qualified/semi-qualified', NULL, NULL, NULL, NULL, '1'),
(45, 17, '', 'account-and-administration', 'Account and Administration', 2, 'Male', '3', '2019-09-17 09:52:13', NULL, NULL, NULL, '2019-09-11 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-18', '28', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p><img src=\"https://dac.technocreates.net/finance-job-nepal/tinymce/file_manager/source/Gulf_Asia_Menpower_z5ETDlx.jpg?1568264650985\" alt=\"\" width=\"1900\" height=\"1600\" /></p>', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', '8', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(57, 18, 'G Prakash & Associates', 'chartered-accountant', 'Chartered Accountant', 6, 'Male/Female', '2', '2019-09-17 08:57:31', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-18', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Presentation &amp; Communication skills</li>\r\n</ul>', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'other', '', 'CA', NULL, NULL, NULL, NULL, '1'),
(46, 18, 'Aarti Vegetable Products Pvt. Ltd', 'accountant', 'Accountant', 9, 'Male/Female', '2', '2019-09-11 10:52:45', NULL, NULL, NULL, '2019-09-11 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-18', '30', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '1811jv.png', NULL, 'public', NULL, '', 0, 0, '', '', '2', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(48, 18, 'Adhishree House of Designs', 'accountant', 'Accountant', 7, 'Male', '1', '2019-09-11 12:40:23', NULL, NULL, NULL, '2019-09-11 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-18', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Bachelors degree in Management specialized in Accounts, Masters Level preferable</li>\r\n<li>Minimum 2 years experience in related field</li>\r\n<li>Having good knowledge of Email, Internet, Excel, Ms-Word and Power-Point, Tally is a must</li>\r\n<li>Ability to handle accounting transactions</li>\r\n<li>Ability to work independently under pressure&nbsp;</li>\r\n<li>Knowledge of having E-TDS/ VAT update/ Party reconciliation&nbsp;&nbsp;</li>\r\n</ul>\r\n<p><strong>Having own motorbike and having valid 2 wheeler license</strong></p>', '<ul>\r\n<li>Managing and overseeing the daily operations of accounts department</li>\r\n<li>Preparing payments by verifying documentations and requesting disbursements</li>\r\n<li>Managing accounts payable and accounts receivables</li>\r\n<li>Monitoring data processing, posting, analyzing and providing details as per requirement</li>\r\n<li>Reconciling discrepancies by collecting and analyzing account information and initiating corrective actions</li>\r\n<li>Assisting in preparation of Balance Sheet and budget reports</li>\r\n<li>Visiting banks for deposits and withdrawal&nbsp;</li>\r\n<li>Should monitor and support taxation issues</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '71579ef9d711-5280-46bd-b40b-a256e818551e.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(50, 18, '', 'senior-practice-accountant', 'Senior Practice Accountant', 6, 'Male/Female', '1', '2019-09-11 12:45:38', NULL, NULL, NULL, '2019-09-11 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-14', '28', '', '2', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>ACCA/ CA/ CPA/ MBA qualified accountant with minimum 2 years&rsquo; experience in practice</li>\r\n<li>Strong knowledge of accounting systems, UK tax laws and accounting standards applicable to small and medium-sized business</li>\r\n<li>Experience within an accountancy practice</li>\r\n<li>Able to work on multiple projects, in a fast paced environment and work effectively to deadlines and time-scales</li>\r\n<li>Previously been responsible for managing a portfolio of clients</li>\r\n<li>Excellent written and verbal communication skills to both clients and colleagues</li>\r\n</ul>', '<ul>\r\n<li>Have basic knowledge of IRIS, Xero, Sage &amp; QuickBooks</li>\r\n<li>Proficient in Microsoft Office programs, with excellent Excel spreadsheet skill</li>\r\n<li>Experience of working with companies in UK</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '94938ec92b70-18d6-4fd8-b3d9-22289aabe4c1.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', 'ACCA/ CA/ CPA/ MBA qualified', NULL, NULL, NULL, NULL, '1'),
(51, 18, 'The Hidden Treasure (THT) Pvt. Ltd.', 'accountant-cum-receptionist', 'Accountant cum Receptionist', 6, 'Female', '1', '2019-09-12 04:14:43', NULL, NULL, NULL, '2019-09-11 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-18', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p style=\"text-align: justify;\">The Hidden Treasure is looking for an assistant accountant who will also have reception duties. The candidate&rsquo;s duties range from helping to prepare financial statements and accounts, budgeting, managing ledgers, processing invoices and preparing VAT returns. The candidate will provide whatever support is necessary to the management accountant and finance team. The role also includes serving visitors by greeting, welcoming, and directing them appropriately; notify company personnel of visitor arrival; maintains security and telecommunications system. The candidate must have a bachelor&rsquo;s degree at a minimum.</p>', '<p>The Hidden Treasure is looking for an assistant accountant who will also have reception duties. The candidate&rsquo;s duties range from helping to prepare financial statements and accounts, budgeting, managing ledgers, processing invoices and preparing VAT returns. The candidate will provide whatever support is necessary to the management accountant and finance team. The role also includes serving visitors by greeting, welcoming, and directing them appropriately; notify company personnel of visitor arrival; maintains security and telecommunications system. The candidate must have a bachelor&rsquo;s degree at a minimum.</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '3142hidde.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(52, 2, 'DAC', 'testing', 'Testing', 5, 'Male/Female', '1', '2019-09-12 05:09:28', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-12', '29', '', 'Not Required', NULL, '17', 'a:2:{i:0;s:2:\"22\";i:1;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p><img src=\"https://dac.technocreates.net/finance-job-nepal/tinymce/file_manager/source/hrconcept-.jpg?1568264939643\" alt=\"\" width=\"1200\" height=\"800\" /><img src=\"https://dac.technocreates.net/finance-job-nepal/tinymce/file_manager/source/Baby-hand-push-walker-both-color.jpg?1568264903238\" alt=\"\" width=\"750\" height=\"727\" /></p>', '', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '', NULL, 'private', NULL, '', 0, 0, '', '', '1', 'Not Required', '', '', NULL, NULL, NULL, NULL, '1'),
(53, 18, 'Aarti Vegetable Products Pvt. Ltd', 'accountant', 'Accountant', 9, 'Male/Female', '2', '2019-09-12 09:01:05', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-18', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p>candidates with the knowledge of FACT Software&nbsp;</p>', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '6419logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(54, 18, 'Nepal Mountaineering Association', 'account-officer', 'Account Officer', 7, 'Male/Female', '1', '2019-09-12 10:10:57', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>At least a Master degree in Management majored in account or finance</li>\r\n<li>Experience of working in finance or accounting for 3 years in tourism or related organizations.</li>\r\n<li>Excellent communication skills (verbal and written) in English and Nepali</li>\r\n<li>Should have analytical skills and organizational skills as well</li>\r\n<li>Proficient in Microsoft Office applications and other accounting software like tally etc</li>\r\n<li>At least 3 years managerial experience in the previous role is desirable</li>\r\n<li>Knowledge of acceptable Nepal accounting standards and auditing practices</li>\r\n<li style=\"text-align: justify;\">Perfect knowledge of Nepal Tax and Tax benefits</li>\r\n</ul>', '<ul>\r\n<li>Monitor employee\'s payroll slips&nbsp;</li>\r\n<li>Manage receivable and payable for the company&nbsp;</li>\r\n<li>Monitor and analyze accounting data and produce accurate financial reports&nbsp;</li>\r\n<li>Establish and enforces proper accounting method\'s policies, and principles&nbsp;</li>\r\n<li>Improve systems and procedures and initiate corrective actions&nbsp;</li>\r\n<li>Liaise with accountant/ auditors for timely years-end audit&nbsp;</li>\r\n<li>Reconcile monthly payroll tax annually&nbsp;&nbsp;</li>\r\n<li>Monitor and minimize expenses of the organization where possible&nbsp;</li>\r\n<li>Monitor accounts supports performance and ensure they achieving the necessary results&nbsp;</li>\r\n<li>Ensurer accounts manual is update and present in the board when needed&nbsp;</li>\r\n<li>Provide training to new and existing staff as needed&nbsp;</li>\r\n<li>Other Ad Hoc Duties when required&nbsp;</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '5535logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'master', '', '', NULL, NULL, NULL, NULL, '1'),
(55, 18, 'Dharma Adventures', 'tally-accountant', 'Tally Accountant', 2, 'Male/Female', '1', '2019-09-19 11:01:04', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-08', '28', '', '1', NULL, '17', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Strong knowledge of Tally ERP 9 software</li>\r\n<li>Familiar with travel and tourism business</li>\r\n<li>Strong knowledge of MS Excel</li>\r\n<li>Well versed in statutory requirements (Tax, VAT, labour, contractual)</li>\r\n<li>Sound knowledge of MS Office, Internet</li>\r\n</ul>', '<ul>\r\n<li>Maintain up to date books of accounts in the accounting software</li>\r\n<li>Ensure all vouchers generated from the accounting software have necessary approvals</li>\r\n<li>Check all supporting documents for arithmetic accuracy and adequacy of documents before preparation of vouchers from the accounting software</li>\r\n<li>File all vouchers along with supporting documents with objective of easy retrieval</li>\r\n<li>Raise VAT invoice timely and accurately</li>\r\n<li>Maintain up to date VAT sales and purchase register</li>\r\n<li>Reconcile all bank account statements, all vendor account statements, all agents account statements&nbsp;&nbsp;with the Company\'s books of accounts</li>\r\n<li>Compute payroll taxation and other payroll deductions</li>\r\n<li>Perform duties as per the directions of the finance manager, the director and the Chairman</li>\r\n<li>Safeguarding of Company assets</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '6628logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(56, 18, 'Gateway Payment Services Pvt. Ltd.', 'accountant-and-administration', 'Accountant and Administration', 2, 'Male/Female', '1', '2019-09-12 10:50:22', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-22', '28', '', '1', NULL, '17', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Freshers or equal to 1 years of experience&nbsp;</li>\r\n<li>Minimum bachelors degree</li>\r\n<li>Good knowledge of using accounting software and typing skills.&nbsp;&nbsp;</li>\r\n<li>Good interpersonal and negotiation skill.&nbsp;</li>\r\n<li>Learning attitude&nbsp;</li>\r\n<li>Knowledge of import and export</li>\r\n<li>Good command on email, written and spoken of English and Nepali Language.&nbsp;</li>\r\n<li>Detailed description of the nature of current and/or previous job/s, and roles played&nbsp;</li>\r\n<li>Photo of the candidate.</li>\r\n<li>Days required to joining.</li>\r\n</ul>', '<ul>\r\n<li>Handling the regular accounting, voucher preparation, filing of transaction documents and executing various forms and document, as a part of standard operating procedures of accounts and finance department&nbsp;</li>\r\n<li>Preparing financial statements like balance sheet, income statement and cash flow statement</li>\r\n<li>Monthly Tax and Vat calculation.&nbsp;</li>\r\n<li>Keep and communicate accounting records as a journal, ledger, bank statements, and invoices.</li>\r\n<li>Other tasks&nbsp;&nbsp;</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"NJob\";}', '', '0', NULL, '', '8818logo.png', NULL, 'private', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(58, 18, 'G Prakash & Associates', 'semi-qualified-ca', 'Semi Qualified CA', 6, 'Male/Female', '2', '2019-09-12 11:00:05', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-20', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Presentation &amp; Communication Skills</li>\r\n</ul>', '', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', 'CA/ACCA', NULL, NULL, NULL, NULL, '1'),
(59, 18, 'Niwash Bhattarai & Associates', 'semi-qualified-ca', 'Semi qualified CA', 6, 'Male/Female', '1', '2019-09-12 11:02:26', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-12', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Presentation &amp; Communication skills</li>\r\n</ul>', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', 'CA Semi Qualified', NULL, NULL, NULL, NULL, '1'),
(60, 18, 'UK based Audit Firm', 'senior-associatesassociates', 'Senior Associates/Associates', 6, 'Male/Female', '3', '2019-09-17 04:55:06', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-12', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p>Excellent Excel Skills</p>', '<p>PRIMARY RESPONSIBILITY: Financial reporting under UK GAAP and IFRS, tax reporting, working papers, outsourced finance function, management reporting, VAT returns, payroll, company secretarial andfinancial analysis.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<div><strong>ADDITIONAL DETAILS:&nbsp;</strong></div>\r\n<div>&middot; Full on the job training will be provided for the job&nbsp;</div>\r\n<div>&middot; Fantastic opportunity to work on the international clients and get exposure to variety of clients and</div>\r\n<div>works&nbsp;</div>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', '2', 'other', '', 'Newly Qualified Chartered Accountants(OR Semi-qualified CA with only one group remaining) ', NULL, NULL, NULL, NULL, '1'),
(61, 18, 'S.U.N. Associates, Chartered Accountants', 'chartered-accountants', 'Chartered Accountants', 6, 'Male/Female', '2', '2019-09-12 11:09:46', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-12', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', 'CA', NULL, NULL, NULL, NULL, '1'),
(62, 18, 'S.U.N. Associates, Chartered Accountants', 'semi-qualified-chartered-accou', 'Semi Qualified Chartered Accountants', 6, 'Male/Female', '2', '2019-09-12 11:10:46', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-12', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', 'CA', NULL, NULL, NULL, NULL, '1'),
(63, 18, 'S.U.N. Associates, Chartered Accountants', 'trainee-chartered-accountants', 'Trainee Chartered Accountants', 6, 'Male/Female', '2', '2019-09-12 11:11:55', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-12', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', 'CA', NULL, NULL, NULL, NULL, '1'),
(64, 18, 'Leapfrog  Technology Nepal Pvt. Ltd.', 'assistant-manager-finance', 'Assistant Manager-Finance', 2, 'Male/Female', '1', '2019-09-17 06:53:24', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-20', '33', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>CA, ACCA, MBA or similar academic background</li>\r\n<li>At least 2 years of professional experience in a related field</li>\r\n<li>Commercial and business awareness</li>\r\n<li>Good communication skills &ndash; both written and verbal</li>\r\n<li>A keen eye for detail and the ability to probe further into data</li>\r\n<li>Ability to stick to time constraints</li>\r\n</ul>', '<ul>\r\n<li>Manage and oversee the daily operations of Accounts and Finance.</li>\r\n<li>Monitor and &nbsp;analyze accounting data and produce financial reports or statements.</li>\r\n<li>Enforce accounting methods, policies, and principles.</li>\r\n<li>Manage &nbsp;account receivable and payable positions of the company and forward schedule of receipt and payments.</li>\r\n<li>Supervise compliance of &nbsp;taxation and statutory matters.</li>\r\n<li>Preparation of accounting reports, financial information, and financial &nbsp;reports.</li>\r\n<li>Coordinate and complete annual audits.</li>\r\n<li>Issue and management of invoicing.</li>\r\n<li>Monitoring of Company budget and review of budget variation statements.</li>\r\n<li>Supervise functions of Accounts Officer and Transaction Officer.</li>\r\n<li>Perform all tasks as assigned by supervisor.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '3212logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '2', 'master', '', '', NULL, NULL, NULL, NULL, '1'),
(65, 18, 'Southasia Institute of Advanced Studies', 'account-and-finance-manager', 'Account and Finance Manager', 2, 'Male', '1', '2019-09-12 11:30:51', NULL, NULL, NULL, '2019-09-12 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-15', '28', '', '5', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Bachelor (preferably masters) degree in management with specialization in accounting or finance management.</li>\r\n<li>Minimum five of years of experiences with bachelor degree or three years experiences with masters degree on account and finance management in I/NGOs, or not-for-profit organizations.</li>\r\n<li>Good command in computer application such as accounting software and MS office.</li>\r\n<li>Experiences on account and finance management and reporting of donor funded projects</li>\r\n<li>Good knowledge of audit requirements, Tax and VAT regulations.</li>\r\n<li>Excellent negotiation and interpersonal skills.</li>\r\n</ul>', '<p style=\"font-weight: 400;\">&nbsp; &nbsp; &nbsp;</p>\r\n<ul>\r\n<li>Developing and maintaining account system for a non profit company.</li>\r\n<li>Maintain up to date system for TAX and VAT.</li>\r\n<li>Ensure necessary government compliances for non-profit company i.e. Company Registrar Office, Inland Revenue Office, Local Government etc.</li>\r\n<li>Develop financial plan&nbsp;of specific projects and organization as a whole.</li>\r\n<li>Produce financial reports of project as per the requirement by respective donor.</li>\r\n<li>Handle procurements of goods and services and assure maintaining record of assets.</li>\r\n<li>Develop financial proposal for the new projects.</li>\r\n<li>&nbsp;Supervise administrative staffs and ensure conducive office environment.</li>\r\n</ul>\r\n<p style=\"font-weight: 400;\">&middot;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4696logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'master', '', '', NULL, NULL, NULL, NULL, '1'),
(66, 18, 'A reputed & Dynamic College', 'account-officer', 'Account Officer', 2, 'Male', '1', '2019-09-15 09:28:43', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-20', '28', '', '5', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<ul style=\"list-style-type: disc;\">\r\n<li>Bachelor in Management with at least 5 year\'s of relevant experience&nbsp;&nbsp;</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '3282logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(67, 18, 'Stonestep', 'accounting-cum-finance-officer', 'Accounting Cum Finance Officer', 2, 'Male/Female', '1', '2019-09-17 09:42:04', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-19', '31', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul style=\"list-style-type: disc;\">\r\n<li>Should be familiar with Project Accounting</li>\r\n<li>Should know about Government Taxes</li>\r\n<li>Good with Tally Software</li>\r\n<li>Excellent in Excel</li>\r\n<li>Good both in verbal and written English</li>\r\n<li>Should generate the report for Audit purpose, donor agency</li>\r\n<li>Proven ability to create and assess financial statements and budget documents, and to create and maintain the local financial processes and policies</li>\r\n<li>Bring a can-do attitude and hands-on approach to the daily operations</li>\r\n<li>Agility and taking ownership is expected&nbsp;\r\n<p><strong>Education &amp; Experience</strong></p>\r\n<ul>\r\n<li>Candidates having working experience in NGO&rsquo;s and INGO&rsquo;s will have a plus point</li>\r\n<li>Completion of a minimum bachelor\'s degree at an accredited college or university in the field of Management, Finance, Investments, Accounting or Economics or equivalent</li>\r\n<li>&nbsp;3+ years of working experience in a similar position</li>\r\n<li>Demonstrated ability to establish financial processes and execute the daily financial management and accounting activities</li>\r\n</ul>\r\n</li>\r\n</ul>', '<p>We are recruiting a Finance and Accounting Officer to be based in our Kathmandu, Nepal office beginning immediately.&nbsp; The Finance and Accounting Manager will provide daily operational and long-term strategic support to the organization. This role will report directly to the Program Manager and assist him on all strategic and tactical matters related to budget management, financial planning, cash management, expense management, accounting, yearly closing, audit, parent company reporting and bank relations.</p>\r\n<p>This role requires attention to detail and timely execution. This position provides a unique opportunity in an early-stage company to work with a team which believes in responsible social development to promote social and economic development.</p>\r\n<div class=\"card\">\r\n<div class=\"card-body\">\r\n<div class=\"card-group\">\r\n<div class=\"card border-0\">\r\n<div class=\"card-text p-2\">\r\n<p><strong>Essential Duties &amp; Responsibilities</strong></p>\r\n<ul>\r\n<li>Manage day-to-day financial operations of the Group</li>\r\n<li>Prepare and implement accounting policies</li>\r\n<li>Oversee the production of monthly reports including reconciliations, financial statements and cash flow projections</li>\r\n<li>Oversee Accounts Payable and Accounts Receivable</li>\r\n<li>Prepare all fiscal reporting activities for the organization including: operating budget, revenue / expense and balance sheet reports, reports to funding agencies, development and monitoring of organizational and contract/grant budgets</li>\r\n<li>Ensure adequate cash flow management</li>\r\n<li>Oversee all purchasing and payroll activity for staff and participants</li>\r\n<li>Establish banking relations and execute bank transfers with Regional CEO</li>\r\n<li>Train staff on knowledge of financial management matters</li>\r\n<li>Support business development/sales and project work</li>\r\n<li>Assist in the development and negotiation of contracts</li>\r\n<li>Participate in developing new business, specifically: assist the Regional CEO, Nepal Program Manager, and senior management in identifying new funding opportunities, preparing business cases and budgets for new leads</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<hr class=\"mt-0 mb-4\" />\r\n<div class=\"mt-3\"><button class=\"btn btn-success\" type=\"button\" data-toggle=\"modal\" data-target=\"#generic-modal-box\" data-remote=\"/jobseeker/modal/login/?next=/accounting-cum-finance-officer-2/\">APPLY NOW</button></div>\r\n</div>\r\n</div>\r\n<div class=\"\">&nbsp;</div>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7976logo.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(68, 18, 'I. Solution International Pvt. Ltd.', 'manager', 'Manager', 2, 'Male/Female', '2', '2019-09-13 05:43:08', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-30', '28', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7135logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, '1'),
(69, 18, 'ME10', 'senior-tax-accountant', 'Senior Tax Accountant', 2, 'Male/Female', '1', '2019-09-13 06:40:56', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-14', '28', '', '2', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>ACCA/ CA/ CPA/ MBA qualified/semi-qualified with extensive personal and corporate tax experience</li>\r\n<li>Strong technical experience, gained within a tax department, audit firm and/or financial accounting team for UK Clients</li>\r\n<li>Maintain up to date knowledge of tax and tax legislation across the board&nbsp;</li>\r\n<li>Excellent time management skills and being able to deliver engagements under pressure to strict deadlines</li>\r\n<li>Team management experience</li>\r\n<li>Ability to communicate effectively and appropriately at all levels, both within and outside the firm&nbsp;\r\n<p><strong>Desirable Skills:&nbsp;</strong></p>\r\n<ul>\r\n<li>Have basic knowledge of VT and IRIS</li>\r\n<li>Proficient in Microsoft Office programs, with excellent Excel spreadsheet skill</li>\r\n<li>Experience of working with companies in UK</li>\r\n</ul>\r\n</li>\r\n</ul>', '<ul>\r\n<li>Compiling and analysing financial information to prepare tax returns and other reports</li>\r\n<li>Reviewing/preparing tax returns and work-papers and review/calculate estimated tax payments as required</li>\r\n<li>Reconciling tax accounts, prepare documentation and appropriate journal entries</li>\r\n<li>Interacting with various other departments within the firm regarding tax compliance, statutory filings, and other tax related matters relating to operations requirements</li>\r\n<li>Keeping abreast of international tax law changes, researches tax issues using tax research tools, and documents findings</li>\r\n<li>The management of a portfolio of clients</li>\r\n<li>Monitoring tax return process and assist with development of junior staff</li>\r\n<li>Preparing P11d\'s</li>\r\n<li>Advising clients on tax implications and deadlines.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '1972me10_logo.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'master', '', '', NULL, NULL, NULL, NULL, '1'),
(70, 18, 'ME10', 'senior-practice-accountant', 'Senior Practice Accountant', 2, 'Male/Female', '2', '2019-09-13 06:47:10', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-14', '28', '', '2', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>ACCA/ CA/ CPA/ MBA qualified accountant with minimum 2 years&rsquo; experience in practice</li>\r\n<li>Strong knowledge of accounting systems, UK tax laws and accounting standards applicable to small and medium-sized business</li>\r\n<li>Experience within an accountancy practice</li>\r\n<li>Able to work on multiple projects, in a fast paced environment and work effectively to deadlines and time-scales</li>\r\n<li>Previously been responsible for managing a portfolio of clients</li>\r\n<li>Exc\r\n<p><strong>Desirable Requirements</strong></p>\r\n<ul>\r\n<li>Have basic knowledge of IRIS, Xero, Sage &amp; QuickBooks</li>\r\n<li>Proficient in Microsoft Office programs, with excellent Excel spreadsheet skill</li>\r\n<li>Experience of working with companies in UK</li>\r\n</ul>\r\n</li>\r\n</ul>', '<ul>\r\n<li>Preparing statutory annual accounts for sole traders, partnerships and limited companies as well as corporation tax computations</li>\r\n<li>Planning and completing audit and accounting assignments to a high standard of technical competence and within time/budget constraints</li>\r\n<li>Assisting the portfolio manager &amp; partner to achieve deadlines</li>\r\n<li>Regular Dealing with UK clients for all queries</li>\r\n<li>To undertake smaller and medium sized assignments independently or assist in larger assignments reporting to a Manager or Senior Manager</li>\r\n<li>Preparation of management reporting and analysis, and quarterly VAT returns for your portfolio</li>\r\n<li>Reviewing and completion of all work prior to partner review</li>\r\n<li>Maintaining technical competence</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '3275me10_logo.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'master', '', '', NULL, NULL, NULL, NULL, '1'),
(71, 18, 'Qatar Charity', 'assistant-finance-officer', 'Assistant Finance Officer', 7, 'Male/Female', '1', '2019-09-15 09:28:27', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-21', '28', '', '2', NULL, '17', 'a:1:{i:0;s:2:\"25\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p><strong>&nbsp; &nbsp; &nbsp; Skills:</strong></p>\r\n<ul style=\"list-style-type: disc;\">\r\n<li>&nbsp;Excellent computer skills including email, internet, MS Office, with the experience of accounting software and excellent standard of written and spoken Arabic, English and Nepali.&nbsp;&nbsp;\r\n<p><strong>Key Results:</strong></p>\r\n<p>Specialization in finance or accounting and experience of working in finance, administration and/or procurement in a relevant field in NGOs or INGOs. Sound knowledge of accounting procedures and principles and excellent Microsoft word and excel spreadsheet skills are key attributes.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Competencies:</strong></p>\r\n<ul>\r\n<li>Results focus, good communication and teamwork</li>\r\n<li>Sound knowledge of accounting procedures and principles&nbsp;</li>\r\n<li>Experience of using accounting software</li>\r\n<li>Knowledge sharing and continuous improvement&nbsp;\r\n<p><strong>Technical/Functional Skills:</strong></p>\r\n<p>&nbsp;</p>\r\n</li>\r\n<li>Support the efficient running of Qatar Charity Nepal office, help to identify needs and improve or develop systems where necessary</li>\r\n<li>Manage logistic arrangements for project activities and travel</li>\r\n<li>Ensure that organizational administrative documentation is up-to-date and in place</li>\r\n<li>Support with administrative and legal procedures</li>\r\n<li>Help to ensure finance, HR, and operations policies and procedures are available as a central resource to staff and support compliance</li>\r\n<li>Support in logistics management of training, events and monitoring visits&nbsp;\r\n<p>&nbsp;</p>\r\n</li>\r\n</ul>\r\n</li>\r\n</ul>', '<ul>\r\n<li>Make payments, ensuring compliance with Qatar Charity and donor agency rules and regulations</li>\r\n<li>Keep accurate and complete records of financial transactions in the computerized accounting system</li>\r\n<li>Maintain proper filing of vouchers and backup documents and safe storage of cheque books and banking documents</li>\r\n<li>Prepare monthly bank reconciliation statements and reconcile account balances</li>\r\n<li>Support preparation of report to Qatar Charity, Doha office weekly, monthly and as needed</li>\r\n<li>Support preparation of salary sheets, deposits of salaries, taxes and other employment related liabilities</li>\r\n<li>Procure goods and services, ensuring compliance with Qatar Charity and donor rules and regulations</li>\r\n<li>Maintain proper inventory records of goods and equipment owned by Qatar Charity and ensure that relevant control systems are in place and complied with</li>\r\n<li>Closely work with partner organizations&rsquo; finance teams on project financial reporting, ensuring accuracy and alignment with approved budgets</li>\r\n<li>Support the organization and management of statutory audits</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7367qatar.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(72, 18, 'KSM Services', 'accountant', 'Accountant', 8, 'Male/Female', '1', '2019-09-17 08:55:15', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-19', '29', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<div class=\"card-body p-2\">\r\n<ul>\r\n<li>Must be very fluent in excel</li>\r\n<li>Accounting software knowledge of swastik and tally</li>\r\n<li>Must be Smart and active female candidate as can deal will client as well</li>\r\n<li>If work is as expected then increment is not an issue</li>\r\n</ul>\r\n<h3 class=\"mb-1 h6\"><strong>&nbsp;</strong></h3>\r\n</div>', '<ul>\r\n<li>Prepares asset, liability, and capital account entries by compiling and analyzing account information</li>\r\n<li>Documents financial transactions by entering account information</li>\r\n<li>Recommends financial actions by analyzing accounting options</li>\r\n<li>Summarizes current financial status by collecting information, preparing balance sheet, profit and loss statement, and other reports</li>\r\n<li>Maintains accounting controls by preparing and recommending policies and procedures</li>\r\n<li>Reconciles financial discrepancies by collecting and analysing account information</li>\r\n<li>Secures financial information by completing database backups</li>\r\n<li>Prepares payments by verifying documentation, and requesting disbursements</li>\r\n<li>Prepares special financial reports by collecting, analysing, and summarizing account information and trends</li>\r\n<li>Maintains customer confidence and protects operations by keeping financial information confidential</li>\r\n<li>Assist in the processing of balance sheets, income statements and other financial statements according to legal and company accounting and financial guidelines</li>\r\n<li>Assist with reviewing of expenses, payroll records etc. as assigned</li>\r\n<li>Update financial data in databases to ensure that information will be accurately and immediately available when needed</li>\r\n<li>Prepare and submit weekly/monthly reports</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7605ksm.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(73, 18, 'Adhishree House of Designs', 'accountant', 'Accountant', 8, 'Male/Female', '1', '2019-09-13 07:16:02', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-18', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Bachelors degree in Management specialized in Accounts, Masters Level preferable</li>\r\n<li>Minimum 2 years experience in related field</li>\r\n<li>Having good knowledge of Email, Internet, Excel, Ms-Word and Power-Point, Tally is a must</li>\r\n<li>Ability to handle accounting transactions</li>\r\n<li>Ability to work independently under pressure&nbsp;</li>\r\n<li>Knowledge of having E-TDS/ VAT update/ Party reconciliation&nbsp;</li>\r\n<li>&nbsp;<strong>Having own motorbike and having valid 2 wheeler license</strong></li>\r\n</ul>', '<ul>\r\n<li>Managing and overseeing the daily operations of accounts department</li>\r\n<li>Preparing payments by verifying documentations and requesting disbursements</li>\r\n<li>Managing accounts payable and accounts receivables</li>\r\n<li>Monitoring data processing, posting, analyzing and providing details as per requirement</li>\r\n<li>Reconciling discrepancies by collecting and analyzing account information and initiating corrective actions</li>\r\n<li>Assisting in preparation of Balance Sheet and budget reports</li>\r\n<li>Visiting banks for deposits and withdrawal&nbsp;</li>\r\n<li>Should monitor and support taxation issues</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '6125ahod.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(74, 18, 'Microplus', 'assistant-accountant', 'Assistant Accountant', 6, 'Male/Female', '1', '2019-09-13 07:24:01', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-16', '29', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Proven accounting experience, preferably as an accounting data entry.</li>\r\n<li>Familiarity with bookkeeping and basic accounting procedures</li>\r\n<li>Competency in MS Office, databases and accounting software</li>\r\n<li>Hands-on experience with spreadsheets and financial reports</li>\r\n<li>Accuracy and attention to detail</li>\r\n<li>Aptitude for numbers</li>\r\n<li>Ability to perform filing and record keeping tasks</li>\r\n<li>Data entry and word processing skills</li>\r\n<li>Well organized</li>\r\n<li>+2 Degree</li>\r\n<li>Associate&rsquo;s degree or relevant certification is a plus</li>\r\n</ul>', '<p>We are looking for a skilled Assistant Accountant to perform a variety of accounting, bookkeeping and financial tasks.</p>\r\n<p>Assistant Accountant responsibilities include keeping financial records updated, preparing reports and reconciling bank statements. You will run online accounting software programs to process business transactions, like sales, purchase, accounts payable and receivable, disbursements, expense vouchers and receipts. A successful accounting assistant&nbsp;should be familiar with all accounting procedures and have a flair for the numbers.</p>\r\n<p>Ultimately, a successful Account Assistant will ensure that the company&rsquo;s daily accounting functions run accurately and effectively.&nbsp;&nbsp;</p>\r\n<p><strong>Responsibilities</strong></p>\r\n<ul>\r\n<li>Provide accounting and clerical support to the accounting department</li>\r\n<li>Type accurately, prepare and maintain accounting documents and records</li>\r\n<li>Prepare bank deposits, general ledger postings and statements</li>\r\n<li>Reconcile accounts in a timely manner</li>\r\n<li>Daily enter key data of financial transactions in software</li>\r\n<li>Provide assistance and support to company personnel</li>\r\n<li>Research, track and restore accounting or documentation problems and discrepancies</li>\r\n<li>Inform management and compile reports/summaries on activity areas</li>\r\n<li>Function in accordance with established standards, procedures and applicable laws</li>\r\n<li>Constantly update job knowledge</li>\r\n</ul>\r\n<div class=\"card-body\">&nbsp;</div>\r\n<div class=\"card-footer\">&nbsp;</div>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '5026microplus.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'intermediate', '', '', NULL, NULL, NULL, NULL, '1'),
(75, 18, 'All For All Solution (P) LTD.', 'chief-accountant', 'Chief Accountant', 6, 'Male/Female', '1', '2019-09-13 07:38:28', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-20', '29', '', '2', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Must have completed Bachelors Degree</li>\r\n<li>Must have minimum 2 yrs work experience in related field</li>\r\n<li>Knowledge about internal and external audit</li>\r\n<li>Experience in trading companies will be preferred</li>\r\n<li>Candidates having prior experience will be given priority</li>\r\n<li>Advanced computer skills in MS Office, accounting software and databases</li>\r\n<li>Excellent organizational, problem-solving, and communication skills</li>\r\n<li>Additional experience in Audit and International accounting</li>\r\n<li>Team working ability</li>\r\n</ul>', '<ul>\r\n<li>Prepares asset, liability, and capital account entries by compiling and analyzing account information</li>\r\n<li>Documents financial transactions by entering account information</li>\r\n<li>Recommends financial actions by analyzing accounting options</li>\r\n<li>Summarizes current financial status by collecting information; preparing balance sheet, profit and loss statement, and other reports</li>\r\n<li>Prepares special financial reports by collecting, analyzing, and summarizing account information and trends</li>\r\n<li>Maintains financial security by following internal controls</li>\r\n<li>Prepares payments by verifying documentation, and requesting disbursements</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '2466afa.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(76, 17, ' Daily Grocery PVT. LTD.(DG Mart)', 'officer-account-and-finance', 'Officer, Account and Finance', 3, 'Male/Female', '1', '2019-09-17 09:51:58', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-19', '29', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Must have completed Bachelors or Masters Degree is preferable</li>\r\n<li>Must be proficient with MS Excel</li>\r\n<li>Must be proficient in using IMS Software</li>\r\n</ul>', '<ul>\r\n<li>Record Keeping of all Transactions such as monthly expenses/income, advance and deposits, assets purchase, petty cash, adjustment entry</li>\r\n<li>Preparing financial sheets</li>\r\n<li>Monitoring all transactions such as cal deposit from all the outlets, purchase entry from receiver, transaction entry and transfer entry</li>\r\n<li>Credit Card &amp; Bank Reconciliation, Vendor\'s Account&nbsp;</li>\r\n<li>Reconciliation, Cash Reconciliation</li>\r\n<li>VAT Book Verification and E-Submission</li>\r\n<li>Financial Audit (Internal &amp; External)</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4404adg.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(77, 18, 'A multinational beverage company', 'accountant', 'Accountant', 4, 'Male/Female', '1', '2019-09-13 08:05:02', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-15', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>At least 2 years experiences in FMCG companies</li>\r\n<li>Bachelor&rsquo;s Degree in Accounting or Finance</li>\r\n<li>Good Data Entry Management Skills</li>\r\n<li>Firm grasp of basic and intermediate accounting principles</li>\r\n<li>Sound Knowledge of Vat, Income Tax and TDs</li>\r\n<li>Excellent Reporting &amp; Analytical Skills</li>\r\n</ul>', '<ul>\r\n<li>Maintain proper records of all financial statements and vouchers on daily basic</li>\r\n<li>Summarizes and analyze financial status by collecting information; preparing balance sheet, profit and loss statement, and other reports</li>\r\n<li>Hands on experience in lead managing Tax Audits and preparation and e-filing of Tax</li>\r\n<li>Preparation of advance tax workings and managing payments</li>\r\n<li>Compliance with TDS requirements</li>\r\n<li>Preparing legal briefs for Senior Management</li>\r\n<li>Reconciles financial discrepancies by collecting and analyzing account information Provides financial information to management by researching and analyzing accounting data, preparing reports daily, weekly &amp; monthly basis</li>\r\n<li>Compute taxes owed and prepare tax returns, ensuring compliance with payment, reporting, and other tax&nbsp;</li>\r\n<li>Prepares payments by verifying documentation, and requesting disbursements</li>\r\n<li>Secures financial information by completing data base backups</li>\r\n<li>Prepares payments by verifying documentation, and requesting disbursements</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4361logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1');
INSERT INTO `jobs` (`id`, `eid`, `displayname`, `slug`, `jobtitle`, `jobcategory`, `preferredgender`, `requiredno`, `date_added`, `pmm`, `pdd`, `pyy`, `post_date`, `updatedate`, `apmm`, `apdd`, `apyy`, `applybefore`, `salaryrange`, `exprequire`, `noexperience`, `education`, `joblevel`, `jobtype`, `jobtype2`, `jobtype3`, `jobtype4`, `otherstype`, `joblocation`, `brief`, `background`, `specification`, `requirements`, `howtoapply`, `acceptonline`, `onlineap`, `emailap`, `postap`, `video_cv`, `isNewspaperJob`, `job_display_in`, `isWalkin`, `pobox`, `adminPosted`, `complogo`, `banner_image`, `post_status`, `apply_by_faculty`, `apply_by_age`, `from_age`, `to_age`, `postedin`, `orgemail`, `no_of_views`, `required_education`, `expected_faculty`, `other_faculty`, `slc_docs`, `docs_11_12`, `bachelor_docs`, `masters_docs`, `isEmailed`) VALUES
(78, 18, 'Advance Group', 'manager-finance-and-accounts', 'Manager (Finance and Accounts)', 4, 'Male/Female', '2', '2019-09-13 08:13:45', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-21', '28', '', '3', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Must have completed Chartered Accountancy from ICAI/ICAN</li>\r\n<li>Must have at least 1-2 years of work experience in reputed business house or CA Firm\r\n<p><strong>Additional Qualification:&nbsp;&nbsp;</strong></p>\r\n<ul>\r\n<li>Advanced computer skills on MS Office, accounting software and databases</li>\r\n<li>Ability to handle large amounts of data</li>\r\n<li>Proven knowledge of bookkeeping and accounting principles, practices, standards, laws and regulations</li>\r\n<li>High attention to detail and accuracy</li>\r\n<li>Ability to direct and supervise</li>\r\n</ul>\r\n</li>\r\n</ul>', '<ul>\r\n<li>Assist General Manager (Finance) for day to day operation</li>\r\n<li>Manage and oversee the daily operations of the accounts department which includes month and end-year process</li>\r\n<li>Monitor and analyze accounting data and produce financial reports or statements</li>\r\n<li>Establish and enforce proper accounting methods, policies and principles</li>\r\n<li>Coordinate and complete annual audits</li>\r\n<li>Improve systems and procedures and initiate corrective actions</li>\r\n<li>Supervise finance team to ensure compliance and accuracy</li>\r\n<li>Meet financial accounting objectives</li>\r\n<li>Establish and maintain fiscal files and records to document transactions</li>\r\n<li>Oversee monthly closing process and issuance of performance and financial reports</li>\r\n<li>Preparation of month end reconciliations of all accounts, processing of Clients and Customers sales</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '2742ag.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', '', NULL, NULL, NULL, NULL, '1'),
(79, 18, 'Genese Solution', 'finance-officer', 'Finance Officer', 6, 'Male/Female', '1', '2019-09-13 08:51:52', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-13', '30', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Semi-Qualified CA/ ACCA (preference is given) or MBA with experience of at least 3 years (articleship counted)</li>\r\n<li>Experience of Accounting software (Tally) is a must</li>\r\n<li>Good communication skills and ability to work under minimum supervision and hectic work environment&nbsp;</li>\r\n<li>Overall knowledge of various other activities conducted by the Finance Department</li>\r\n<li>Hands-on knowledge of XLS, Word, Access and PowerPoint</li>\r\n<li>Nepali typing will be an advantage</li>\r\n</ul>', '<ul>\r\n<li>To liaise with the Finance Manager and Director in Kathmandu, manages all key financial transactions at the provincial level</li>\r\n<li>Responsible for overall central and field account management&nbsp;</li>\r\n<li>Preparation of sales invoices as per the requirement of the company</li>\r\n<li>Responsible for field budgets and fund request</li>\r\n<li>Review the advance settlement and payments documents to ensure that the documents are in compliance with Genese rules and regulation&nbsp;</li>\r\n<li>Prepares monthly bank reconciliations</li>\r\n<li>Checks petty cash payments and periodically reconciles petty cash balances</li>\r\n<li>Record accounts payable and accounts receivable</li>\r\n<li>Update internal systems with financial data</li>\r\n<li>Assist with budget preparation</li>\r\n<li>Dealing and reporting with Banks/ NRB/ DOI&nbsp;</li>\r\n<li>Work closely with the finance and accounts department of central office for efficient operations</li>\r\n<li>Review the travel expenses report of staffs and make the payment accordingly</li>\r\n<li>Prepare monthly, quarterly and annual financial reports or as per need</li>\r\n<li>Ensures that the books of accounts are up to date at all times, orderly, well kept, and readily available for reference and audit, when required</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '6093genese.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(80, 18, 'AD Capital Group', 'financial-analyst-corporate-ad', 'Financial Analyst-Corporate Advisory', 2, 'Male/Female', '1', '2019-09-13 09:07:00', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-30', '29', '', '1', NULL, '17', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Recent Graduates from BBA/MBA program&nbsp; &nbsp;</li>\r\n<li>Preferably holding a degree with concentration in finance, accounting, business, economics or another related field (All majors are welcome to apply)&nbsp; &nbsp;</li>\r\n<li>Some relevant financial services experience required.</li>\r\n<li>We train our new hires to gain proficiency in investment banking related skills including financial modeling&nbsp; &nbsp;</li>\r\n<li>Experience with MS Word, Excel and PowerPoint&nbsp; &nbsp;</li>\r\n<li>Excellent verbal and written communication skills are essential&nbsp; &nbsp;</li>\r\n<li>Authorized to work in Nepal&nbsp; &nbsp;</li>\r\n</ul>\r\n<p>&nbsp;</p>', '<p>AD Capital Group is a financial services firm providing advisory services to institutional clients. We believe in attracting exceptional talent and helping them grow into high-caliber individuals through our commitment to career development.&nbsp; &nbsp;</p>\r\n<p>We\'re looking to hire 1-2 full time analysts to join our team. The successful candidate will play a critical role in the following areas:&nbsp; &nbsp;</p>\r\n<ul>\r\n<li>Research potential buyers/investors and follow market trends&nbsp; &nbsp;</li>\r\n<li>Understand the appropriate deal approval and documentation required for transactions&nbsp; &nbsp;</li>\r\n<li>Express ideas in an organized, persuasive and articulate manner&nbsp; &nbsp;</li>\r\n<li>Work well in a team and keep team members informed of client discussion and relevant issues&nbsp; &nbsp;</li>\r\n<li>The successful candidate will participate in developing the overall business&nbsp; &nbsp;</li>\r\n</ul>\r\n<p>Successful team members are self-motivated, consistently reliable, work well under deadline pressure, have excellent problem-solving and analytical skills, are detail oriented and can multi-task well.&nbsp; &nbsp;</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4605logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(81, 18, 'HLE Nepal', 'loan-processing-specialist', 'Loan Processing Specialist', 2, 'Male/Female', '10', '2019-09-13 09:17:23', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-15', '28', '', '1', NULL, '17', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p><strong>Your key areas of responsibilities as a Loan Processing Specialist are:</strong></p>\r\n<ul>\r\n<li>Process home loan applications from submission to settlement for our clients in Australia</li>\r\n<li>Liaise with brokers, clients, lenders, solicitors, and other businesses</li>\r\n<li>Work efficiently in a high pressure and volume</li>\r\n<li>Provide meticulous attention to detail and accuracy in data entry</li>\r\n<li>Providing excellent customer service</li>\r\n<li>Perform in a dynamic team environment</li>\r\n<li>Take additional challenges as and when required&nbsp;\r\n<p>The Benefits of Joining Us Are Many!</p>\r\n<ul>\r\n<li>Competitive remuneration&nbsp;</li>\r\n<li>A secure long-term role</li>\r\n<li>Paid annual leave and sick leave</li>\r\n<li>Provident and Gratuity fund, Dashain bonus</li>\r\n<li>An&nbsp;environment that values continuous learning and development</li>\r\n<li>Parties and events &ndash; we want you to have some fun at work!</li>\r\n<li>Office-sponsored daily breakfasts and other benefits</li>\r\n<li>5-day work week (except for the 1st Sunday of the month)</li>\r\n</ul>\r\n<p><strong>Work hours:</strong>&nbsp;6:00 am to 2:00 pm including 1 hour lunch break (non-negotiable)</p>\r\n<p>&nbsp;</p>\r\n</li>\r\n</ul>', '<ul>\r\n<li>Minimum of six months of work experience (college internship or volunteering can be considered)</li>\r\n<li>Amazing customer service skills</li>\r\n<li>Excellent communication skills both written and verbal</li>\r\n<li>Problem-solving skills and solution focused</li>\r\n<li>Exceptional attention to detail and accuracy</li>\r\n<li>Excellent time management skills and prioritization of workload</li>\r\n<li>Analytical and mathematical skills</li>\r\n<li>Ability to work closely with a diverse and cross &ndash; cultural team</li>\r\n<li>Ability to follow instructions and work autonomously to achieve deadlines</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '9595logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(82, 18, ' Out Solu Nepal Pvt. Ltd.', 'loan-processing-assistant', 'Loan Processing Assistant', 2, 'Male/Female', '5', '2019-09-20 05:55:23', NULL, NULL, NULL, '2019-09-13 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-30', '29', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li><span lang=\"EN\">Must have completed a Bachelor degree in Business or Marketing or equivalent</span></li>\r\n<li><span lang=\"EN\">Excellent interpersonal, verbal and written communication skills in English</span></li>\r\n<li><span lang=\"EN\">Intermediate computer typing skills</span></li>\r\n<li><span lang=\"EN\">A good team player with the ability to work on own initiative</span></li>\r\n</ul>', '<ul>\r\n<li><span lang=\"EN\">Data entry of loan application information into lender platforms</span></li>\r\n<li><span lang=\"EN\">Assisting our clients with processing &amp; tracking home loan from pre-submission to settlement</span></li>\r\n<li><span lang=\"EN\">Liaising with clients to request supporting documentation and update them on the progress of their application.</span></li>\r\n<li><span lang=\"EN\">Forming relationships and communicating with clients, lenders, referrers and other business agents.</span></li>\r\n<li><span lang=\"EN\">Keeping active notes and managing applications in a dedicated Customer Relation Management (CRM) platform</span></li>\r\n<li><span lang=\"EN\">Working with finance brokers to ensure compliance processes are followed and maintained.</span></li>\r\n<li><span lang=\"EN\">Provide exceptional customer service</span></li>\r\n<li><span lang=\"EN\">Ready to take challenges and prove it</span></li>\r\n<li><span lang=\"EN\"><span lang=\"EN\"><span lang=\"EN\">Ability to work autonomously with set tasks&nbsp;</span></span></span>\r\n<p style=\"font-weight: 400;\"><strong>Essential skills and qualifications required to meet position objectives:</strong></p>\r\n<ul style=\"font-weight: 400;\">\r\n<li>Excellent Communication skills in English both verbal and written</li>\r\n<li>High attention to detail and accuracy</li>\r\n<li>Highly self-motivated and self-driven</li>\r\n<li>Professionally Presented</li>\r\n<li>Positive attitude and prepared to work in a team environment and meet deadlines</li>\r\n<li>Problem-solving skills, including the ability to resolve unusual and complex issues and then devise actionable solutions</li>\r\n<li>Responsible for managing time and prioritizing the assigned tasks</li>\r\n</ul>\r\n<p style=\"font-weight: 400;\"><strong>How to Apply</strong></p>\r\n<p style=\"font-weight: 400;\">Interested candidates are requested to submit CVs and Cover letter to&nbsp;<a href=\"mailto:hr@outsolu.com\">hr@outsolu.com</a>&nbsp;or Apply it online via portal.</p>\r\n</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '9590logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '5', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(83, 18, 'Golchha Organisation', 'account-officer', 'Account Officer', 2, 'Male/Female', '2', '2019-09-17 09:55:55', NULL, NULL, NULL, '2019-09-17 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-30', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<ul>\r\n<li>Detail knowledge of overall accounting</li>\r\n<li>Should be able to work on software</li>\r\n<li>Should have good Nepali typing Skills</li>\r\n<li>Knowledge of income tax and VAT</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(84, 18, 'Hulash Investment Pvt.Ltd', 'loan-officer', 'Loan Officer', 2, 'Male/Female', '2', '2019-09-17 05:52:02', NULL, NULL, NULL, '2019-09-17 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-30', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<p>Work Experience: Minimum experience in financial institutions and co-operatives.</p>\r\n<p>Driving License: Must have two wheeler License</p>\r\n<p>Other Skills: Must be knowledge to operate computer and willingness to travel.</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '6474logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(85, 18, 'Insight Spaces Pvt. Ltd (A Venture of CMS Group)', 'accountant', 'Accountant', 8, 'Male/Female', '1', '2019-09-17 10:41:57', NULL, NULL, NULL, '2019-09-17 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-19', '29', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Minimum bachelor\'s degree</li>\r\n<li>Atleast 1 year of work expereince</li>\r\n<li>Good Interpersonal &amp; Communication Skills</li>\r\n<li>Good at&nbsp; Software handling.</li>\r\n</ul>', '<ul>\r\n<li>Having working knowledge of (accounting software) and Microsoft excel and word.</li>\r\n<li>Should have basic idea about VAT and Tax laws.</li>\r\n<li>Prepare management report as required by the management.</li>\r\n<li>Ensure day to day activites related to account.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4312ensightes_spaces.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '10', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(86, 18, 'Ashish Nirman Sewa', 'accountant', 'Accountant', 8, 'Male/Female', '4', '2019-09-17 11:01:21', NULL, NULL, NULL, '2019-09-17 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-23', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<p>&nbsp;</p>\r\n<ul style=\"list-style-type: disc;\">\r\n<li>Manage all accounting transactions</li>\r\n<li>Publish financial statements in time</li>\r\n<li>Handle monthly, quarterly and annual closings</li>\r\n<li>Reconcile accounts payable and receivable</li>\r\n<li>Ensure timely bank payments</li>\r\n<li>Compute taxes and prepare tax returns</li>\r\n<li>Manage balance sheets and profit/loss statements</li>\r\n<li>Audit financial transactions and documents</li>\r\n<li>Reinforce financial data confidentiality and conduct database backups when necessary</li>\r\n<li>Comply with financial policies and regulations</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '1932logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '25', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(87, 18, 'Janata Capital Limited', 'finance-and-administration-off', 'Finance and Administration Officer', 2, 'Male/Female', '1', '2019-09-20 05:42:15', NULL, NULL, NULL, '2019-09-17 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-23', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Highly confident, dynamic, thorough, pragmatic and intuitive</li>\r\n<li>Excellent oral and written communication skills in English and Nepali</li>\r\n<li>High level of proficiency in MS-office and other soft skill</li>\r\n<li>Ability to work independently or as an active member of a team</li>\r\n<li>Ability to work under pressure</li>\r\n</ul>', '<ul>\r\n<li>Prepare, vouch and supervise day to day financial activities in Software</li>\r\n<li>Ensure smooth functioning of operational activities as per the guidelines and procedures of the Capital</li>\r\n<li>Prepare and monitor annual budgets</li>\r\n<li>Perform financial forecast and financial analysis</li>\r\n<li>Prepare Financial statement, annual reports and other relevant reports on timely basis</li>\r\n<li>Prepare MIS reports within predefined interval and reporting to senior management on timely basis</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '5942janata.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '1', '', '', NULL, NULL, NULL, NULL, NULL, '1'),
(88, 18, 'Classic Tech ', 'account-officer', 'Account Officer', 171, 'Male/Female', '4', '2019-09-18 05:29:39', NULL, NULL, NULL, '2019-09-18 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-01', '28', '', '2', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Must have completed Bachelor level in related field</li>\r\n<li>Must have at least 2 years of experience in related field</li>\r\n<li>Should have good knowledge of accounts and accounting terminologies</li>\r\n<li>Must have 2 wheeler with valid license</li>\r\n</ul>', '<ul>\r\n<li>Document financial transactions by analyzing documents and raising vouchers along the knowledge of taxation systems</li>\r\n<li>Preparation of Vouchers and entry into the system while complying with government policy by studying existing and new legislation, enforcing adherence to requirements, and advising management on needed actions</li>\r\n<li>Handle general account queries, check invoices for inaccuracies and budgeting, Finance Planning, Handling Tax matters, annual budget preparation</li>\r\n<li>Prepares special financial reports by collecting, analyzing, and summarizing account information and trends, Contact clients about invoices that are past due while maintaining records of business costs, such as labor &amp; material</li>\r\n<li>Payable Management and Scheduling</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '8508classic.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'other', '', '', NULL, NULL, NULL, NULL, '1'),
(89, 18, 'Home Appliance Company', 'accountant', 'Accountant', 177, 'Male/Female', '1', '2019-09-18 06:30:13', NULL, NULL, NULL, '2019-09-18 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '4', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<ul>\r\n<li>Prepares asset, liability, and capital account entries by compiling and analyzing account information.</li>\r\n<li>Documents financial transactions by entering account information.</li>\r\n<li>Recommends financial actions by analyzing accounting options.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4005hac.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(90, 18, 'Plastics industry', 'accounts-manager', 'Accounts Manager', 4, 'Male/Female', '1', '2019-09-18 07:05:00', NULL, NULL, NULL, '2019-09-18 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-01', '28', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"87\";}', NULL, NULL, '', '<ul>\r\n<li>Operating as the lead point of contact for any and all matters specific to your accounts.</li>\r\n<li>Prepare reports on account status.</li>\r\n<li>Ensure the timely and successful delivery of our solutions according to customer needs and objectives.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7814plastic.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '2', 'master', '', '', NULL, NULL, NULL, NULL, '1'),
(91, 18, 'Trading Company', 'accountant', 'Accountant', 175, 'Male/Female', '1', '2019-09-18 09:25:55', NULL, NULL, NULL, '2019-09-18 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-20', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<ul>\r\n<li>Making vat bills and keeping track of purchase bills party wise ( for each vendor )</li>\r\n<li>Managing factory inventory&nbsp;</li>\r\n<li>Making monthly balance sheets&nbsp;</li>\r\n<li>Keeping track of Project expenditures&nbsp;</li>\r\n<li>Customizing a new Tally program to suit our needs&nbsp;</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7480trading.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '3', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(92, 17, 'A FMCG distribution company', 'accounts-manager', 'Accounts Manager', 2, 'Male/Female', '1', '2019-09-19 05:49:43', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-15', '28', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4241logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'CA/ACCA', '', NULL, NULL, NULL, NULL, NULL, '1'),
(93, 18, 'SK Ventures Pvt. Ltd.', 'financial-officer', 'Financial Officer', 8, 'Male/Female', '2', '2019-09-19 06:18:04', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '189', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<p>Hard working passionate individual who can work under pressure.</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '4119skventures_logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'CA', '', NULL, NULL, NULL, NULL, NULL, '1'),
(94, 18, 'SK Ventures Pvt. Ltd.', 'investment-manager', 'Investment Manager', 8, 'Male/Female', '3', '2019-09-19 06:18:39', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '8738skventures_logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'MBA', '', NULL, NULL, NULL, NULL, NULL, '1'),
(95, 18, 'SK Ventures Pvt. Ltd.', 'accountant', 'Accountant', 8, 'Male/Female', '2', '2019-09-19 06:19:22', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<p>Should be able to do all entries in accounting softwares.</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '1956skventures_logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(96, 18, 'Recruitment Organization', 'accountant', 'Accountant', 182, 'Male/Female', '2', '2019-09-19 06:28:50', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', 'Not Required', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<p>Core knowledge of accounting and tally software along with tax and VAT system of Nepal.</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '3953logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(97, 18, 'Ujyalo Foundation', 'operations-manager', 'Operations Manager', 6, 'Male/Female', '1', '2019-09-19 06:56:48', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-27', '30', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>At least 2 years of professional administrative experience&nbsp;</li>\r\n<li>Masters in Business Administration (MBA)&nbsp;<strong>Preferred&nbsp;</strong></li>\r\n<li>Bachelor\'s degree in Finance, Business Administration, or other related studies required&nbsp;</li>\r\n<li>Proficient in Microsoft Office Suite&nbsp;</li>\r\n<li>Knowledge and experience with accounting software&nbsp;\r\n<p><strong>Personal Attitudes and Behavior :</strong></p>\r\n<ul>\r\n<li>Excellent interpersonal, verbal, and written communications skills&nbsp;</li>\r\n<li>Ability to meet deadlines, and report challenges and opportunities as needed&nbsp;</li>\r\n<li>Innovative, self-driven and team player&nbsp;</li>\r\n<li>Ability to work effectively both independently and in a team-based environment&nbsp;</li>\r\n<li>Demonstrate a willingness to be flexible and adaptable to changing priorities&nbsp;</li>\r\n<li>Flexibility with work hours as needed&nbsp;</li>\r\n</ul>\r\n</li>\r\n</ul>', '<ul>\r\n<li>Monitor and manage the overall operations of the organization including Administration and Finance&nbsp;</li>\r\n<li>Plan, oversee, and arrange program-based logistics for smooth and efficient operations&nbsp;</li>\r\n<li>Track and ensure recurrent expenditures and program related expenses like payroll, rent and utilities are paid on time&nbsp;</li>\r\n<li>Develop, maintain and monitor all fundraising and accounting systems and procedures capturing all pledges, billings and receipts and for the recording of all revenue transactions&nbsp;</li>\r\n<li>Manage grantor contracts and maintain archival and administrative files&nbsp;</li>\r\n<li>Assist and lead the fundraising related activity conducted by the Foundation&nbsp;&nbsp;\r\n<p>&nbsp;</p>\r\n</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '9952ujyalo.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Master', '', NULL, NULL, NULL, NULL, NULL, '1'),
(98, 18, 'Polaris Technology Nepal', 'administration-and-accounts-of', 'Administration and Accounts Officer', 169, 'Male/Female', '1', '2019-09-19 07:05:31', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-02', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Must have completed Bachelor&rsquo;s Degree&nbsp;</li>\r\n<li>Must have 1-2 Years of experience in a similar capacity</li>\r\n<li>Must have working-level knowledge of the Tally ERP</li>\r\n</ul>', '<ul>\r\n<li>Identify the daily needs of materials in organization and ordering them.</li>\r\n<li>Maintain polite and professional communication via phone, e-mail, and mail.</li>\r\n<li>Record keeping of the transaction relating to the business.</li>\r\n<li>Posting the accounting entries, prepare the payments.</li>\r\n<li>Follow-up for the receivables of the company.</li>\r\n<li>Filing of the monthly VAT and TDS returns.</li>\r\n<li>Ensure timely payments of the VAT and Taxes.</li>\r\n<li>Complete the banking related transaction.</li>\r\n<li>Complete the legal and compliance related works of the organization.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '3991polaris.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(99, 18, 'Excel Development Bank Ltd.', 'assistant', 'Assistant', 2, 'Male/Female', '1', '2019-09-19 07:32:23', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:4:{i:0;s:2:\"85\";i:1;s:2:\"57\";i:2;s:2:\"87\";i:3;s:2:\"92\";}', NULL, NULL, '', '<ul>\r\n<li>Bachelors Degree in Management/Science from a recognized University with minimum 50% or equivalent with at least 2 years of Credit related work experience in any bank &amp; financial institutions</li>\r\n<li>Basic computer knowledge is must</li>\r\n<li>Proficiency in operating Pumori Plus IV Banking software shall be an added advantage for all levels</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '6802excellogo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(100, 18, 'Homtek Sanitary Ware', 'accountant', 'Accountant', 177, 'Female', '1', '2019-09-19 09:05:48', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '29', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Bachelors degree completed with atleast Two years or more experience of accounting or auditing, preferably in similar organization&nbsp;</li>\r\n<li>Can demonstrate good accounting skills, knowledge of standard accounting principles, knowledge of taxation, legal provisions and requirements</li>\r\n<li>Have team engagement ability, good communication skills with team members, ability to lead</li>\r\n<li>Ability to communicate in English</li>\r\n<li>Skills of operating accounting software (swastik)</li>\r\n<li>Skills of budgeting and maintaining internal control</li>\r\n</ul>', '<ul>\r\n<li>Maintain bookkeeping and accounting process of the project and income and expenses</li>\r\n<li>Review advance request &amp; settlement from the project team for implementation of the program</li>\r\n<li>Produce monthly financial status report to share with a partner, the senior team in the office and executive board</li>\r\n<li>Prepare for statutory and project periodic financial audit and facilitate audit process</li>\r\n<li>Educate project team on the financial process requirements and procedures</li>\r\n<li>Suggest Office-in-Charge on the need of amendment and adoption of new policies, procedures on the financial management</li>\r\n<li>Vendor dealing, negotiation and preparation of comparison sheet for vendor selection</li>\r\n<li>Preparation of salary sheet, tax calculation and ensure time transfer of salary, and deposition of statutory taxes</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7097homtek.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(101, 18, 'Emerging Nepal Limited', 'accountant', 'Accountant', 167, 'Male', '1', '2019-09-19 09:31:25', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-17', '29', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:3:\"138\";}', NULL, NULL, '<p>&nbsp;</p>\r\n<ul style=\"list-style-type: disc;\">\r\n<li>Competent in using accounting software (Tally) and excel</li>\r\n<li>Knowledgeable about VAT and&nbsp; TAX</li>\r\n<li>Proper knowledge&nbsp;of the latest accounting rules and theories</li>\r\n<li>Accurate and detail-oriented</li>\r\n<li>Sincere and punctual</li>\r\n<li><strong>Must be willing to relocate to Simikot, Humla for atleast 6 months in a year.</strong></li>\r\n<li><strong>Relevant experience in accounting/administration of a Hotel/Restaurant will be an added advantage.&nbsp;</strong>\r\n<p>Professional Skills Required: Nepali Typing, Business Development, Administrstion, Account Coordination, Data Entry</p>\r\n</li>\r\n</ul>', '<p>&nbsp;</p>\r\n<ul>\r\n<li>Must be able to establish and set up effective accounting and financial reporting system for a hotel</li>\r\n<li>Must be able to implement good internal control system, establish key control points and schedule monitoring for control assurance</li>\r\n<li>Must be able to manage the entire accounts and finance department of hotel</li>\r\n<li>Must be able to generate Key Performance Indicators and Key Financial Indicators to the management</li>\r\n<li>Must have a practical knowledge of Tax, VAT&nbsp; and Labor laws of Nepal</li>\r\n<li>Must be capable to handle/ manage payroll, inventory, tax audit, internal audit and credit control amongst other regular accounting and financial requirement</li>\r\n<li>Must have good knowledge of bank finances available from local banks and be capable of dealing with Local Branch Manager of the Bank</li>\r\n<li>Must be capable to forecast the financial requirement of a hotel with analysis and assessment of the financial strength and weakness of a hotel</li>\r\n<li>Must be capable of preparing the periodic Balance Sheet, Cash Flow Statement and Income Statement</li>\r\n<li>Preparation of Board Minute and Legal Documents</li>\r\n<li>Command over Nepali Typing is recommended</li>\r\n<li>Other duties as assigned by Management</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7715enl.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(102, 18, 'Sparrow SMS ', 'account-officer', 'Account Officer', 180, 'Male', '1', '2019-09-19 09:39:07', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-21', '28', '', '2', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Ability to work under pressure</li>\r\n<li>Internet friendly</li>\r\n<li>Good understanding about Mathematics&nbsp;</li>\r\n<li>Idea about all type of latest taxation rules&nbsp;</li>\r\n<li>Good knowledge of CIT/PF/Insurance</li>\r\n<li>Experience in working with current IRD web application (E-TDS Filling, VAT Returns, Estimated Tax)</li>\r\n<li>Preference will be given to one who has worked in the accounts department of an IT company</li>\r\n</ul>', '<ul>\r\n<li>Prepare, examine, and analyze accounting records, financial statements, and other financial reports to assess accuracy, completeness, and conformance to reporting and procedural standards</li>\r\n<li>Compute taxes owed and prepare tax returns, ensuring compliance with payment, issuing bills, payment follow up, reporting and other tax requirements</li>\r\n<li>Analyze business operations, trends, costs, revenues, financial commitments, and obligations, to project future revenues and expenses or to provide advice</li>\r\n<li>Develop, maintain, and analyze budgets, preparing periodic reports that compare budgeted costs to actual costs</li>\r\n<li>Bank and party reconciliation, salary disbursement, manual voucher posting etc</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '4218sparrow.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(103, 18, 'Aperion', 'finance-manager', 'Finance Manager', 181, 'Male/Female', '1', '2019-09-19 11:20:28', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-24', '28', '', '5', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>A Masters of Accounting degree or similar field</li>\r\n<li>Five years&rsquo; experience of financial management in the NGO sector</li>\r\n<li>Proven track record of managing multiple donor accounts successfully</li>\r\n<li>Proficient with Microsoft Excel in particular, internet, e-mail and other tools of electronic communication and research</li>\r\n<li>Proficiency in GAP , IFRS and NFRS</li>\r\n<li>Demonstrated competence in interacting and negotiating at a senior level</li>\r\n<li>Ability to maintain the highest level of honesty and professionalism when dealing with staff, funders, project participants, and partner organizations</li>\r\n</ul>', '<div class=\"card-group\">\r\n<div class=\"card border-0\">\r\n<div class=\"card-text p-2\">\r\n<p><strong>Actively Supporting The Organisation\'s Values And Culture</strong></p>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Understanding how Apeiron works in practice</li>\r\n<li>Taking practical steps to maintain their commitment to Apeiron&rsquo;s values</li>\r\n<li>Encouraging senior managers and board members to recognize and consider their financial management responsibilities</li>\r\n<li>Helping create a culture that balances centralised control with decentralised decision-making.</li>\r\n<li>Assist in developing project budgets</li>\r\n<li>Develop annual programme and organizational budgets, overseeing and supervising budget plans of projects with the executive director</li>\r\n<li>Serve as primary contact for multiple project staff; provide financial analysis, management support and guidance</li>\r\n<li>With other team members, ensure that services are delivered efficiently, effectively and in a courteous and timely way</li>\r\n<li>Communicate regularly with project leaders and provide a high level of collaboration around short and long term financial management and sustainability</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><strong>&nbsp;</strong><strong>Setting Up And Running Finance Systems</strong></p>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Support budget creation, budget projections and analysis of expenses as needed</li>\r\n<li>Review salaries being charged to projects and adjust to ensure correct allocation</li>\r\n<li>Prepare, review and distribute monthly reports, funder reports and others. Document and address issues requiring attention and/or further discussion</li>\r\n<li>Analyze and monitor projects&rsquo; fund and cash balances and keep project and project team informed of status, issues</li>\r\n<li>Work with staff accountants to ensure timely and accurate processing of payables, deposits and billings</li>\r\n<li>Manage all forex payments, requests and transfers</li>\r\n<li>Deliver funding reports</li>\r\n<li>Develop all financial risk and develop early warning systems</li>\r\n<li>Supervise all procurement, ensuring alignment with policies and donor contracts</li>\r\n<li>Monitor project expenditure and implement corrective action where such expenditure exceeds or is not consistent with agreed budgets and donor requirements</li>\r\n<li>Prepare monthly bank reconciliations and petty cash/cash fund reconciliation</li>\r\n<li>Ensure all documents are electronically and physically filed and available for internal and external audits</li>\r\n<li>Correct and rectify any recommendations made by auditors</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n&nbsp;<strong>Helping Stakeholders Understand&nbsp;</strong><strong>Financial</strong><strong>&nbsp;Management Issues</strong>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Establish, implement, educate staff and project team about and manage effective financial systems and controls to ensure sound management of funds&nbsp;</li>\r\n<li>Ensure that project leaders are provided with the tools they need to manage their budgets</li>\r\n<li>Manage and supervise the work of the Finance officer ensuring that all financial administrative tasks are completed accurately and timeously</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n&nbsp;<strong>Supporting Relationships With Partner Organisations</strong>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Maintain sound relations with our banking partner/s and deal with all queries related to banking</li>\r\n<li>Assessing partners\' financial management capacity</li>\r\n<li>Monitoring how partners use funds</li>\r\n<li>Supporting partner organisations to develop their capacity</li>\r\n<li>Handling formal agreements with partner organisations</li>\r\n</ul>\r\n&nbsp;<strong>Supporting Audits And Meeting Legal Requirements</strong><br />\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Planning and supporting internal and external audits</li>\r\n<li>Presenting auditors\' reports and management letters to senior managers and board members</li>\r\n<li>Understanding the NGO\'s legal requirements and helping senior managers and board members understand them</li>\r\n<li>Meeting legal requirements, including submitting reports to government agencies as required</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"card-group\">\r\n<div class=\"card border-0\">\r\n<div class=\"card-header p-2\">\r\n<h6 class=\"my-1\"><strong>&nbsp;</strong></h6>\r\n</div>\r\n</div>\r\n</div>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '5690apeiron.jpg', NULL, 'public', NULL, '', 0, 0, '', '', '3', 'Master', '', NULL, NULL, NULL, NULL, NULL, '1'),
(104, 18, 'A & E Engineering Consultancy Company', 'accountant', 'Accountant', 6, 'Male/Female', 'Few', '2019-09-19 10:01:44', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<ul>\r\n<li>Prepares asset, liability, and capital account entries by compiling and analyzing account information.</li>\r\n<li>Documents financial transactions by entering account information.</li>\r\n<li>Recommends financial actions by analyzing accounting options.</li>\r\n<li>Summarizes current financial status by collecting informations preparing balance sheet, profit and loss statement, and other reports.</li>\r\n<li>Maintains accounting controls by preparing and recommending policies and procedures.</li>\r\n<li>Reconciles financial discrepancies by collecting and analysing account information.</li>\r\n<li>Secures financial information by completing data base backups.</li>\r\n<li>Prepares payments by verifying documentation, and requesting disbursements.</li>\r\n<li>Prepares special financial reports by collecting, analysing, and summarizing account information and trends.</li>\r\n<li>Maintains customer confidence and protects operations by keeping financial information confidential</li>\r\n<li>Assist in the processing of balance sheets, income statements and other financial statements</li>\r\n<li>According to legal and company accounting and financial guidelines</li>\r\n<li>Assist with reviewing of expenses, payroll records etc. as assigned</li>\r\n<li>Update financial data in databases to ensure that information will be accurated and immediately available when needed \'</li>\r\n<li>Prepare and submit weekly/monthly reports.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '6900logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(105, 18, 'Global Action Nepal (GAN)', 'finance-and-admin-officer', 'Finance and Admin Officer', 181, 'Male/Female', '1', '2019-09-19 10:16:30', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-24', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<ul>\r\n<li>Account keeping in with efficiency and effectiveness</li>\r\n<li>Management of financial, admin, human resources and logistics as per the organization and project policies and compliances</li>\r\n<li>Prepare budget, budget note and financial reports in English language with effective communication</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7820gan-nepal.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(106, 18, 'A Reputed School', 'accountant', 'Accountant', 5, 'Female', '1', '2019-09-19 10:34:36', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-23', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul style=\"list-style-type: disc;\">\r\n<li>Having working knowledge of accounting software, Microsoft excel and word.</li>\r\n<li>Should have basic idea about VAT, Tax, Tally and Billing Procedure.</li>\r\n<li>Prepare management report as required by the management.</li>\r\n<li>Ensure day to day activities related to account.&nbsp;</li>\r\n</ul>', '<ul style=\"list-style-type: disc;\">\r\n<li>&nbsp;Must have good knowledge of operating Accounting Software packages.</li>\r\n<li>Must be willing to learn software package employed by the company.</li>\r\n<li>Good interpersonal and communication skills.</li>\r\n<li>Must be energatic, resourceful, willing to rearn and participate in company affairs and be a strong team player.</li>\r\n<li>Minimum bachelor degree</li>\r\n<li>S,art personality.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '1606logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(107, 18, 'Infotech Services Pvt. Ltd', 'accountant', 'Accountant', 6, 'Male', '1', '2019-09-19 10:47:19', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"51\";}', NULL, NULL, '<ul style=\"list-style-type: disc;\">\r\n<li>BBS/BBA</li>\r\n</ul>', '<ul style=\"list-style-type: disc;\">\r\n<li>Must have basic computer skill or Tally</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '7746logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(108, 18, 'Vie Tec Pvt Ltd.', 'accountant', 'Accountant', 180, 'Male', '1', '2019-09-19 11:28:53', NULL, NULL, NULL, '2019-09-19 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-20', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '<ul>\r\n<li>Prepares asset, liability, and capital account entries by compiling and analyzing account information</li>\r\n<li>Documents financial transactions by entering account information</li>\r\n<li>Recommends financial actions by analyzing accounting options</li>\r\n<li>Summarizes current financial status by collecting information, preparing balance sheet, profit and loss statement, and other reports</li>\r\n<li>Maintains accounting controls by preparing and recommending policies and procedures</li>\r\n<li>Reconciles financial discrepancies by collecting and analysing account information</li>\r\n<li>Secures financial information by completing database backups</li>\r\n<li>Prepares payments by verifying documentation, and requesting disbursements</li>\r\n<li>Prepares special financial reports by collecting, analysing, and summarizing account information and trends</li>\r\n<li>Maintains customer confidence and protects operations by keeping financial information confidential</li>\r\n<li>Assist in the processing of balance sheets, income statements and other financial statements according to legal and company accounting and financial guidelines</li>\r\n<li>Assist with reviewing of expenses, payroll records etc. as assigned</li>\r\n<li>Update financial data in databases to ensure that information will be accurately and immediately available when needed</li>\r\n<li>Prepare and submit weekly/monthly reports</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '5513logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '1', 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1');
INSERT INTO `jobs` (`id`, `eid`, `displayname`, `slug`, `jobtitle`, `jobcategory`, `preferredgender`, `requiredno`, `date_added`, `pmm`, `pdd`, `pyy`, `post_date`, `updatedate`, `apmm`, `apdd`, `apyy`, `applybefore`, `salaryrange`, `exprequire`, `noexperience`, `education`, `joblevel`, `jobtype`, `jobtype2`, `jobtype3`, `jobtype4`, `otherstype`, `joblocation`, `brief`, `background`, `specification`, `requirements`, `howtoapply`, `acceptonline`, `onlineap`, `emailap`, `postap`, `video_cv`, `isNewspaperJob`, `job_display_in`, `isWalkin`, `pobox`, `adminPosted`, `complogo`, `banner_image`, `post_status`, `apply_by_faculty`, `apply_by_age`, `from_age`, `to_age`, `postedin`, `orgemail`, `no_of_views`, `required_education`, `expected_faculty`, `other_faculty`, `slc_docs`, `docs_11_12`, `bachelor_docs`, `masters_docs`, `isEmailed`) VALUES
(109, 18, 'One House Solution', 'account-receivable-lead', 'Account Receivable Lead', 3, 'Male/Female', '1', '2019-09-20 04:54:54', NULL, NULL, NULL, '2019-09-20 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-19', '30', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul>\r\n<li>Run account receivables reports daily / weekly for each client account</li>\r\n<li>Prioritize claims for account receivables work based on aging, rupee value, and other criteria</li>\r\n<li>Assign account receivables accounts and prioritized claims to account receivables associates for completion on a daily or weekly as appropriate</li>\r\n<li>Assign collection targets for each client account</li>\r\n<li>Audit account receivables work to ensure collection, productivity and quality targets are met&nbsp;</li>\r\n<li>Attend management meetings to present results and formulate continual process improvement and effectiveness</li>\r\n<li>Customer accounts reconciliation&nbsp;\r\n<p>Benefits</p>\r\n<ul>\r\n<li>High growth Opportunities</li>\r\n<li>Excellent work atmosphere</li>\r\n<li>Remuneration commensurate with industry standards</li>\r\n</ul>\r\n</li>\r\n</ul>', '<ul>\r\n<li>Good knowledge in Billing and Accounting process capability to lead team, business acumen, strategic thinking, entrepreneurial spark and high energy levels</li>\r\n<li>Graduates with Good Communication Skills (Oral and written) and Analytical Skills required for Account Receivables</li>\r\n<li>Candidate will be responsible for Client communication for collections&nbsp;</li>\r\n<li>Also, will be responsible for fixing claims and processing the claims</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '6298one_house_solution.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(110, 18, 'Louis Berger', 'senior-finance-and-compliance-', 'Senior Finance And Compliance Manager', 166, 'Male/Female', '1', '2019-09-20 05:19:24', NULL, NULL, NULL, '2019-09-20 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-26', '28', '', '5', NULL, '19', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<p><strong>Selection Requirements&nbsp;</strong></p>\r\n<ul>\r\n<li>Very good command of English and Nepali&nbsp;</li>\r\n<li>Master\'s degree or equivalent in Business Administration, Finance/Accounting&nbsp;</li>\r\n<li>At least five years of confirmed experience with USAID project (s) in the area of financial management and compliance&nbsp;</li>\r\n<li>Have experience of administration</li>\r\n<li>&nbsp;Have strong analytical &amp; quantitative skills</li>\r\n<li>&nbsp;Have a strong command of IT Office Tools</li>\r\n<li>&nbsp;Have good communication skills Demonstrate that you work in teams Ability to work under pressure and adhere to deadlines Ability to manage change&nbsp;</li>\r\n</ul>\r\n<p>This is a senior level position. Compensation will be based on applicable policies of USAID and Louis Berger. Initial duration will be for one year with a possibility of extension. A 3-month probation period will ensue upon hiring. Only finalists will be contacted.</p>', '<p>The Senior Finance and Compliance Manager takes responsibility in managing day-to-day finance and administration function in the organization that would include project budget plans, account keeping, reporting, conducting financial analysis and facilitating internal and external audits and day to day running of the project. S/he must ensure proper compliance of the contract and prevailing relevant laws of Nepal. S/he will be responsible for the following overarching tasks:&nbsp;</p>\r\n<ul>\r\n<li>Establish all field accounting and procurement operations and ensure that Louis Berger policies and procedures are implemented in strict adherence to USAID regulations &amp; corporate guidelines.</li>\r\n<li>Coordinate with and assist partner and other subcontractors on project related financial management concerns</li>\r\n<li>Manage the project\'s cash operations to ensure the timely and effective transfer of financial resources between Louis Berger operations and Nepal office in support of project activities</li>\r\n<li>Oversee the development of inventory controls and procedures for field operations, and ensure the compliance by all offices</li>\r\n<li>Respond to Louis Berger home office on requests associated with internal and external audits; working with the project team to provide necessary documentations to comply with audit and financial review requirements</li>\r\n<li>Prepare financial reports as required by the project and Louis Berger corporate management</li>\r\n<li>Monthly closing of Field Cash Report (FCR) and reconciliation of daily cash disbursement Excel spreadsheet</li>\r\n<li>Review employee expense reports for completeness and accuracy and ensure proper completion of approved forms and templates with all required support document and receipts, and supervisor\'s signature. In coordination with the Home Office, provide the project management with regular updates to budgets, expenditures, Value for Money Plan and burn rate to. Interact with project staff as needed to help facilitate project deliverable</li>\r\n<li>Custodian of issued Purchase Orders to include assigning of numbers, gathering of signatures, tracking of status, and maintaining a permanent file for relevance</li>\r\n<li>Serve as contact person with landlords regarding lease agreements and interaction with project expatriate as needed to help facilitate housing requirements. Provide remote and on-site oversight and support to field staff in satellite offices as and when needed&nbsp;</li>\r\n<li>Serve as contact person in handling visa request for project expatriates&nbsp;and consultants.&nbsp;</li>\r\n<li>Handle travel arrangement, including airfare, transportation, lodging and travel advances. Handle project training and events arrangement, including airfare, transportation, lodging, meals</li>\r\n<li>Conduct new employee orientation</li>\r\n<li>Handle the monthly local national payroll to include worksheet, pay slips, and timesheets and the physical distribution of local national salary to ensure privacy and orderly process</li>\r\n<li>Monitor and claim VAT on periodic basis by working closely with USAID Payment and deduction of CIT and Tax on sources; keep track of CIT and Tax details; provide copy of tax deposit receipt of IRO to vendors/landlord as per their request. Coordinate with local banks for opening new bank account for staff and banking transactions Keep records of staff employment documents such as contracts and contract amendment, TORs and job descriptions, promotions, transfers, performance reviews, terminations, and employee statistics for reporting purposes. Undertake periodic field visits. Report to the Deputy Chief of Party and assume other management tasks determined by him/her</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '8114louis.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Master', '', NULL, NULL, NULL, NULL, NULL, '1'),
(111, 18, 'Pashchimodaya Saving & Credit Co-operative Ltd', 'cashier', 'Cashier', 2, 'Male/Female', '2', '2019-09-20 05:27:54', NULL, NULL, NULL, '2019-09-20 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-26', '29', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '<ul style=\"list-style-type: disc;\">\r\n<li>Preference to experience.</li>\r\n</ul>', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '2492logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(112, 18, 'Manjushree Finance Limited', 'branch-manager', 'Branch Manager', 2, 'Male/Female', '1', '2019-09-20 05:40:33', NULL, NULL, NULL, '2019-09-20 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-25', '28', '', '4', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:3:\"279\";}', NULL, NULL, '', '<ul>\r\n<li>At least Bachelor\'s degree in management. However, preference shall be given to the candidates higher education qualification&nbsp;</li>\r\n<li>More than or equals to 4 years of banking experience in commercial Bank / development Bank or finance companies. Must have an exposure in deposit marketing, credit and operation of the branch office</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '9224manjushree.jpg', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(113, 18, 'A FMCG distribution company', 'accounts-manager', 'Accounts Manager', 3, 'Male/Female', '1', '2019-09-20 06:20:49', NULL, NULL, NULL, '2019-09-20 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-10-15', '28', '', '3', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"41\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '6776logo.png', NULL, 'public', NULL, '', 0, 0, '', '', '3', 'CA/ACCA', '', NULL, NULL, NULL, NULL, NULL, '1'),
(114, 18, 'Hulash Investment Pvt.Ltd', 'loan-officer', 'Loan Officer', 2, 'Male/Female', '2', '2019-09-20 06:21:44', NULL, NULL, NULL, '2019-09-20 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-27', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:3:\"125\";}', NULL, NULL, '', '<ul style=\"list-style-type: disc;\">\r\n<li>Work Experience: Minimum experience in Financial institution or Cooperatives.</li>\r\n<li>Driving License: Must have two wheeler license.</li>\r\n<li>Other Skill: Must be knowledge to operate computer and willingness to frequent travel.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '8941logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1'),
(115, 18, 'Hulash Investment Pvt.Ltd', 'regional-loan-officer', 'Regional Loan Officer', 2, 'Male/Female', '3', '2019-09-20 06:30:37', NULL, NULL, NULL, '2019-09-20 04:00:00', '0000-00-00', NULL, NULL, NULL, '2019-09-27', '28', '', '1', NULL, '18', 'a:1:{i:0;s:2:\"23\";}', NULL, NULL, NULL, '', 'a:1:{i:0;s:2:\"95\";}', NULL, NULL, '', '<ul style=\"list-style-type: disc;\">\r\n<li>Work Experience: Minimum experience in financial institution or co-operatives.</li>\r\n<li>Driving License: Must have two wheeler license.</li>\r\n<li>Other skills: Must be knowledge to operate computer and willingness to frequent travel.</li>\r\n</ul>', NULL, 'No', 'No', 'No', 'No', '', 'a:2:{i:0;s:4:\"RJob\";i:1;s:4:\"NJob\";}', '', '0', NULL, '', '3059logo.png', NULL, 'public', NULL, '', 0, 0, '', '', NULL, 'Bachelor', '', NULL, NULL, NULL, NULL, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `seeker`
--

CREATE TABLE `seeker` (
  `id` int(11) NOT NULL,
  `email` varchar(35) DEFAULT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `summary` text,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `address_permanent` varchar(255) DEFAULT NULL,
  `address_current` varchar(255) DEFAULT NULL,
  `phone_cell` varchar(25) DEFAULT NULL,
  `phone_resisdance` varchar(25) DEFAULT NULL,
  `gender` enum('Male','Female','Other','Male/Female') NOT NULL,
  `dob` date NOT NULL,
  `marital_status` enum('Married','Single') DEFAULT 'Single',
  `nationality` int(11) DEFAULT NULL,
  `highest_qualification` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `have_work_experience` enum('Yes','No') DEFAULT 'No',
  `experience_years` int(11) DEFAULT NULL,
  `experience_months` int(11) DEFAULT NULL,
  `cjobposiiton` varchar(100) NOT NULL,
  `keyskills` text NOT NULL,
  `profile_summary` text NOT NULL,
  `desired_industry` varchar(255) DEFAULT NULL,
  `desired_functional_area` varchar(255) DEFAULT NULL,
  `desired_role` varchar(100) DEFAULT NULL,
  `desired_job_type` varchar(50) DEFAULT NULL,
  `desired_employment_type` varchar(100) DEFAULT NULL,
  `desired_shift` varchar(100) NOT NULL,
  `desired_expected_salary` int(11) NOT NULL,
  `desired_job_location` varchar(100) NOT NULL,
  `past_employer` varchar(100) NOT NULL,
  `current_employer` varchar(100) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `facebook` varchar(150) NOT NULL,
  `linkedin` varchar(150) NOT NULL,
  `resume` varchar(150) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime NOT NULL,
  `last_accessed` datetime NOT NULL,
  `isActivated` enum('1','0') NOT NULL DEFAULT '0',
  `activation_code` varchar(50) NOT NULL,
  `lastaccess` datetime NOT NULL,
  `token` varchar(150) NOT NULL,
  `oauth_provider` varchar(100) NOT NULL,
  `oauth_uid` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `locale` varchar(10) NOT NULL,
  `user_type` enum('registered','cv_only') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker`
--

INSERT INTO `seeker` (`id`, `email`, `username`, `password`, `summary`, `fname`, `mname`, `lname`, `address_permanent`, `address_current`, `phone_cell`, `phone_resisdance`, `gender`, `dob`, `marital_status`, `nationality`, `highest_qualification`, `faculty`, `have_work_experience`, `experience_years`, `experience_months`, `cjobposiiton`, `keyskills`, `profile_summary`, `desired_industry`, `desired_functional_area`, `desired_role`, `desired_job_type`, `desired_employment_type`, `desired_shift`, `desired_expected_salary`, `desired_job_location`, `past_employer`, `current_employer`, `profile_picture`, `facebook`, `linkedin`, `resume`, `date_created`, `date_modified`, `last_accessed`, `isActivated`, `activation_code`, `lastaccess`, `token`, `oauth_provider`, `oauth_uid`, `link`, `locale`, `user_type`) VALUES
(29, 'binodrajsingh@yahoo.com', '', NULL, NULL, 'Binod Raj', NULL, 'Singh', NULL, NULL, NULL, NULL, '', '0000-00-00', 'Single', NULL, '', '', 'No', NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, '', 0, '', '', '', '', '', '', '', '2019-09-17 19:27:48', '2019-09-17 15:27:56', '0000-00-00 00:00:00', '1', '', '0000-00-00 00:00:00', '', 'facebook', '2932791306747396', '', '', 'registered'),
(17, 'manjilpradhan@yahoo.com', 'manjilpradhan@yahoo.com', 'a4fdb4d8ad1ffda03369b6e874d379ac', NULL, 'Manjil', NULL, 'Pradhan', NULL, NULL, NULL, NULL, 'Male', '0000-00-00', 'Single', NULL, '', '', 'No', NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, '', 0, '', '', '', '', '', '', '9308manjil-pradhan.pdf', '2019-09-11 09:18:24', '2019-09-11 15:03:23', '0000-00-00 00:00:00', '0', '', '0000-00-00 00:00:00', '', '', '', '', '', 'cv_only'),
(18, 'kharelrabin@gmail.com', 'kharelrabin@gmail.com', '323dca815d02f4499fa3ee8c61ff1271', NULL, 'Rabin', NULL, 'Kharel', NULL, NULL, NULL, NULL, 'Male', '0000-00-00', 'Single', NULL, '', '', 'No', NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, '', 0, '', '', '', '', '', '', '4135rabin_kharel.pdf', '2019-09-11 09:19:19', '2019-09-11 15:04:19', '0000-00-00 00:00:00', '0', '', '0000-00-00 00:00:00', '', '', '', '', '', 'cv_only'),
(15, 'amitsaarthak17@gmail.com', 'amitsaarthak17@gmail.com', '30cef43ff6a4c2451145d3a3ec02b027', NULL, 'Amit', '', 'Poudel', NULL, 'Atrauli,Sarlahi, Nepal', '9863313839', NULL, 'Male', '1988-06-01', 'Single', NULL, '', 'other', 'No', 3, NULL, 'ACCOUNTS-SENIOR OFFICER', '', '', NULL, NULL, NULL, NULL, NULL, '', 28, '', '', '', '', '', '', '2347amit_poudel.pdf', '2019-09-10 04:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '', '2019-09-11 15:13:38', '', '', '', '', '', 'registered');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_education`
--

CREATE TABLE `seeker_education` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `education_program` varchar(50) DEFAULT NULL,
  `graduationyear` int(11) DEFAULT NULL,
  `instution` varchar(150) DEFAULT NULL,
  `board` varchar(150) DEFAULT NULL,
  `marks_secured_in` enum('Percentage','CGPA') NOT NULL,
  `marks_secured` varchar(50) DEFAULT NULL,
  `graduation_month` varchar(20) DEFAULT NULL,
  `current_studying` enum('1','0') DEFAULT NULL,
  `started_year` varchar(100) DEFAULT NULL,
  `started_month` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `seeker_experience`
--

CREATE TABLE `seeker_experience` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `title` varchar(225) NOT NULL,
  `company` varchar(150) DEFAULT NULL,
  `location` varchar(200) NOT NULL,
  `frommonth` varchar(20) DEFAULT NULL,
  `fromyear` varchar(20) DEFAULT NULL,
  `tomonth` varchar(20) DEFAULT NULL,
  `toyear` varchar(20) DEFAULT NULL,
  `currently_working` int(11) DEFAULT NULL,
  `roles_and_responsibilities` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `seeker_language`
--

CREATE TABLE `seeker_language` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `lang` varchar(50) DEFAULT NULL,
  `reading` varchar(20) DEFAULT NULL,
  `writing` varchar(20) DEFAULT NULL,
  `speaking` varchar(20) DEFAULT NULL,
  `listening` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `seeker_reference`
--

CREATE TABLE `seeker_reference` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `reference_name` varchar(100) DEFAULT NULL,
  `position` varchar(100) NOT NULL,
  `organization_name` varchar(100) NOT NULL,
  `mobile_number` varchar(25) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `other_number` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `seeker_training`
--

CREATE TABLE `seeker_training` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `institution` varchar(100) DEFAULT NULL,
  `course` varchar(150) DEFAULT NULL,
  `frommonth` varchar(20) DEFAULT NULL,
  `fromyear` int(11) DEFAULT NULL,
  `tomonth` varchar(20) DEFAULT NULL,
  `toyear` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `short_description` text COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `urlcode` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `title`, `content`, `short_description`, `logo`, `urlcode`) VALUES
(2, 'Recruitment', '<p style=\"text-align: justify;\"><img src=\"https://dac.technocreates.net/finance-job-nepal/tinymce/file_manager/source/hrconcept-.jpg?1568720986796\" alt=\"\" width=\"1010\" height=\"673\" /></p>\r\n<p style=\"text-align: justify;\"><img src=\"https://dac.technocreates.net/livedatabase/tinymce/file_manager/source/recr.jpg?1568203482440\" alt=\"\" /><img src=\"https://dac.technocreates.net/livedatabase/tinymce/file_manager/source/recr.jpg?1568203380738\" alt=\"\" />Finance Job Nepal Pvt. Ltd. recruitment team is committed to finding the right talent for numerous businesses throughout the country regardless of industry type. Along with the competency requirement, our choice for candidates for the clients will be who are well-suited to their work culture and its unique management style ensuring a better retention and better return on investment.</p>\r\n<p style=\"text-align: justify;\">Regardless of the requirement, our recruitment team realizes that providing a pool of resumes or sending off shortlisted candidates to the client is not always sufficient. We have an understanding of giving the best dedicated customer focus for each and every client we have with being flexible for their requirement at all times having their priorities understood to provide a better customer experience.</p>\r\n<p style=\"text-align: justify;\">Whether we are recruiting an assistant or a mid-level employee or a top notch senior manager or a director we always give the confidentiality the first place. Especially with executive search services we give the option to the client to select the venue for having discussions with the candidates. With a mutual understanding we entrust the client to have interviews on their premises when required or to have it on a place mutually agreed or in our office premises.</p>\r\n<p style=\"text-align: justify;\">We will act aggressively to find the best talent in many ways operating as the partner the client seeks for their recruitment or as consultants to exceed their expectations finding the right talent covering the entire recruitment cycle.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>', '', '4233', 'recruitment'),
(7, 'Labour Audit', '', '', '', 'labour-audit');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblnewsletter`
--

CREATE TABLE `tblnewsletter` (
  `newsid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `newstitle` text NOT NULL,
  `newscontents` longtext NOT NULL,
  `newsdate` datetime NOT NULL,
  `newsstatus` varchar(30) NOT NULL,
  `publish` enum('1','0') DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `topbanner`
--

CREATE TABLE `topbanner` (
  `id` int(11) NOT NULL,
  `leftlink` varchar(100) NOT NULL,
  `leftimage` varchar(100) NOT NULL,
  `rightlink` varchar(100) NOT NULL,
  `rightimage` varchar(100) NOT NULL,
  `jobseeker` varchar(100) NOT NULL,
  `employer` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `modules` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `modules`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$eyQmdzZaaF.XDGqaeXp05uRka5/nx7jZg6FuYgQ376rSdhUiME/qi', '', 'binaya619@gmail.com', NULL, 'aGhEaCD.-H0SBz-A.E75le67fc6ea3095a45eafd', 1555919481, '51YhFP6IFSi1CuCHW5Nttu', 1467791269, 1494332548, 1, 'Admin ', '', 'DAC', '', ''),
(2, '127.0.0.1', NULL, '$2y$08$f3AWSHNcFHceKGU5mhgctuqu/hICw.14lE3VMQRGjl6KMEadgtz1O', NULL, 'admin@financejobnepal.com', NULL, NULL, NULL, 'r/9zxwfNRXVl.hn2.2wBEu', 1494413182, 1568958052, 1, 'Suresh', 'Lamsal', 'Finance Job Nepal Pvt. Ltd.', '016226783', ''),
(3, '', 'user', '$2y$08$67pyVQlhZ2lnhKKURoaj.ONomY7enWAjNRyqTP9AFJTmOUjvdAwD.', NULL, 'user@financejobnepal.com', NULL, NULL, NULL, 'pcKMFoCXMxW6VG5ApcqLwu', 0, 1530687528, 1, 'Guest', '', 'Finance Job Nepal', '9841', ''),
(4, '', 'recruiter', '$2y$08$dTdJg2DIf/R7SFq.AgmhQOfXjucCV/yzxV97NMZwrSNP5hAwyurR.', NULL, 'recruiter@financejobnepal.com', NULL, NULL, NULL, 'esx33ZrGIKfdCaj9KDS2Ge', 1522035435, 1552193057, 1, 'Recruiter', '', 'Finance Job Nepal', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(94, 1, 1),
(95, 2, 1),
(96, 3, 2),
(97, 4, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertisement`
--
ALTER TABLE `advertisement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dropdown`
--
ALTER TABLE `dropdown`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker`
--
ALTER TABLE `seeker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_education`
--
ALTER TABLE `seeker_education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_experience`
--
ALTER TABLE `seeker_experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_language`
--
ALTER TABLE `seeker_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_reference`
--
ALTER TABLE `seeker_reference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_training`
--
ALTER TABLE `seeker_training`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblnewsletter`
--
ALTER TABLE `tblnewsletter`
  ADD PRIMARY KEY (`newsid`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topbanner`
--
ALTER TABLE `topbanner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertisement`
--
ALTER TABLE `advertisement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dropdown`
--
ALTER TABLE `dropdown`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=280;

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `seeker`
--
ALTER TABLE `seeker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `seeker_education`
--
ALTER TABLE `seeker_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `seeker_experience`
--
ALTER TABLE `seeker_experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `seeker_language`
--
ALTER TABLE `seeker_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seeker_reference`
--
ALTER TABLE `seeker_reference`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seeker_training`
--
ALTER TABLE `seeker_training`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblnewsletter`
--
ALTER TABLE `tblnewsletter`
  MODIFY `newsid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topbanner`
--
ALTER TABLE `topbanner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
