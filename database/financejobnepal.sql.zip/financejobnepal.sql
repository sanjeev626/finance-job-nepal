-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2019 at 07:07 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `financejobnepal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin` varchar(50) NOT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin`, `pass`, `email`, `fullname`, `title`) VALUES
(1, 'admin', 'ex+LDv3rDn1HXumipiwNkcnprH8kBEUhrKwvm2bDZXE=', 'info@globaljob.com.np', 'Global Jobs', 'Global Jobs');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE `advertisement` (
  `id` int(11) NOT NULL,
  `addtitle` varchar(150) DEFAULT NULL,
  `image` varchar(220) DEFAULT NULL,
  `addtype` enum('type1','type2') DEFAULT NULL,
  `addstatus` enum('publish','unpublish') DEFAULT NULL,
  `website` varchar(100) NOT NULL,
  `background_color` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertisement`
--

INSERT INTO `advertisement` (`id`, `addtitle`, `image`, `addtype`, `addstatus`, `website`, `background_color`) VALUES
(4, 'Digital Agency Catmandu', '9650kisspng-nepal-tourism-board-nepal-marathon.jpg', NULL, 'publish', 'https://www.digitalagencycatmandu.com/', ''),
(5, 'Advertisement', NULL, NULL, 'publish', 'https://www.digitalagencycatmandu.com/', '#ff8040');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `jid` int(11) DEFAULT NULL,
  `eid` int(11) NOT NULL,
  `appdate` date NOT NULL,
  `status` enum('0','shortlisted','rejected') NOT NULL DEFAULT '0',
  `remarks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `sid`, `jid`, `eid`, `appdate`, `status`, `remarks`) VALUES
(1, 2, 4, 2, '2019-05-15', 'rejected', ''),
(2, 2, 5, 2, '2019-05-15', '0', ''),
(3, 6, 5, 2, '2019-06-05', '0', ''),
(5, 6, 6, 2, '2019-06-13', '0', '');

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `articles` text,
  `cr_date` varchar(20) DEFAULT NULL,
  `up_date` varchar(20) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `stat` enum('Y','N') DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `slug`, `title`, `articles`, `cr_date`, `up_date`, `author`, `stat`) VALUES
(0, 'blog', 'Blog', '<p>this is for testing&nbsp;</p>', '2019-05-23 12:36:34', '2019-05-23 12:36:34', NULL, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `slug` varchar(200) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `articles` text,
  `image` varchar(200) NOT NULL,
  `cr_date` varchar(20) DEFAULT NULL,
  `up_date` varchar(20) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `stat` enum('Y','N') DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `cat_id`, `slug`, `title`, `articles`, `image`, `cr_date`, `up_date`, `author`, `stat`) VALUES
(2, NULL, 'dot-wedge-datasheet', 'Dot Wedge Datasheet', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '372050259453_124938715221567_8937636993752367104_n.jpg', '2019-09-09 03:12:00', '2019-09-09 03:12:00', NULL, 'Y'),
(3, NULL, 'about-us', 'About Us', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '5312chasma.jpg', '2019-09-09 03:21:31', '2019-09-09 03:21:31', NULL, 'Y'),
(4, NULL, 'about-auditor-general', 'ABOUT AUDITOR GENERAL', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '822931355828_163559564311342_578439220398391296_n.jpg', '2019-09-09 03:23:12', '2019-09-09 03:23:12', NULL, 'Y'),
(5, NULL, 'annual-progress-report', 'Annual Progress Report', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '2168hairstyle2.jpg', '2019-09-09 03:28:04', '2019-09-09 03:28:04', NULL, 'Y'),
(8, NULL, 'the-role-of-human-resource-management-in-business', 'व्यवसायमा मानव संसाधन व्यवस्थापनको भूमिका', '<p>व्यवसायमा मानव संसाधन व्यवस्थापनको भूमिका</p>', '6945autoclavable-roswell.jpg', '2019-09-16 04:13:43', '2019-09-17 11:23:19', NULL, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `status` enum('Y','N') DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `checkvalue`
--

CREATE TABLE `checkvalue` (
  `id` int(11) NOT NULL,
  `attid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `funcareaid` int(11) NOT NULL,
  `chkvalue` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `clientname` varchar(200) NOT NULL,
  `image` varchar(220) DEFAULT NULL,
  `url` varchar(220) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `orderno` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `clientname`, `image`, `url`, `status`, `orderno`) VALUES
(2, 'Digital Agency Catmandu', '6000kisspng-nepal-tourism-board-nepal-marathon.jpg', 'https://www.digitalagencycatmandu.com/', NULL, 1),
(3, 'Nepal Auto', '8965nada-opening-desktop.jpg', 'nepalauto.com', NULL, 20);

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `contents` text,
  `cr_date` varchar(20) DEFAULT NULL,
  `up_date` varchar(20) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `stat` enum('Y','N') DEFAULT 'N',
  `image` varchar(225) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `slug`, `title`, `contents`, `cr_date`, `up_date`, `author`, `stat`, `image`, `meta_title`, `meta_keyword`, `meta_description`) VALUES
(2, 'dot-wedge-datasheet', 'Dot Wedge Datasheet', '<div>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n<div>\r\n<h2>Why do we use it?</h2>\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div>\r\n<h2>Where does it come from?</h2>\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>\r\n</div>', '2019-05-31 11:48:33', '2019-05-31 11:57:33', NULL, 'Y', '9108versa-1.jpg', 'Dot Wedge Datasheet', 'Lorem Ipsum ', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ');

-- --------------------------------------------------------

--
-- Table structure for table `country2code`
--

CREATE TABLE `country2code` (
  `id` int(11) NOT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `country_code2` varchar(5) DEFAULT NULL,
  `country_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country2code`
--

INSERT INTO `country2code` (`id`, `country_code`, `country_code2`, `country_name`) VALUES
(1, 'GB', 'GBR', 'UNITED KINGDOM'),
(2, 'US', 'USA', 'UNITED STATES'),
(3, 'BM', 'BMU', 'BERMUDA'),
(5, 'SE', 'SWE', 'SWEDEN'),
(7, 'IT', 'ITA', 'ITALY'),
(12, 'CA', 'CAN', 'CANADA'),
(17, 'PR', 'PRI', 'PUERTO RICO'),
(46, 'BO', 'BOL', 'BOLIVIA'),
(98, 'NL', 'NLD', 'NETHERLANDS'),
(105, 'DE', 'DEU', 'GERMANY'),
(107, 'CH', 'CHE', 'SWITZERLAND'),
(121, 'FR', 'FRA', 'FRANCE'),
(123, 'IL', 'ISR', 'ISRAEL'),
(127, 'ES', 'ESP', 'SPAIN'),
(236, 'CL', 'CHL', 'CHILE'),
(269, 'BS', 'BHS', 'BAHAMAS'),
(272, 'AR', 'ARG', 'ARGENTINA'),
(284, 'DM', 'DMA', 'DOMINICA'),
(298, 'BE', 'BEL', 'BELGIUM'),
(310, 'IE', 'IRL', 'IRELAND'),
(316, 'BZ', 'BLZ', 'BELIZE'),
(317, 'BR', 'BRA', 'BRAZIL'),
(319, 'MX', 'MEX', 'MEXICO'),
(349, 'JP', 'JPN', 'JAPAN'),
(359, 'IN', 'IND', 'INDIA'),
(361, 'AU', 'AUS', 'AUSTRALIA'),
(362, 'TH', 'THA', 'THAILAND'),
(364, 'CN', 'CHN', 'CHINA'),
(365, 'MY', 'MYS', 'MALAYSIA'),
(366, 'PK', 'PAK', 'PAKISTAN'),
(367, 'NZ', 'NZL', 'NEW ZEALAND'),
(368, 'KR', 'KOR', 'REPUBLIC OF KOREA'),
(371, 'HK', 'HKG', 'HONG KONG'),
(372, 'SG', 'SGP', 'SINGAPORE'),
(376, 'BD', 'BGD', 'BANGLADESH'),
(378, 'ID', 'IDN', 'INDONESIA'),
(383, 'PH', 'PHL', 'PHILIPPINES'),
(395, 'TW', 'TWN', 'TAIWAN'),
(432, 'AF', 'AFG', 'AFGHANISTAN'),
(453, 'VN', 'VNM', 'VIET NAM'),
(515, 'PA', 'PAN', 'PANAMA'),
(546, 'NC', 'NCL', 'NEW CALEDONIA'),
(549, 'BN', 'BRN', 'BRUNEI DARUSSALAM'),
(790, 'GR', 'GRC', 'GREECE'),
(792, 'SA', 'SAU', 'SAUDI ARABIA'),
(799, 'PL', 'POL', 'POLAND'),
(861, 'CZ', 'CZE', 'CZECH REPUBLIC'),
(864, 'RU', 'RUS', 'RUSSIAN FEDERATION'),
(874, 'DK', 'DNK', 'DENMARK'),
(875, 'NG', 'NGA', 'NIGERIA'),
(876, 'ZW', 'ZWE', 'ZIMBABWE'),
(882, 'IQ', 'IRQ', 'IRAQ'),
(886, 'FI', 'FIN', 'FINLAND'),
(888, 'IR', 'IRN', 'ISLAMIC REPUBLIC OF IRAN'),
(897, 'AE', 'ARE', 'UNITED ARAB EMIRATES'),
(903, 'GH', 'GHA', 'GHANA'),
(904, 'GA', 'GAB', 'GABON'),
(907, 'UG', 'UGA', 'UGANDA'),
(910, 'SD', 'SDN', 'SUDAN'),
(912, 'CY', 'CYP', 'CYPRUS'),
(917, 'NO', 'NOR', 'NORWAY'),
(923, 'AT', 'AUT', 'AUSTRIA'),
(925, 'UA', 'UKR', 'UKRAINE'),
(927, 'TJ', 'TJK', 'TAJIKISTAN'),
(2277, 'PT', 'PRT', 'PORTUGAL'),
(2278, 'TR', 'TUR', 'TURKEY'),
(2287, 'GE', 'GEO', 'GEORGIA'),
(2290, 'BY', 'BLR', 'BELARUS'),
(2311, 'AM', 'ARM', 'ARMENIA'),
(2322, 'LB', 'LBN', 'LEBANON'),
(2326, 'MD', 'MDA', 'REPUBLIC OF MOLDOVA'),
(2398, 'BG', 'BGR', 'BULGARIA'),
(2479, 'MZ', 'MOZ', 'MOZAMBIQUE'),
(2502, 'AO', 'AGO', 'ANGOLA'),
(2507, 'KE', 'KEN', 'KENYA'),
(2509, 'CD', 'COD', 'THE DEMOCRATIC REPUBLIC OF THE CONGO'),
(2510, 'MG', 'MDG', 'MADAGASCAR'),
(2512, 'TZ', 'TZA', 'UNITED REPUBLIC OF TANZANIA'),
(2515, 'TG', 'TGO', 'TOGO'),
(2523, 'ZM', 'ZMB', 'ZAMBIA'),
(2530, 'CM', 'CMR', 'CAMEROON'),
(3828, 'OM', 'OMN', 'OMAN'),
(3853, 'LV', 'LVA', 'LATVIA'),
(3856, 'KZ', 'KAZ', 'KAZAKHSTAN'),
(3879, 'EE', 'EST', 'ESTONIA'),
(3882, 'SK', 'SVK', 'SLOVAKIA'),
(3949, 'BA', 'BIH', 'BOSNIA AND HERZEGOVINA'),
(3951, 'HU', 'HUN', 'HUNGARY'),
(3955, 'KW', 'KWT', 'KUWAIT'),
(4192, 'AL', 'ALB', 'ALBANIA'),
(4264, 'LT', 'LTU', 'LITHUANIA'),
(4427, 'SM', 'SMR', 'SAN MARINO'),
(5143, 'RO', 'ROM', 'ROMANIA'),
(5178, 'CS', 'SCG', 'SERBIA AND MONTENEGRO'),
(5683, 'MA', 'MAR', 'MOROCCO'),
(5731, 'LU', 'LUX', 'LUXEMBOURG'),
(5767, 'DZ', 'DZA', 'ALGERIA'),
(5792, 'IS', 'ISL', 'ICELAND'),
(5883, 'CR', 'CRI', 'COSTA RICA'),
(6017, 'MK', 'MKD', 'THE FORMER YUGOSLAV REPUBLIC OF MACEDONIA'),
(6245, 'MT', 'MLT', 'MALTA'),
(6252, 'GM', 'GMB', 'GAMBIA'),
(6286, 'SZ', 'SWZ', 'SWAZILAND'),
(6491, 'ZA', 'ZAF', 'SOUTH AFRICA'),
(7222, 'MW', 'MWI', 'MALAWI'),
(7457, 'FK', 'FLK', 'FALKLAND ISLANDS (MALVINAS)'),
(7514, 'BH', 'BHR', 'BAHRAIN'),
(7537, 'UZ', 'UZB', 'UZBEKISTAN'),
(7552, 'AZ', 'AZE', 'AZERBAIJAN'),
(7563, 'EG', 'EGY', 'EGYPT'),
(7740, 'MC', 'MCO', 'MONACO'),
(7790, 'HT', 'HTI', 'HAITI'),
(7795, 'GU', 'GUM', 'GUAM'),
(7801, 'FM', 'FSM', 'FEDERATED STATES OF MICRONESIA'),
(7809, 'CO', 'COL', 'COLOMBIA'),
(7821, 'LR', 'LBR', 'LIBERIA'),
(7831, 'EC', 'ECU', 'ECUADOR'),
(7872, 'KY', 'CYM', 'CAYMAN ISLANDS'),
(7875, 'PE', 'PER', 'PERU'),
(7919, 'HN', 'HND', 'HONDURAS'),
(7923, 'SL', 'SLE', 'SIERRA LEONE'),
(7991, 'ML', 'MLI', 'MALI'),
(8005, 'LC', 'LCA', 'SAINT LUCIA'),
(8055, 'NI', 'NIC', 'NICARAGUA'),
(8057, 'DO', 'DOM', 'DOMINICAN REPUBLIC'),
(8063, 'AN', 'ANT', 'NETHERLANDS ANTILLES'),
(8073, 'GT', 'GTM', 'GUATEMALA'),
(8206, 'TT', 'TTO', 'TRINIDAD AND TOBAGO'),
(8354, 'BV', 'BVT', 'BOUVET ISLAND'),
(8377, 'VE', 'VEN', 'VENEZUELA'),
(8416, 'WS', 'WSM', 'SAMOA'),
(8421, 'MH', 'MHL', 'MARSHALL ISLANDS'),
(8504, 'PW', 'PLW', 'PALAU'),
(8558, 'BB', 'BRB', 'BARBADOS'),
(8618, 'MP', 'MNP', 'NORTHERN MARIANA ISLANDS'),
(8792, 'GD', 'GRD', 'GRENADA'),
(8793, 'VC', 'VCT', 'SAINT VINCENT AND THE GRENADINES'),
(8968, 'SV', 'SLV', 'EL SALVADOR'),
(8973, 'JM', 'JAM', 'JAMAICA'),
(8997, 'CU', 'CUB', 'CUBA'),
(9017, 'TC', 'TCA', 'TURKS AND CAICOS ISLANDS'),
(9061, 'CG', 'COG', 'CONGO'),
(9318, 'PY', 'PRY', 'PARAGUAY'),
(9326, 'RW', 'RWA', 'RWANDA'),
(9336, 'SR', 'SUR', 'SURINAME'),
(9339, 'GY', 'GUY', 'GUYANA'),
(9577, 'PG', 'PNG', 'PAPUA NEW GUINEA'),
(9647, 'KN', 'KNA', 'SAINT KITTS AND NEVIS'),
(9675, 'AG', 'ATG', 'ANTIGUA AND BARBUDA'),
(9689, 'GI', 'GIB', 'GIBRALTAR'),
(9775, 'AW', 'ABW', 'ARUBA'),
(9820, 'UY', 'URY', 'URUGUAY'),
(9893, 'JO', 'JOR', 'JORDAN'),
(10238, 'SY', 'SYR', 'SYRIAN ARAB REPUBLIC'),
(10364, 'UM', 'UMI', 'UNITED STATES MINOR OUTLYING ISLANDS'),
(11042, 'SI', 'SVN', 'SLOVENIA'),
(11133, 'MU', 'MUS', 'MAURITIUS'),
(11176, 'NE', 'NER', 'NIGER'),
(11476, 'KG', 'KGZ', 'KYRGYZSTAN'),
(11477, 'TM', 'TKM', 'TURKMENISTAN'),
(11524, 'HR', 'HRV', 'CROATIA'),
(12106, 'GN', 'GIN', 'GUINEA'),
(12108, 'MM', 'MMR', 'MYANMAR'),
(12118, 'BJ', 'BEN', 'BENIN'),
(12120, 'CF', 'CAF', 'CENTRAL AFRICAN REPUBLIC'),
(12122, 'ET', 'ETH', 'ETHIOPIA'),
(12123, 'NP', 'NPL', 'NEPAL'),
(12126, 'BT', 'BTN', 'BHUTAN'),
(12155, 'QA', 'QAT', 'QATAR'),
(12176, 'NA', 'NAM', 'NAMIBIA'),
(12409, 'BW', 'BWA', 'BOTSWANA'),
(12434, 'TD', 'TCD', 'CHAD'),
(12992, 'RE', 'REU', 'REUNION'),
(13016, 'SO', 'SOM', 'SOMALIA'),
(13034, 'BI', 'BDI', 'BURUNDI'),
(13044, 'FO', 'FRO', 'FAROE ISLANDS'),
(13111, 'LS', 'LSO', 'LESOTHO'),
(13115, 'MR', 'MRT', 'MAURITANIA'),
(13124, 'NR', 'NRU', 'NAURU'),
(13862, 'LY', 'LBY', 'LIBYAN ARAB JAMAHIRIYA'),
(13937, 'KM', 'COM', 'COMOROS'),
(14077, 'LI', 'LIE', 'LIECHTENSTEIN'),
(14349, 'SC', 'SYC', 'SEYCHELLES'),
(14537, 'LA', 'LAO', 'LAO PEOPLES DEMOCRATIC REPUBLIC'),
(14539, 'LK', 'LKA', 'SRI LANKA'),
(15134, 'TN', 'TUN', 'TUNISIA'),
(15377, 'MQ', 'MTQ', 'MARTINIQUE'),
(15386, 'GP', 'GLP', 'GUADELOUPE'),
(15881, 'VA', 'VAT', 'HOLY SEE (VATICAN CITY STATE)'),
(16119, 'YE', 'YEM', 'YEMEN'),
(17815, 'YT', 'MYT', 'MAYOTTE'),
(17955, 'BF', 'BFA', 'BURKINA FASO'),
(19155, 'AQ', 'ATA', 'ANTARCTICA'),
(19367, 'KH', 'KHM', 'CAMBODIA'),
(19382, 'MV', 'MDV', 'MALDIVES'),
(19572, 'MO', 'MAC', 'MACAO'),
(19665, 'WF', 'WLF', 'WALLIS AND FUTUNA'),
(19927, 'MN', 'MNG', 'MONGOLIA'),
(20046, 'FJ', 'FJI', 'FIJI'),
(20343, 'VU', 'VUT', 'VANUATU'),
(20502, 'PF', 'PYF', 'FRENCH POLYNESIA'),
(37111, 'GQ', 'GNQ', 'EQUATORIAL GUINEA'),
(37537, 'DJ', 'DJI', 'DJIBOUTI'),
(39188, 'GW', 'GNB', 'GUINEA-BISSAU'),
(39980, 'SN', 'SEN', 'SENEGAL'),
(41750, 'PS', 'PSE', 'PALESTINIAN TERRITORY, OCCUPIED'),
(41824, 'AD', 'AND', 'ANDORRA'),
(44897, 'GL', 'GRL', 'GREENLAND'),
(46296, 'CV', 'CPV', 'CAPE VERDE'),
(46297, 'ST', 'STP', 'SAO TOME AND PRINCIPE'),
(57574, 'MS', 'MSR', 'MONTSERRAT'),
(58292, 'TF', 'ATF', 'FRENCH SOUTHERN TERRITORIES'),
(58517, 'GF', 'GUF', 'FRENCH GUIANA'),
(59439, 'GS', 'SGS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS'),
(59511, 'SB', 'SLB', 'SOLOMON ISLANDS'),
(59525, 'TV', 'TUV', 'TUVALU'),
(59615, 'KI', 'KIR', 'KIRIBATI'),
(59968, 'TO', 'TON', 'TONGA'),
(59991, 'IO', 'IOT', 'BRITISH INDIAN OCEAN TERRITORY'),
(60199, 'CK', 'COK', 'COOK ISLANDS'),
(60249, 'AS', 'ASM', 'AMERICAN SAMOA'),
(60276, 'TL', 'TLS', 'TIMOR-LESTE'),
(60278, 'TK', 'TKL', 'TOKELAU'),
(61485, 'NF', 'NFK', 'NORFOLK ISLAND'),
(62134, 'VG', 'VGB', 'VIRGIN ISLANDS, BRITISH'),
(62156, 'VI', 'VIR', 'VIRGIN ISLANDS, U.S.'),
(62261, 'AI', 'AIA', 'ANGUILLA'),
(72662, 'ER', 'ERI', 'ERITREA'),
(73648, 'CI', 'CIV', 'COTE D IVOIRE');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown`
--

CREATE TABLE `dropdown` (
  `id` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `dropvalue` varchar(50) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dropdown`
--

INSERT INTO `dropdown` (`id`, `fid`, `dropvalue`, `ordering`, `slug`, `image`) VALUES
(4, 6, 'Manufacturing', 0, '', ''),
(15, 2, 'Charikot', 0, '', ''),
(16, 10, 'Banking, Finance & Insurance Services', 0, '', ''),
(17, 10, 'Automobiles Sales & Services', 0, '', ''),
(18, 10, 'Architect & Interior Design', 0, '', ''),
(19, 10, 'Accounting / Finance', 0, '', ''),
(68, 12, 'Full Time', 0, '', ''),
(69, 12, 'Correspondence', 0, '', ''),
(70, 12, 'Distance Learning', 0, '', ''),
(71, 4, 'NRs. 5000-10000', 0, '', ''),
(72, 2, 'Birendranagar', 0, '', ''),
(73, 4, 'NRs. 10000-15000', 0, '', ''),
(74, 4, 'NRs. 15000-20000', 0, '', ''),
(75, 4, 'NRs. 20000-25000', 0, '', ''),
(76, 4, 'NRs. 25000-30000', 0, '', ''),
(77, 4, 'NRs. 40000-45000', 0, '', ''),
(78, 2, 'Biratnagar', 0, '', ''),
(79, 2, 'Damak', 0, '', ''),
(80, 2, 'Butwal', 0, '', ''),
(81, 2, 'Itahari', 0, '', ''),
(82, 2, 'Chandragadhi', 0, '', ''),
(83, 2, 'Birtamode', 0, '', ''),
(84, 4, 'NRs. 45000-50000', 0, '', ''),
(103, 2, 'Bhojpur', 0, '', ''),
(104, 2, 'Bharatpur', 0, '', ''),
(106, 4, 'NRs. 50000-60000', 0, '', ''),
(107, 4, 'NRs. 60000-70000', 0, '', ''),
(108, 10, 'BPO/Call Center', 0, '', ''),
(109, 10, 'Content, Journalism', 0, '', ''),
(110, 10, 'Construction, Engineering Consultants', 0, '', ''),
(111, 10, 'Engineering, Design, R & D', 0, '', ''),
(112, 10, 'Export/Import/Trading', 0, '', ''),
(113, 10, 'Fashion, Garment', 0, '', ''),
(114, 10, 'Front Office, Fresher, Trainee Jobs', 0, '', ''),
(115, 10, 'Healthcare, Medical, R & D', 0, '', ''),
(116, 10, 'Hotels, Restaurants', 0, '', ''),
(117, 10, 'HR & Admin', 0, '', ''),
(118, 10, 'Industrial Sectors', 0, '', ''),
(119, 10, 'IT-Hardware & Software Services', 0, '', ''),
(120, 10, 'Legal Consulting', 0, '', ''),
(121, 10, 'Marketing, Advertising & Sales', 0, '', ''),
(122, 10, 'Event Management/Entertainment', 0, '', ''),
(123, 10, 'NGO/INGO/Government/Social Work', 0, '', ''),
(124, 10, 'Overseas/Manpower/International', 0, '', ''),
(125, 10, 'Pharma, Biotech', 0, '', ''),
(126, 10, 'Purchase, Supply Chain', 0, '', ''),
(127, 10, 'Secretary', 0, '', ''),
(128, 10, 'Site Engineering', 0, '', ''),
(129, 10, 'Teaching, Education', 0, '', ''),
(130, 10, 'Telecom & Satellite', 0, '', ''),
(131, 10, 'Travel, Airlines, GSA', 0, '', ''),
(132, 10, 'TV/Films/Media', 0, '', ''),
(133, 10, 'Walk In Interviews', 0, '', ''),
(134, 10, 'Web, Graphic Design', 0, '', ''),
(135, 10, 'Others', 0, '', ''),
(159, 2, 'Bhaktapur', 0, '', ''),
(166, 2, 'Bhadrapur', 0, '', ''),
(167, 2, 'Beni', 0, '', ''),
(168, 2, 'Dharan', 0, '', ''),
(169, 2, 'Bardibas', 0, '', ''),
(170, 2, 'Bardiya', 0, '', ''),
(171, 2, 'Bara', 0, '', ''),
(324, 9, 'Agro-based Industry ', 0, 'agro-based-industry', '4994autoclavable-roswell.jpg'),
(174, 10, 'Sales', 0, '', ''),
(323, 9, 'Construction ', 0, 'construction', '7986architecture-beautiful.jpg'),
(322, 9, 'Hospitality Sector', 0, 'hospitality-sector', ''),
(177, 2, 'Banke', 0, '', ''),
(178, 2, 'Banepa', 0, '', ''),
(179, 2, 'Janakpur', 0, '', ''),
(180, 2, 'Birgunj', 0, '', ''),
(181, 2, 'Bandipur', 0, '', ''),
(182, 2, 'Bajhang', 0, '', ''),
(321, 9, 'Training & Consulting', 0, 'training-consulting', ''),
(185, 2, 'Baitadi', 0, '', ''),
(186, 2, 'Baglung', 0, '', ''),
(187, 2, 'Hetauda', 0, '', ''),
(188, 2, 'Arghakhanchi', 0, '', ''),
(189, 2, 'Narayangarh', 0, '', ''),
(190, 4, 'NRs. 70000-80000', 0, '', ''),
(191, 4, 'NRs. 80000-90000', 0, '', ''),
(192, 4, 'NRs. 90000-100000', 0, '', ''),
(193, 4, 'NRs. 100000+', 0, '', ''),
(194, 2, 'Various Places', 0, '', ''),
(320, 9, 'Education Sector', 0, 'education-sector', ''),
(198, 4, 'Negotiable', 0, '', ''),
(199, 2, 'Accham', 0, '', ''),
(202, 2, 'Pokhara', 0, '', ''),
(203, 2, 'Butwal', 0, '', ''),
(204, 2, 'Bhairahawa', 0, '', ''),
(205, 2, 'Ghorahi', 0, '', ''),
(206, 2, 'Tulsipur', 0, '', ''),
(207, 2, 'Nepalgunj', 0, '', ''),
(208, 2, 'Tikapur', 0, '', ''),
(209, 2, 'Dhangadhi', 0, '', ''),
(210, 2, 'Mahendranagar', 0, '', ''),
(211, 2, 'Kathmandu', 0, '', ''),
(212, 12, 'e-Learning', 0, '', ''),
(218, 2, 'Chitwan', 0, '', ''),
(219, 2, 'Dadeldhura', 0, '', ''),
(220, 2, 'Dailekh', 0, '', ''),
(221, 2, 'Damauli', 0, '', ''),
(222, 2, 'Dang', 0, '', ''),
(223, 2, 'Darchula', 0, '', ''),
(224, 2, 'Dhading', 0, '', ''),
(225, 2, 'Dhankuta', 0, '', ''),
(226, 2, 'Gaur', 0, '', ''),
(227, 2, 'Gorkha', 0, '', ''),
(228, 2, 'Jhapa', 0, '', ''),
(229, 2, 'Kaski', 0, '', ''),
(230, 2, 'Kavrepalanchok', 0, '', ''),
(231, 2, 'Laltipur', 0, '', ''),
(232, 2, 'Mahottari', 0, '', ''),
(233, 2, 'Sindhupalchowk', 0, '', ''),
(234, 2, 'Taplejung', 0, '', ''),
(235, 2, 'Therathum', 0, '', ''),
(236, 2, 'Ilam', 0, '', ''),
(237, 2, 'Jaleshwar', 0, '', ''),
(238, 2, 'Kailali', 0, '', ''),
(239, 2, 'Kakarvita', 0, '', ''),
(240, 2, 'Kalaiya', 0, '', ''),
(241, 2, 'Makawanpur', 0, '', ''),
(242, 2, 'Morang', 0, '', ''),
(243, 2, 'Nawalparasi', 0, '', ''),
(244, 2, 'Parbat', 0, '', ''),
(245, 2, 'Nuwakot', 0, '', ''),
(246, 2, 'Palpa', 0, '', ''),
(247, 2, 'Pyuthan', 0, '', ''),
(248, 2, 'Ramechhap', 0, '', ''),
(249, 2, 'Udaypur', 0, '', ''),
(250, 2, 'Trishuli', 0, '', ''),
(251, 2, 'Tanahu', 0, '', ''),
(252, 2, 'Syanja', 0, '', ''),
(253, 2, 'Surkhet', 0, '', ''),
(254, 2, 'Sunsari', 0, '', ''),
(255, 2, 'Siraha', 0, '', ''),
(256, 2, 'Sindhuli', 0, '', ''),
(257, 2, 'Simara', 0, '', ''),
(258, 2, 'Sarlahi', 0, '', ''),
(259, 2, 'Saptari', 0, '', ''),
(260, 2, 'Salyan', 0, '', ''),
(261, 2, 'Rupandehi', 0, '', ''),
(262, 2, 'Jajarkot', 0, '', ''),
(318, 9, 'FMCG Sector', 0, 'fmcg-sector', ''),
(264, 10, 'Hydropower ', 0, '', ''),
(265, 10, 'Housing/Real Estate', 0, '', ''),
(266, 10, 'Distribution/Retail/Wholesale', 0, '', ''),
(267, 2, 'Kathmandu', 0, '', ''),
(281, 10, 'FMCG/Manufacturing', 0, '', ''),
(282, 10, 'Security Providers', 0, '', ''),
(287, 10, 'Embassies', 0, '', ''),
(288, 10, 'Handicraft Manufacturing', 0, '', ''),
(317, 9, 'Banks & Financial Institutions', 0, 'banks-financial-institutions', ''),
(316, 9, 'Manufacturing', 0, 'manufacturing', ''),
(299, 2, 'kathmandu', 0, '', ''),
(300, 4, 'Don\'t disclose', 0, '', ''),
(301, 12, 'Part Time', 0, '', ''),
(302, 10, 'Manufacturing', 0, '', ''),
(303, 10, 'Service', 0, '', ''),
(329, 16, 'Contract', 0, '', ''),
(328, 16, 'Part Time', 0, '', ''),
(327, 16, 'Full Time', 0, '', ''),
(326, 16, 'Internship', 0, '', ''),
(325, 16, 'Freelance', 0, '', ''),
(312, 17, 'Entry Level', 1, '', ''),
(313, 17, 'Mid Level', 2, '', ''),
(314, 17, 'Senior Level', 3, '', ''),
(315, 17, 'Top Level', 4, '', ''),
(330, 7, '0-10', 0, '0-10', ''),
(331, 7, '10-20', 0, '10-20', ''),
(334, 15, 'TEsting', NULL, 'testing', '3911autoclavable_pico_plus.jpg'),
(336, 16, 'Permanent', NULL, 'permanent', NULL),
(337, 16, 'TEsting', NULL, 'testing', NULL),
(338, 16, 'Testing for select', NULL, 'testing-for-select', NULL),
(339, 8, 'Nepal', NULL, 'nepal', NULL),
(340, 3, 'CA', NULL, 'ca', NULL),
(341, 3, 'MBA', NULL, 'mba', NULL),
(342, 3, 'Semi Qualified CA', NULL, 'semi-qualified-ca', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `orgname` varchar(200) NOT NULL,
  `organization_code` varchar(255) NOT NULL,
  `organization_name` varchar(200) DEFAULT NULL,
  `organization_type` int(50) DEFAULT NULL,
  `organization_address` varchar(100) DEFAULT NULL,
  `organization_size` varchar(100) NOT NULL,
  `organization_description` text NOT NULL,
  `organization_phone` varchar(50) DEFAULT NULL,
  `organization_fax` varchar(25) DEFAULT NULL,
  `organization_pobox` varchar(25) DEFAULT NULL,
  `organization_website` varchar(50) DEFAULT NULL,
  `organization_logo` varchar(50) DEFAULT NULL,
  `organization_banner` varchar(100) DEFAULT NULL,
  `organization_facebook` varchar(200) NOT NULL,
  `organization_linkedin` varchar(200) NOT NULL,
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_designation` varchar(50) DEFAULT NULL,
  `contact_email` varchar(50) DEFAULT NULL,
  `contact_mobile` varchar(50) DEFAULT NULL,
  `alternate_contact_name` varchar(50) DEFAULT NULL,
  `alternate_contact_designatioin` varchar(50) DEFAULT NULL,
  `alternate_contact_email` varchar(50) DEFAULT NULL,
  `alternate_contact_mobile` varchar(20) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime NOT NULL,
  `last_accessed` datetime NOT NULL,
  `isActivated` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `activation_code` varchar(50) NOT NULL,
  `token` varchar(150) DEFAULT NULL,
  `joindate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`id`, `username`, `email`, `password`, `orgname`, `organization_code`, `organization_name`, `organization_type`, `organization_address`, `organization_size`, `organization_description`, `organization_phone`, `organization_fax`, `organization_pobox`, `organization_website`, `organization_logo`, `organization_banner`, `organization_facebook`, `organization_linkedin`, `contact_name`, `contact_designation`, `contact_email`, `contact_mobile`, `alternate_contact_name`, `alternate_contact_designatioin`, `alternate_contact_email`, `alternate_contact_mobile`, `date_created`, `date_modified`, `last_accessed`, `isActivated`, `activation_code`, `token`, `joindate`) VALUES
(2, 'dac@info.com', 'dac@info.com', '6ebe76c9fb411be97b3b0d48b791a7c9', 'Digital Agency Catmandu', 'digital-agency-catmandu-2', 'Digital Agency Catmandu', 0, 'Baluwatar, Kathmandu, Nepal', '331', '<p>TEsting for information</p>', '987654321', NULL, '', 'digitalagencycatmandu.com', '9063company_logo.png', '86652.png', 'https://www.facebook.com/', 'https://www.linkedin.com/', 'Sanjeev Singh', 'MD', 'sansanjeev@gmail.com', '9851237969', 'Ayaz Udin', 'Senior Developer', 'ayaz.din@gmail.com', '41526', '2019-03-14 10:30:32', '0000-00-00 00:00:00', '2019-09-18 15:15:36', 'Yes', '', '', '2019-03-14'),
(3, 'admin@amin.com', 'admin@amin.com', '6ebe76c9fb411be97b3b0d48b791a7c9', 'my company', 'my-company-3', 'my company', 0, '1307 commonwealth ave', '', '<p>asdfghjkl</p>', '987654321', NULL, '', 'my company', NULL, NULL, '', '', 'Binaya', 'MD', 'shresthasanjay1@gmail.com', '', 'sanjay shrestha', '', '', '', '2019-03-22 10:26:00', '0000-00-00 00:00:00', '2019-03-22 16:12:28', 'Yes', '', NULL, '2019-03-22'),
(9, 'test@test.com', 'test@test.com', '25f9e794323b453885f5181f1b624d0b', 'Testing for org name', 'testing-for-org-name-9', 'Testing for org name', 324, 'Bailachhen, Patan, Nepalte', '', '<p>teaefdasfasdfasfasdfasdfa</p>', '987654321', NULL, '', '', NULL, NULL, '', '', 'Binaya', 'MD', '', '', '', '', '', '', '2019-09-11 10:38:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Yes', '', NULL, '2019-09-11'),
(7, 'shresthasanjay1@gmail.com', 'shresthasanjay1@gmail.com', '25f9e794323b453885f5181f1b624d0b', 'sanjay shrestha pvt. co', 'testing-for-org-name-8', 'sanjay shrestha pvt. co', 0, '1307 commonwealth ave', '', '<p>testasasdfasdfadfadfa</p>', '987654321', NULL, '', '', NULL, NULL, '', '', 'Binaya', 'MD', 'shresthasanjay1@gmail.com', '', 'sanjay shrestha', '', '', '', '2019-06-13 11:11:30', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Yes', '', NULL, '2019-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fields`
--

INSERT INTO `fields` (`id`, `title`) VALUES
(2, 'Job Location'),
(3, 'Education'),
(4, 'Salary Range'),
(5, 'Ownership'),
(6, 'Organization Type'),
(7, 'Organization Size'),
(8, 'Nationality'),
(9, 'Job Category'),
(11, 'Education Level'),
(15, 'Job Region'),
(16, 'Job Type'),
(17, 'Job Level');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `eid` int(11) DEFAULT NULL,
  `displayname` varchar(150) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `jobtitle` varchar(150) DEFAULT NULL,
  `jobcategory` int(11) DEFAULT NULL,
  `preferredgender` enum('Male','Female','Male/Female','Both','Others') NOT NULL DEFAULT 'Male',
  `requiredno` varchar(150) DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pmm` int(11) DEFAULT NULL,
  `pdd` int(11) DEFAULT NULL,
  `pyy` int(11) DEFAULT NULL,
  `post_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedate` date NOT NULL,
  `apmm` int(11) DEFAULT NULL,
  `apdd` int(11) DEFAULT NULL,
  `apyy` int(11) DEFAULT NULL,
  `applybefore` date NOT NULL,
  `salaryrange` varchar(25) DEFAULT NULL,
  `exprequire` varchar(10) NOT NULL,
  `noexperience` varchar(100) DEFAULT NULL,
  `education` int(11) DEFAULT NULL,
  `joblevel` varchar(250) DEFAULT NULL,
  `jobtype` varchar(250) DEFAULT NULL,
  `jobtype2` varchar(250) DEFAULT NULL,
  `jobtype3` varchar(250) DEFAULT NULL,
  `jobtype4` varchar(250) NOT NULL,
  `otherstype` varchar(50) NOT NULL,
  `joblocation` varchar(250) DEFAULT NULL,
  `brief` text,
  `background` text,
  `specification` text,
  `requirements` text,
  `howtoapply` text,
  `acceptonline` enum('Yes','No') DEFAULT 'No',
  `onlineap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `emailap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `postap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `video_cv` varchar(10) NOT NULL,
  `isNewspaperJob` text,
  `job_display_in` varchar(50) DEFAULT '',
  `isWalkin` enum('0','1') NOT NULL DEFAULT '0',
  `pobox` text,
  `adminPosted` enum('1','0') NOT NULL DEFAULT '0',
  `complogo` varchar(150) NOT NULL,
  `banner_image` varchar(200) DEFAULT NULL,
  `post_status` varchar(100) NOT NULL,
  `apply_by_faculty` varchar(100) DEFAULT NULL,
  `apply_by_age` varchar(100) NOT NULL,
  `from_age` int(11) NOT NULL,
  `to_age` int(11) NOT NULL,
  `postedin` varchar(100) NOT NULL,
  `orgemail` varchar(100) NOT NULL,
  `no_of_views` varchar(100) DEFAULT NULL,
  `required_education` varchar(200) NOT NULL,
  `expected_faculty` text NOT NULL,
  `other_faculty` varchar(200) NOT NULL,
  `slc_docs` int(11) DEFAULT NULL,
  `docs_11_12` int(11) DEFAULT NULL,
  `bachelor_docs` int(11) DEFAULT NULL,
  `masters_docs` int(11) DEFAULT NULL,
  `isEmailed` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `eid`, `displayname`, `slug`, `jobtitle`, `jobcategory`, `preferredgender`, `requiredno`, `date_added`, `pmm`, `pdd`, `pyy`, `post_date`, `updatedate`, `apmm`, `apdd`, `apyy`, `applybefore`, `salaryrange`, `exprequire`, `noexperience`, `education`, `joblevel`, `jobtype`, `jobtype2`, `jobtype3`, `jobtype4`, `otherstype`, `joblocation`, `brief`, `background`, `specification`, `requirements`, `howtoapply`, `acceptonline`, `onlineap`, `emailap`, `postap`, `video_cv`, `isNewspaperJob`, `job_display_in`, `isWalkin`, `pobox`, `adminPosted`, `complogo`, `banner_image`, `post_status`, `apply_by_faculty`, `apply_by_age`, `from_age`, `to_age`, `postedin`, `orgemail`, `no_of_views`, `required_education`, `expected_faculty`, `other_faculty`, `slc_docs`, `docs_11_12`, `bachelor_docs`, `masters_docs`, `isEmailed`) VALUES
(3, 2, '', 'financial-analyst-corporate-ad', 'Financial Analyst-Corporate Advisory', 324, 'Others', '5', '2019-09-18 09:53:13', 3, 23, 2019, '2019-03-22 18:15:00', '2019-03-21', 5, 20, 2019, '2019-09-20', '198', 'No', 'Not Required', NULL, '313', 'a:1:{i:0;s:3:\"329\";}', '', '', '', '', 'a:4:{i:0;s:3:\"199\";i:1;s:3:\"188\";i:2;s:3:\"186\";i:3;s:3:\"185\";}', NULL, NULL, '<p>testing</p>', '<p>testing</p>', '', 'No', 'No', 'No', 'No', 'No', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', '', '', '', NULL, 'public', NULL, '0-0', 0, 0, '2019-08-29', '', '71', 'CA', '', '', 1, 1, NULL, NULL, '1'),
(4, 2, '', 'job-title', 'Job Title', 317, 'Male', '1', '2019-09-18 09:27:53', 3, 21, 2019, '2019-03-20 18:15:00', '2019-06-12', 7, 31, 2019, '2019-09-30', '198', 'No', 'Not Required', NULL, '313', 'a:2:{i:0;s:3:\"325\";i:1;s:3:\"326\";}', '', '', '', '', 'a:2:{i:0;s:3:\"167\";i:1;s:3:\"166\";}', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', 'No', 'a:1:{i:0;s:4:\"RJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '-', 0, 0, '', '', '61', 'Not Required', '', '', NULL, NULL, NULL, NULL, '1'),
(5, 2, 'DAC', 'admin-job-add', 'Admin Job Add', 324, 'Male/Female', '5', '2019-09-18 09:26:58', 5, 8, 2019, '2019-05-07 18:15:00', '2019-06-12', 6, 30, 2019, '2019-12-31', '300', '', '3', NULL, '312', 'a:1:{i:0;s:3:\"325\";}', '', '', '', '', 'a:3:{i:0;s:3:\"199\";i:1;s:3:\"186\";i:2;s:3:\"182\";}', NULL, NULL, '<p><img src=\"http://localhost/financejobnepal/tinymce/file_manager/source/NADA-Opening-desktop.jpg?1568264472401\" alt=\"\" width=\"1050\" height=\"600\" /></p>', '', NULL, 'No', 'No', 'No', 'No', 'No', 'a:3:{i:0;s:4:\"RJob\";i:1;s:6:\"FJNJob\";i:2;s:4:\"NJob\";}', '', '0', NULL, '', '8256versa-1.png', NULL, 'public', NULL, '-', 0, 0, '', '', '127', 'bachelor', '', '', NULL, NULL, NULL, NULL, '1'),
(6, 2, NULL, 'testing-for-multiple-array', 'TEsting for multiple array', 324, 'Male/Female', '10', '2019-09-18 09:26:52', 6, 13, 2019, '2019-06-12 18:15:00', '0000-00-00', 7, 13, 2019, '2019-12-31', '74', 'Yes', 'Not Required', NULL, '313', 'a:3:{i:0;s:3:\"325\";i:1;s:3:\"326\";i:2;s:3:\"327\";}', NULL, NULL, '', '', 'a:2:{i:0;s:3:\"199\";i:1;s:3:\"188\";}', NULL, NULL, '<p>tessttest</p>', '<p>test</p>', NULL, 'No', 'No', 'No', 'No', '', 'a:3:{i:0;s:4:\"RJob\";i:1;s:6:\"FJNJob\";i:2;s:4:\"NJob\";}', '', '0', NULL, '', '', NULL, 'public', NULL, '', 0, 0, '2019-06-13', '', '41', 'intermediate', 'Management', '', NULL, NULL, NULL, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `seeker`
--

CREATE TABLE `seeker` (
  `id` int(11) NOT NULL,
  `email` varchar(35) DEFAULT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `summary` text,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `address_permanent` varchar(255) DEFAULT NULL,
  `address_current` varchar(255) DEFAULT NULL,
  `phone_cell` varchar(25) DEFAULT NULL,
  `phone_resisdance` varchar(25) DEFAULT NULL,
  `gender` enum('Male','Female','Other','Male/Female') NOT NULL,
  `dob` date NOT NULL,
  `marital_status` enum('Married','Single') DEFAULT 'Single',
  `nationality` int(11) DEFAULT NULL,
  `highest_qualification` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `have_work_experience` enum('Yes','No') DEFAULT 'No',
  `experience_years` int(11) DEFAULT NULL,
  `experience_months` int(11) DEFAULT NULL,
  `cjobposiiton` varchar(100) NOT NULL,
  `keyskills` text NOT NULL,
  `profile_summary` text NOT NULL,
  `desired_industry` varchar(255) DEFAULT NULL,
  `desired_functional_area` varchar(255) DEFAULT NULL,
  `desired_role` varchar(100) DEFAULT NULL,
  `desired_job_type` varchar(50) DEFAULT NULL,
  `desired_employment_type` varchar(100) DEFAULT NULL,
  `desired_shift` varchar(100) NOT NULL,
  `desired_expected_salary` int(11) NOT NULL,
  `desired_job_location` varchar(100) NOT NULL,
  `past_employer` varchar(100) NOT NULL,
  `current_employer` varchar(100) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `facebook` varchar(150) NOT NULL,
  `linkedin` varchar(150) NOT NULL,
  `resume` varchar(150) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime NOT NULL,
  `last_accessed` datetime NOT NULL,
  `isActivated` enum('1','0') NOT NULL DEFAULT '0',
  `activation_code` varchar(50) NOT NULL,
  `lastaccess` datetime NOT NULL,
  `token` varchar(150) NOT NULL,
  `oauth_provider` varchar(100) NOT NULL,
  `oauth_uid` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `locale` varchar(10) NOT NULL,
  `user_type` enum('registered','cv_only') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker`
--

INSERT INTO `seeker` (`id`, `email`, `username`, `password`, `summary`, `fname`, `mname`, `lname`, `address_permanent`, `address_current`, `phone_cell`, `phone_resisdance`, `gender`, `dob`, `marital_status`, `nationality`, `highest_qualification`, `faculty`, `have_work_experience`, `experience_years`, `experience_months`, `cjobposiiton`, `keyskills`, `profile_summary`, `desired_industry`, `desired_functional_area`, `desired_role`, `desired_job_type`, `desired_employment_type`, `desired_shift`, `desired_expected_salary`, `desired_job_location`, `past_employer`, `current_employer`, `profile_picture`, `facebook`, `linkedin`, `resume`, `date_created`, `date_modified`, `last_accessed`, `isActivated`, `activation_code`, `lastaccess`, `token`, `oauth_provider`, `oauth_uid`, `link`, `locale`, `user_type`) VALUES
(2, 'binaya619@gmail.com', 'binaya619@gmail.com', '6ebe76c9fb411be97b3b0d48b791a7c9', NULL, 'Binaya', '', 'shrestha', NULL, 'Bailahhen, Lalitpur, nepal', '9849748017', NULL, 'Male', '1989-05-25', 'Single', NULL, 'Masters', '', 'No', 2, NULL, 'developer', '', '', NULL, NULL, NULL, NULL, NULL, '', 77, '', 'Longtail', 'Dac', '7566company_logo.png', 'facebook.com', 'linkedin.com', '8145xerafy-dot-wedge-datasheet_cn.pdf', '2019-03-26 18:15:00', '2019-05-13 00:00:00', '0000-00-00 00:00:00', '1', '1535209236', '2019-08-29 11:41:13', '', '', '', '', '', 'registered'),
(6, 'binaya_619@hotmail.com', '', NULL, NULL, 'Bnay', 'Prasad', 'Shrestha', NULL, 'Bailahhen, Lalitpur, nepal', '9849748017', NULL, '', '0000-00-00', 'Single', NULL, 'bachelor', '', 'No', 4, NULL, 'developer', '', '', NULL, NULL, NULL, NULL, NULL, '', 77, '', 'Longtail', 'Dac', '', 'https://www.facebook.com/binaya619', '', '', '2019-04-09 05:21:02', '2019-07-26 13:12:21', '0000-00-00 00:00:00', '1', '', '0000-00-00 00:00:00', '', 'facebook', '10157447453035139', '', '', 'registered'),
(8, 'binaya_916@hotmail.com', 'binaya_916@hotmail.com', '6ebe76c9fb411be97b3b0d48b791a7c9', NULL, 'binaya', NULL, 'shrestha', NULL, NULL, NULL, NULL, 'Male', '0000-00-00', 'Single', NULL, '', '', 'No', NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, '', 0, '', '', '', '', '', '', '6756general_changes.docx', '2019-09-11 09:33:27', '2019-09-11 15:18:27', '0000-00-00 00:00:00', '1', '', '2019-09-11 15:26:08', '', '', '', '', '', 'cv_only'),
(7, 'basantalfc@gmail.com', 'basantalfc@gmail.com', '027c362bcec33f41a19f1b6f8e46f37d', NULL, 'basanta', NULL, 'pandey', NULL, NULL, NULL, NULL, 'Male', '0000-00-00', 'Single', NULL, '', '', 'No', NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, '', 0, '', '', '', '', '', '', '4468eol-notification-2.docx', '2019-05-10 06:39:31', '2019-05-10 12:56:54', '0000-00-00 00:00:00', '0', '', '0000-00-00 00:00:00', '', '', '', '', '', 'cv_only');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_education`
--

CREATE TABLE `seeker_education` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `education_program` varchar(50) DEFAULT NULL,
  `graduationyear` int(11) DEFAULT NULL,
  `instution` varchar(150) DEFAULT NULL,
  `board` varchar(150) DEFAULT NULL,
  `marks_secured_in` enum('Percentage','CGPA') DEFAULT NULL,
  `marks_secured` varchar(50) DEFAULT NULL,
  `graduation_month` varchar(20) DEFAULT NULL,
  `current_studying` enum('1','0') DEFAULT NULL,
  `started_year` varchar(100) DEFAULT NULL,
  `started_month` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_education`
--

INSERT INTO `seeker_education` (`id`, `sid`, `degree`, `education_program`, `graduationyear`, `instution`, `board`, `marks_secured_in`, `marks_secured`, `graduation_month`, `current_studying`, `started_year`, `started_month`) VALUES
(48, 2, '', 'BE Computer', 2016, '', '', 'Percentage', '60', '', '1', '', ''),
(47, 2, '', '+2', 2016, 'AVM', 'HSEB', 'Percentage', '60', '', '', NULL, NULL),
(41, 6, '24', '+2', 2007, 'AVM', 'HSEB', 'Percentage', '72', 'January', '', NULL, NULL),
(42, 6, '30', 'BE', 2012, 'CITE', 'Purbanchal University', 'Percentage', '80', 'January', '', NULL, NULL),
(43, 6, '45', 'ME', 2012, 'kathmandu university', 'Kathmandu University', 'Percentage', '80', 'January', '1', '2018', 'February'),
(49, 2, '', 'BE Computer', 2019, 'CITE', 'Tribhuvan University', 'CGPA', '3.2', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_experience`
--

CREATE TABLE `seeker_experience` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `title` varchar(225) NOT NULL,
  `company` varchar(150) DEFAULT NULL,
  `location` varchar(200) NOT NULL,
  `frommonth` varchar(20) DEFAULT NULL,
  `fromyear` varchar(20) DEFAULT NULL,
  `tomonth` varchar(20) DEFAULT NULL,
  `toyear` varchar(20) DEFAULT NULL,
  `currently_working` int(11) DEFAULT NULL,
  `roles_and_responsibilities` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_experience`
--

INSERT INTO `seeker_experience` (`id`, `sid`, `position`, `title`, `company`, `location`, `frommonth`, `fromyear`, `tomonth`, `toyear`, `currently_working`, `roles_and_responsibilities`) VALUES
(3, 6, 'Entry Level', 'Developer', 'Longtail', 'Patandhoka', 'August', '2013', 'January', '2015', 1, '<p>1st and 2nd</p>');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_language`
--

CREATE TABLE `seeker_language` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `lang` varchar(50) DEFAULT NULL,
  `reading` varchar(20) DEFAULT NULL,
  `writing` varchar(20) DEFAULT NULL,
  `speaking` varchar(20) DEFAULT NULL,
  `listening` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_language`
--

INSERT INTO `seeker_language` (`id`, `sid`, `lang`, `reading`, `writing`, `speaking`, `listening`) VALUES
(5, 6, 'Nepal Bhasa', 'Excellent', 'Excellent', 'Excellent', 'Excellent'),
(4, 6, 'Nepali', 'Excellent', 'Excellent', 'Excellent', 'Bad');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_reference`
--

CREATE TABLE `seeker_reference` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `reference_name` varchar(100) DEFAULT NULL,
  `position` varchar(100) NOT NULL,
  `organization_name` varchar(100) NOT NULL,
  `mobile_number` varchar(25) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `other_number` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_reference`
--

INSERT INTO `seeker_reference` (`id`, `sid`, `reference_name`, `position`, `organization_name`, `mobile_number`, `email`, `other_number`) VALUES
(3, 6, 'Bishwas bajracharya', 'MD', 'Longtail', '987654321', 'info@longtail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_training`
--

CREATE TABLE `seeker_training` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `institution` varchar(100) DEFAULT NULL,
  `course` varchar(150) DEFAULT NULL,
  `frommonth` varchar(20) DEFAULT NULL,
  `fromyear` int(11) DEFAULT NULL,
  `tomonth` varchar(20) DEFAULT NULL,
  `toyear` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_training`
--

INSERT INTO `seeker_training` (`id`, `sid`, `institution`, `course`, `frommonth`, `fromyear`, `tomonth`, `toyear`) VALUES
(7, 6, 'ABC', 'basic computer cuorse', 'April', 2006, 'July', 2006),
(8, 6, 'NIIT', 'Php course', 'September', 2012, 'December', 2012);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `short_description` text NOT NULL,
  `logo` varchar(225) NOT NULL,
  `urlcode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `title`, `content`, `short_description`, `logo`, `urlcode`) VALUES
(2, 'Dot Wedge Datasheet test', '<p>&nbsp;testing</p>', '', '3273', 'dot-wedge-datasheet-test'),
(3, 'test', '<p>testing</p>', '', '', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblnewsletter`
--

CREATE TABLE `tblnewsletter` (
  `newsid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `newstitle` text NOT NULL,
  `newscontents` longtext NOT NULL,
  `newsdate` datetime NOT NULL,
  `newsstatus` varchar(30) NOT NULL,
  `publish` enum('1','0') DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `topbanner`
--

CREATE TABLE `topbanner` (
  `id` int(11) NOT NULL,
  `leftlink` varchar(100) NOT NULL,
  `leftimage` varchar(100) NOT NULL,
  `rightlink` varchar(100) NOT NULL,
  `rightimage` varchar(100) NOT NULL,
  `jobseeker` varchar(100) NOT NULL,
  `employer` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `modules` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `modules`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$i4lHh.NbeqcEyq/EJw/ZnO6mM4u2lTfG9a2piTRZNjL.ZOVOqBVvK', '', 'binaya619@gmail.com', NULL, 'BUlugA98bmn3pyC8rm-vGue06d1996684b385560', 1555919217, 'SPKT07hsjmo4jXlNmmVB7u', 1467791269, 1555918889, 1, 'Admin ', '', 'DAC', '', ''),
(2, '127.0.0.1', NULL, '$2y$08$O7WzYpYEa3Bm1fe4MPj11.BPDHHktjQzr.D0DgsaS3VUaL9jD.C9W', NULL, 'admin@financejobnepal.com', NULL, 'iwA5lEQ2dLyRXs6A2wX.5eae1a60b27c6cd01bff', 1555915110, 'AjJudS.ydXdMyOt04dnIku', 1494413182, 1568881944, 1, 'Roshan', 'Aacharya', 'Finance Job Nepal', '6226783', ''),
(3, '', 'user', '$2y$08$67pyVQlhZ2lnhKKURoaj.ONomY7enWAjNRyqTP9AFJTmOUjvdAwD.', NULL, 'user@financejobnepal.com', NULL, NULL, NULL, 'pcKMFoCXMxW6VG5ApcqLwu', 0, 1530687528, 1, 'Guest', '', 'Finance Job Nepal', '9841', ''),
(4, '', 'recruiter', '$2y$08$dTdJg2DIf/R7SFq.AgmhQOfXjucCV/yzxV97NMZwrSNP5hAwyurR.', NULL, 'recruiter@financejobnepal.com', NULL, NULL, NULL, 'esx33ZrGIKfdCaj9KDS2Ge', 1522035435, 1552193057, 1, 'Recruiter', '', 'Finance Job Nepal', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(94, 1, 1),
(95, 2, 1),
(96, 3, 2),
(97, 4, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertisement`
--
ALTER TABLE `advertisement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dropdown`
--
ALTER TABLE `dropdown`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker`
--
ALTER TABLE `seeker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_education`
--
ALTER TABLE `seeker_education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_experience`
--
ALTER TABLE `seeker_experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_language`
--
ALTER TABLE `seeker_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_reference`
--
ALTER TABLE `seeker_reference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_training`
--
ALTER TABLE `seeker_training`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblnewsletter`
--
ALTER TABLE `tblnewsletter`
  ADD PRIMARY KEY (`newsid`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topbanner`
--
ALTER TABLE `topbanner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertisement`
--
ALTER TABLE `advertisement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dropdown`
--
ALTER TABLE `dropdown`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=343;

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `seeker`
--
ALTER TABLE `seeker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `seeker_education`
--
ALTER TABLE `seeker_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `seeker_experience`
--
ALTER TABLE `seeker_experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seeker_language`
--
ALTER TABLE `seeker_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `seeker_reference`
--
ALTER TABLE `seeker_reference`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seeker_training`
--
ALTER TABLE `seeker_training`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblnewsletter`
--
ALTER TABLE `tblnewsletter`
  MODIFY `newsid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topbanner`
--
ALTER TABLE `topbanner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
