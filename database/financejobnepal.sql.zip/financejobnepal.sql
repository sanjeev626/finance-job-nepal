-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2019 at 01:05 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `financejobnepal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin` varchar(50) NOT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin`, `pass`, `email`, `fullname`, `title`) VALUES
(1, 'admin', 'ex+LDv3rDn1HXumipiwNkcnprH8kBEUhrKwvm2bDZXE=', 'info@globaljob.com.np', 'Global Jobs', 'Global Jobs');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE `advertisement` (
  `id` int(11) NOT NULL,
  `addtitle` varchar(150) DEFAULT NULL,
  `imagename` varchar(100) DEFAULT NULL,
  `addtype` enum('type1','type2') DEFAULT NULL,
  `addstatus` enum('publish','unpublish') DEFAULT NULL,
  `website` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `jid` int(11) DEFAULT NULL,
  `eid` int(11) NOT NULL,
  `appdate` date NOT NULL,
  `status` enum('0','shortlisted','rejected') NOT NULL DEFAULT '0',
  `remarks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `articles` text,
  `cr_date` varchar(20) DEFAULT NULL,
  `up_date` varchar(20) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `stat` enum('Y','N') DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `checkvalue`
--

CREATE TABLE `checkvalue` (
  `id` int(11) NOT NULL,
  `attid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `funcareaid` int(11) NOT NULL,
  `chkvalue` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `contents` text,
  `cr_date` varchar(20) DEFAULT NULL,
  `up_date` varchar(20) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `stat` enum('Y','N') DEFAULT 'N',
  `meta_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `country2code`
--

CREATE TABLE `country2code` (
  `id` int(11) NOT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `country_code2` varchar(5) DEFAULT NULL,
  `country_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country2code`
--

INSERT INTO `country2code` (`id`, `country_code`, `country_code2`, `country_name`) VALUES
(1, 'GB', 'GBR', 'UNITED KINGDOM'),
(2, 'US', 'USA', 'UNITED STATES'),
(3, 'BM', 'BMU', 'BERMUDA'),
(5, 'SE', 'SWE', 'SWEDEN'),
(7, 'IT', 'ITA', 'ITALY'),
(12, 'CA', 'CAN', 'CANADA'),
(17, 'PR', 'PRI', 'PUERTO RICO'),
(46, 'BO', 'BOL', 'BOLIVIA'),
(98, 'NL', 'NLD', 'NETHERLANDS'),
(105, 'DE', 'DEU', 'GERMANY'),
(107, 'CH', 'CHE', 'SWITZERLAND'),
(121, 'FR', 'FRA', 'FRANCE'),
(123, 'IL', 'ISR', 'ISRAEL'),
(127, 'ES', 'ESP', 'SPAIN'),
(236, 'CL', 'CHL', 'CHILE'),
(269, 'BS', 'BHS', 'BAHAMAS'),
(272, 'AR', 'ARG', 'ARGENTINA'),
(284, 'DM', 'DMA', 'DOMINICA'),
(298, 'BE', 'BEL', 'BELGIUM'),
(310, 'IE', 'IRL', 'IRELAND'),
(316, 'BZ', 'BLZ', 'BELIZE'),
(317, 'BR', 'BRA', 'BRAZIL'),
(319, 'MX', 'MEX', 'MEXICO'),
(349, 'JP', 'JPN', 'JAPAN'),
(359, 'IN', 'IND', 'INDIA'),
(361, 'AU', 'AUS', 'AUSTRALIA'),
(362, 'TH', 'THA', 'THAILAND'),
(364, 'CN', 'CHN', 'CHINA'),
(365, 'MY', 'MYS', 'MALAYSIA'),
(366, 'PK', 'PAK', 'PAKISTAN'),
(367, 'NZ', 'NZL', 'NEW ZEALAND'),
(368, 'KR', 'KOR', 'REPUBLIC OF KOREA'),
(371, 'HK', 'HKG', 'HONG KONG'),
(372, 'SG', 'SGP', 'SINGAPORE'),
(376, 'BD', 'BGD', 'BANGLADESH'),
(378, 'ID', 'IDN', 'INDONESIA'),
(383, 'PH', 'PHL', 'PHILIPPINES'),
(395, 'TW', 'TWN', 'TAIWAN'),
(432, 'AF', 'AFG', 'AFGHANISTAN'),
(453, 'VN', 'VNM', 'VIET NAM'),
(515, 'PA', 'PAN', 'PANAMA'),
(546, 'NC', 'NCL', 'NEW CALEDONIA'),
(549, 'BN', 'BRN', 'BRUNEI DARUSSALAM'),
(790, 'GR', 'GRC', 'GREECE'),
(792, 'SA', 'SAU', 'SAUDI ARABIA'),
(799, 'PL', 'POL', 'POLAND'),
(861, 'CZ', 'CZE', 'CZECH REPUBLIC'),
(864, 'RU', 'RUS', 'RUSSIAN FEDERATION'),
(874, 'DK', 'DNK', 'DENMARK'),
(875, 'NG', 'NGA', 'NIGERIA'),
(876, 'ZW', 'ZWE', 'ZIMBABWE'),
(882, 'IQ', 'IRQ', 'IRAQ'),
(886, 'FI', 'FIN', 'FINLAND'),
(888, 'IR', 'IRN', 'ISLAMIC REPUBLIC OF IRAN'),
(897, 'AE', 'ARE', 'UNITED ARAB EMIRATES'),
(903, 'GH', 'GHA', 'GHANA'),
(904, 'GA', 'GAB', 'GABON'),
(907, 'UG', 'UGA', 'UGANDA'),
(910, 'SD', 'SDN', 'SUDAN'),
(912, 'CY', 'CYP', 'CYPRUS'),
(917, 'NO', 'NOR', 'NORWAY'),
(923, 'AT', 'AUT', 'AUSTRIA'),
(925, 'UA', 'UKR', 'UKRAINE'),
(927, 'TJ', 'TJK', 'TAJIKISTAN'),
(2277, 'PT', 'PRT', 'PORTUGAL'),
(2278, 'TR', 'TUR', 'TURKEY'),
(2287, 'GE', 'GEO', 'GEORGIA'),
(2290, 'BY', 'BLR', 'BELARUS'),
(2311, 'AM', 'ARM', 'ARMENIA'),
(2322, 'LB', 'LBN', 'LEBANON'),
(2326, 'MD', 'MDA', 'REPUBLIC OF MOLDOVA'),
(2398, 'BG', 'BGR', 'BULGARIA'),
(2479, 'MZ', 'MOZ', 'MOZAMBIQUE'),
(2502, 'AO', 'AGO', 'ANGOLA'),
(2507, 'KE', 'KEN', 'KENYA'),
(2509, 'CD', 'COD', 'THE DEMOCRATIC REPUBLIC OF THE CONGO'),
(2510, 'MG', 'MDG', 'MADAGASCAR'),
(2512, 'TZ', 'TZA', 'UNITED REPUBLIC OF TANZANIA'),
(2515, 'TG', 'TGO', 'TOGO'),
(2523, 'ZM', 'ZMB', 'ZAMBIA'),
(2530, 'CM', 'CMR', 'CAMEROON'),
(3828, 'OM', 'OMN', 'OMAN'),
(3853, 'LV', 'LVA', 'LATVIA'),
(3856, 'KZ', 'KAZ', 'KAZAKHSTAN'),
(3879, 'EE', 'EST', 'ESTONIA'),
(3882, 'SK', 'SVK', 'SLOVAKIA'),
(3949, 'BA', 'BIH', 'BOSNIA AND HERZEGOVINA'),
(3951, 'HU', 'HUN', 'HUNGARY'),
(3955, 'KW', 'KWT', 'KUWAIT'),
(4192, 'AL', 'ALB', 'ALBANIA'),
(4264, 'LT', 'LTU', 'LITHUANIA'),
(4427, 'SM', 'SMR', 'SAN MARINO'),
(5143, 'RO', 'ROM', 'ROMANIA'),
(5178, 'CS', 'SCG', 'SERBIA AND MONTENEGRO'),
(5683, 'MA', 'MAR', 'MOROCCO'),
(5731, 'LU', 'LUX', 'LUXEMBOURG'),
(5767, 'DZ', 'DZA', 'ALGERIA'),
(5792, 'IS', 'ISL', 'ICELAND'),
(5883, 'CR', 'CRI', 'COSTA RICA'),
(6017, 'MK', 'MKD', 'THE FORMER YUGOSLAV REPUBLIC OF MACEDONIA'),
(6245, 'MT', 'MLT', 'MALTA'),
(6252, 'GM', 'GMB', 'GAMBIA'),
(6286, 'SZ', 'SWZ', 'SWAZILAND'),
(6491, 'ZA', 'ZAF', 'SOUTH AFRICA'),
(7222, 'MW', 'MWI', 'MALAWI'),
(7457, 'FK', 'FLK', 'FALKLAND ISLANDS (MALVINAS)'),
(7514, 'BH', 'BHR', 'BAHRAIN'),
(7537, 'UZ', 'UZB', 'UZBEKISTAN'),
(7552, 'AZ', 'AZE', 'AZERBAIJAN'),
(7563, 'EG', 'EGY', 'EGYPT'),
(7740, 'MC', 'MCO', 'MONACO'),
(7790, 'HT', 'HTI', 'HAITI'),
(7795, 'GU', 'GUM', 'GUAM'),
(7801, 'FM', 'FSM', 'FEDERATED STATES OF MICRONESIA'),
(7809, 'CO', 'COL', 'COLOMBIA'),
(7821, 'LR', 'LBR', 'LIBERIA'),
(7831, 'EC', 'ECU', 'ECUADOR'),
(7872, 'KY', 'CYM', 'CAYMAN ISLANDS'),
(7875, 'PE', 'PER', 'PERU'),
(7919, 'HN', 'HND', 'HONDURAS'),
(7923, 'SL', 'SLE', 'SIERRA LEONE'),
(7991, 'ML', 'MLI', 'MALI'),
(8005, 'LC', 'LCA', 'SAINT LUCIA'),
(8055, 'NI', 'NIC', 'NICARAGUA'),
(8057, 'DO', 'DOM', 'DOMINICAN REPUBLIC'),
(8063, 'AN', 'ANT', 'NETHERLANDS ANTILLES'),
(8073, 'GT', 'GTM', 'GUATEMALA'),
(8206, 'TT', 'TTO', 'TRINIDAD AND TOBAGO'),
(8354, 'BV', 'BVT', 'BOUVET ISLAND'),
(8377, 'VE', 'VEN', 'VENEZUELA'),
(8416, 'WS', 'WSM', 'SAMOA'),
(8421, 'MH', 'MHL', 'MARSHALL ISLANDS'),
(8504, 'PW', 'PLW', 'PALAU'),
(8558, 'BB', 'BRB', 'BARBADOS'),
(8618, 'MP', 'MNP', 'NORTHERN MARIANA ISLANDS'),
(8792, 'GD', 'GRD', 'GRENADA'),
(8793, 'VC', 'VCT', 'SAINT VINCENT AND THE GRENADINES'),
(8968, 'SV', 'SLV', 'EL SALVADOR'),
(8973, 'JM', 'JAM', 'JAMAICA'),
(8997, 'CU', 'CUB', 'CUBA'),
(9017, 'TC', 'TCA', 'TURKS AND CAICOS ISLANDS'),
(9061, 'CG', 'COG', 'CONGO'),
(9318, 'PY', 'PRY', 'PARAGUAY'),
(9326, 'RW', 'RWA', 'RWANDA'),
(9336, 'SR', 'SUR', 'SURINAME'),
(9339, 'GY', 'GUY', 'GUYANA'),
(9577, 'PG', 'PNG', 'PAPUA NEW GUINEA'),
(9647, 'KN', 'KNA', 'SAINT KITTS AND NEVIS'),
(9675, 'AG', 'ATG', 'ANTIGUA AND BARBUDA'),
(9689, 'GI', 'GIB', 'GIBRALTAR'),
(9775, 'AW', 'ABW', 'ARUBA'),
(9820, 'UY', 'URY', 'URUGUAY'),
(9893, 'JO', 'JOR', 'JORDAN'),
(10238, 'SY', 'SYR', 'SYRIAN ARAB REPUBLIC'),
(10364, 'UM', 'UMI', 'UNITED STATES MINOR OUTLYING ISLANDS'),
(11042, 'SI', 'SVN', 'SLOVENIA'),
(11133, 'MU', 'MUS', 'MAURITIUS'),
(11176, 'NE', 'NER', 'NIGER'),
(11476, 'KG', 'KGZ', 'KYRGYZSTAN'),
(11477, 'TM', 'TKM', 'TURKMENISTAN'),
(11524, 'HR', 'HRV', 'CROATIA'),
(12106, 'GN', 'GIN', 'GUINEA'),
(12108, 'MM', 'MMR', 'MYANMAR'),
(12118, 'BJ', 'BEN', 'BENIN'),
(12120, 'CF', 'CAF', 'CENTRAL AFRICAN REPUBLIC'),
(12122, 'ET', 'ETH', 'ETHIOPIA'),
(12123, 'NP', 'NPL', 'NEPAL'),
(12126, 'BT', 'BTN', 'BHUTAN'),
(12155, 'QA', 'QAT', 'QATAR'),
(12176, 'NA', 'NAM', 'NAMIBIA'),
(12409, 'BW', 'BWA', 'BOTSWANA'),
(12434, 'TD', 'TCD', 'CHAD'),
(12992, 'RE', 'REU', 'REUNION'),
(13016, 'SO', 'SOM', 'SOMALIA'),
(13034, 'BI', 'BDI', 'BURUNDI'),
(13044, 'FO', 'FRO', 'FAROE ISLANDS'),
(13111, 'LS', 'LSO', 'LESOTHO'),
(13115, 'MR', 'MRT', 'MAURITANIA'),
(13124, 'NR', 'NRU', 'NAURU'),
(13862, 'LY', 'LBY', 'LIBYAN ARAB JAMAHIRIYA'),
(13937, 'KM', 'COM', 'COMOROS'),
(14077, 'LI', 'LIE', 'LIECHTENSTEIN'),
(14349, 'SC', 'SYC', 'SEYCHELLES'),
(14537, 'LA', 'LAO', 'LAO PEOPLES DEMOCRATIC REPUBLIC'),
(14539, 'LK', 'LKA', 'SRI LANKA'),
(15134, 'TN', 'TUN', 'TUNISIA'),
(15377, 'MQ', 'MTQ', 'MARTINIQUE'),
(15386, 'GP', 'GLP', 'GUADELOUPE'),
(15881, 'VA', 'VAT', 'HOLY SEE (VATICAN CITY STATE)'),
(16119, 'YE', 'YEM', 'YEMEN'),
(17815, 'YT', 'MYT', 'MAYOTTE'),
(17955, 'BF', 'BFA', 'BURKINA FASO'),
(19155, 'AQ', 'ATA', 'ANTARCTICA'),
(19367, 'KH', 'KHM', 'CAMBODIA'),
(19382, 'MV', 'MDV', 'MALDIVES'),
(19572, 'MO', 'MAC', 'MACAO'),
(19665, 'WF', 'WLF', 'WALLIS AND FUTUNA'),
(19927, 'MN', 'MNG', 'MONGOLIA'),
(20046, 'FJ', 'FJI', 'FIJI'),
(20343, 'VU', 'VUT', 'VANUATU'),
(20502, 'PF', 'PYF', 'FRENCH POLYNESIA'),
(37111, 'GQ', 'GNQ', 'EQUATORIAL GUINEA'),
(37537, 'DJ', 'DJI', 'DJIBOUTI'),
(39188, 'GW', 'GNB', 'GUINEA-BISSAU'),
(39980, 'SN', 'SEN', 'SENEGAL'),
(41750, 'PS', 'PSE', 'PALESTINIAN TERRITORY, OCCUPIED'),
(41824, 'AD', 'AND', 'ANDORRA'),
(44897, 'GL', 'GRL', 'GREENLAND'),
(46296, 'CV', 'CPV', 'CAPE VERDE'),
(46297, 'ST', 'STP', 'SAO TOME AND PRINCIPE'),
(57574, 'MS', 'MSR', 'MONTSERRAT'),
(58292, 'TF', 'ATF', 'FRENCH SOUTHERN TERRITORIES'),
(58517, 'GF', 'GUF', 'FRENCH GUIANA'),
(59439, 'GS', 'SGS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS'),
(59511, 'SB', 'SLB', 'SOLOMON ISLANDS'),
(59525, 'TV', 'TUV', 'TUVALU'),
(59615, 'KI', 'KIR', 'KIRIBATI'),
(59968, 'TO', 'TON', 'TONGA'),
(59991, 'IO', 'IOT', 'BRITISH INDIAN OCEAN TERRITORY'),
(60199, 'CK', 'COK', 'COOK ISLANDS'),
(60249, 'AS', 'ASM', 'AMERICAN SAMOA'),
(60276, 'TL', 'TLS', 'TIMOR-LESTE'),
(60278, 'TK', 'TKL', 'TOKELAU'),
(61485, 'NF', 'NFK', 'NORFOLK ISLAND'),
(62134, 'VG', 'VGB', 'VIRGIN ISLANDS, BRITISH'),
(62156, 'VI', 'VIR', 'VIRGIN ISLANDS, U.S.'),
(62261, 'AI', 'AIA', 'ANGUILLA'),
(72662, 'ER', 'ERI', 'ERITREA'),
(73648, 'CI', 'CIV', 'COTE D IVOIRE');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown`
--

CREATE TABLE `dropdown` (
  `id` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `dropvalue` varchar(50) NOT NULL,
  `ordering` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dropdown`
--

INSERT INTO `dropdown` (`id`, `fid`, `dropvalue`, `ordering`) VALUES
(1, 9, 'Personal Care/Beauty/Cosmetics', 0),
(2, 9, 'BPO/Call Center', 0),
(3, 9, 'Content, Journalism', 0),
(4, 6, 'Private', 0),
(5, 6, 'Public', 0),
(6, 6, 'Government', 0),
(7, 5, 'Sole Proprietorship', 0),
(8, 5, 'Partnership', 0),
(9, 7, 'Mr.', 0),
(10, 7, 'Mrs.', 0),
(11, 7, 'Miss', 0),
(12, 3, 'Intermediate', 0),
(13, 3, 'Bachelor', 0),
(14, 3, 'Master', 0),
(15, 2, 'Charikot', 0),
(16, 10, 'Banking, Finance & Insurance Services', 0),
(17, 10, 'Automobiles Sales & Services', 0),
(18, 10, 'Architect & Interior Design', 0),
(19, 10, 'Accounting / Finance', 0),
(20, 8, 'Nepali', 0),
(21, 8, 'Indian', 0),
(22, 8, 'Other', 0),
(23, 9, 'Accounts/Finance', 0),
(24, 11, 'Higher Secondary', 0),
(25, 11, 'Secondary School', 0),
(26, 11, 'Vocational Course', 0),
(27, 11, 'Diploma', 0),
(28, 11, 'Advanced/Higher Diploma', 0),
(29, 11, 'Professional Degree', 0),
(30, 11, 'Bachelor Degree', 0),
(31, 11, 'B.A', 0),
(32, 11, 'B.Arch', 0),
(33, 11, 'B.C.A', 0),
(34, 11, 'B.B.A', 0),
(35, 11, 'B.Com', 0),
(36, 11, 'B.Ed', 0),
(37, 11, 'BDS', 0),
(38, 11, 'BHM', 0),
(39, 11, 'B.Pharma', 0),
(40, 11, 'B.Sc', 0),
(41, 11, 'B.Tech/B.E', 0),
(42, 11, 'LLB', 0),
(43, 11, 'MBBS', 0),
(44, 11, 'BVSC', 0),
(45, 11, 'Master Degree', 0),
(46, 11, 'Post Graduate Diploma', 0),
(47, 11, 'M.A', 0),
(48, 11, 'M.Arch', 0),
(49, 11, 'M.C.A', 0),
(50, 11, 'M.B.A/PGDM', 0),
(51, 11, 'M.Com', 0),
(52, 11, 'M.Ed', 0),
(53, 11, 'MS', 0),
(54, 11, 'M.Pharma', 0),
(55, 11, 'M.Sc', 0),
(56, 11, 'M.Tech', 0),
(57, 11, 'LLM', 0),
(58, 11, 'MVSC', 0),
(59, 11, 'CA', 0),
(60, 11, 'CS', 0),
(61, 11, 'ICWA', 0),
(62, 11, 'Integrated PG', 0),
(63, 11, 'Doctorate Degree', 0),
(64, 11, 'Some Tertiary Coursework', 0),
(65, 11, 'Ph.D/Doctorate', 0),
(66, 11, 'MPHIL', 0),
(67, 11, 'Others', 0),
(68, 12, 'Full Time', 0),
(69, 12, 'Correspondence', 0),
(70, 12, 'Distance Learning', 0),
(71, 4, 'NRs. 5000-10000', 0),
(72, 2, 'Birendranagar', 0),
(73, 4, 'NRs. 10000-15000', 0),
(74, 4, 'NRs. 15000-20000', 0),
(75, 4, 'NRs. 20000-25000', 0),
(76, 4, 'NRs. 25000-30000', 0),
(77, 4, 'NRs. 40000-45000', 0),
(78, 2, 'Biratnagar', 0),
(79, 2, 'Damak', 0),
(80, 2, 'Butwal', 0),
(81, 2, 'Itahari', 0),
(82, 2, 'Chandragadhi', 0),
(83, 2, 'Birtamode', 0),
(84, 4, 'NRs. 45000-50000', 0),
(85, 9, 'Engineering/Design/R & D', 0),
(86, 9, 'Export/Import/Trading', 0),
(87, 9, 'Front Office/Fresher/Trainee Jobs', 0),
(88, 9, 'Hotels/Restaurants', 0),
(89, 9, 'Industrial Sectors', 0),
(90, 9, 'ICT-Hardware & Software Services', 0),
(91, 9, 'Media/Entertainment', 0),
(92, 9, 'NGO/Government, Defence Job', 0),
(93, 9, 'Manpower/Overseas/International', 0),
(94, 9, 'Pharma, Biotech', 0),
(95, 9, 'Procurement/Supply Chain/Logistics/Commercial', 0),
(96, 9, 'Secretary/Assistant', 0),
(97, 9, 'Site Engineering', 0),
(98, 9, 'Telecom & Satellite', 0),
(99, 9, 'Travel/Airlines/GSA', 0),
(100, 9, 'TV/Films/Music/Production', 0),
(101, 9, 'Walk In Interviews', 0),
(102, 9, 'Web/Graphic Design', 0),
(103, 2, 'Bhojpur', 0),
(104, 2, 'Bharatpur', 0),
(105, 3, 'B.E.Civil', 0),
(106, 4, 'NRs. 50000-60000', 0),
(107, 4, 'NRs. 60000-70000', 0),
(108, 10, 'BPO/Call Center', 0),
(109, 10, 'Content, Journalism', 0),
(110, 10, 'Construction, Engineering Consultants', 0),
(111, 10, 'Engineering, Design, R & D', 0),
(112, 10, 'Export/Import/Trading', 0),
(113, 10, 'Fashion, Garment', 0),
(114, 10, 'Front Office, Fresher, Trainee Jobs', 0),
(115, 10, 'Healthcare, Medical, R & D', 0),
(116, 10, 'Hotels, Restaurants', 0),
(117, 10, 'HR & Admin', 0),
(118, 10, 'Industrial Sectors', 0),
(119, 10, 'IT-Hardware & Software Services', 0),
(120, 10, 'Legal Consulting', 0),
(121, 10, 'Marketing, Advertising & Sales', 0),
(122, 10, 'Event Management/Entertainment', 0),
(123, 10, 'NGO/INGO/Government/Social Work', 0),
(124, 10, 'Overseas/Manpower/International', 0),
(125, 10, 'Pharma, Biotech', 0),
(126, 10, 'Purchase, Supply Chain', 0),
(127, 10, 'Secretary', 0),
(128, 10, 'Site Engineering', 0),
(129, 10, 'Teaching, Education', 0),
(130, 10, 'Telecom & Satellite', 0),
(131, 10, 'Travel, Airlines, GSA', 0),
(132, 10, 'TV/Films/Media', 0),
(133, 10, 'Walk In Interviews', 0),
(134, 10, 'Web, Graphic Design', 0),
(135, 10, 'Others', 0),
(136, 9, 'Architect/Interior Designing', 0),
(137, 9, 'Bank/Finance/Insurance', 0),
(138, 9, 'Construction/Engineering/R & D', 0),
(139, 9, 'Commercial/Purchase/Logistics/Supply Chain', 0),
(140, 9, 'Creative & Graphics Designing/Animation', 0),
(141, 9, 'Fashion/Garments', 0),
(142, 9, 'Healthcare/Pharma/Biotech/Chemist/Microbiologist', 0),
(143, 9, 'Human Resource & Administration', 0),
(144, 9, 'IT-Hardware/Software/Programming', 0),
(145, 9, 'Journalism', 0),
(146, 9, 'Legal & Consulting Services', 0),
(147, 9, 'Marketing/Client Servicing/Customer Relations', 0),
(148, 9, 'Production/Maintenance/Quality', 0),
(149, 9, 'Marketing/Advertising & Sales', 0),
(150, 9, 'Secretarial/Front Desk', 0),
(151, 9, 'Security Services', 0),
(152, 9, 'Teaching/Education & Counselling', 0),
(153, 9, 'Social Services & Development Sector', 0),
(154, 9, 'Others', 0),
(155, 3, 'B.E. Mechanical', 0),
(156, 3, 'B.E. Electrical', 0),
(157, 3, 'B.E. Computer', 0),
(158, 3, 'B.E. Architecture', 0),
(159, 2, 'Bhaktapur', 0),
(160, 3, 'MBA', 0),
(161, 3, 'MBS', 0),
(162, 3, 'Diploma Level', 0),
(163, 3, 'Certificate Level', 0),
(164, 3, 'Proficiency', 0),
(165, 3, 'School Leaving Certificate', 0),
(166, 2, 'Bhadrapur', 0),
(167, 2, 'Beni', 0),
(168, 2, 'Dharan', 0),
(169, 2, 'Bardibas', 0),
(170, 2, 'Bardiya', 0),
(171, 2, 'Bara', 0),
(172, 9, 'Executive Assistant/Secretary/Front Desk ', 0),
(173, 9, 'General Manager/CEO/Country Manager', 0),
(174, 10, 'Sales', 0),
(175, 9, 'Public Relation', 0),
(176, 9, 'Sales/Business development', 0),
(177, 2, 'Banke', 0),
(178, 2, 'Banepa', 0),
(179, 2, 'Janakpur', 0),
(180, 2, 'Birgunj', 0),
(181, 2, 'Bandipur', 0),
(182, 2, 'Bajhang', 0),
(183, 9, 'Investment/Business Consultation', 0),
(184, 9, 'Country Director', 0),
(185, 2, 'Baitadi', 0),
(186, 2, 'Baglung', 0),
(187, 2, 'Hetauda', 0),
(188, 2, 'Arghakhanchi', 0),
(189, 2, 'Narayangarh', 0),
(190, 4, 'NRs. 70000-80000', 0),
(191, 4, 'NRs. 80000-90000', 0),
(192, 4, 'NRs. 90000-100000', 0),
(193, 4, 'NRs. 100000+', 0),
(194, 2, 'Various Places', 0),
(195, 3, 'Chartered Accountant', 0),
(196, 9, 'Hotels/Airlines', 0),
(197, 3, 'BBA', 0),
(198, 4, 'Negotiable', 0),
(199, 2, 'Accham', 0),
(200, 3, 'CTEVT Certified/Vocational Training', 0),
(201, 9, 'Automotive/Auto body/Automobiles/Alternative fuels', 0),
(202, 2, 'Pokhara', 0),
(203, 2, 'Butwal', 0),
(204, 2, 'Bhairahawa', 0),
(205, 2, 'Ghorahi', 0),
(206, 2, 'Tulsipur', 0),
(207, 2, 'Nepalgunj', 0),
(208, 2, 'Tikapur', 0),
(209, 2, 'Dhangadhi', 0),
(210, 2, 'Mahendranagar', 0),
(211, 2, 'Kathmandu', 0),
(212, 12, 'e-Learning', 0),
(213, 15, 'Eastern Region', 0),
(214, 15, 'Central Region', 0),
(215, 15, 'Western Region', 0),
(216, 15, 'Mid Western Region', 0),
(217, 15, 'Far Western Region', 0),
(218, 2, 'Chitwan', 0),
(219, 2, 'Dadeldhura', 0),
(220, 2, 'Dailekh', 0),
(221, 2, 'Damauli', 0),
(222, 2, 'Dang', 0),
(223, 2, 'Darchula', 0),
(224, 2, 'Dhading', 0),
(225, 2, 'Dhankuta', 0),
(226, 2, 'Gaur', 0),
(227, 2, 'Gorkha', 0),
(228, 2, 'Jhapa', 0),
(229, 2, 'Kaski', 0),
(230, 2, 'Kavrepalanchok', 0),
(231, 2, 'Laltipur', 0),
(232, 2, 'Mahottari', 0),
(233, 2, 'Sindhupalchowk', 0),
(234, 2, 'Taplejung', 0),
(235, 2, 'Therathum', 0),
(236, 2, 'Ilam', 0),
(237, 2, 'Jaleshwar', 0),
(238, 2, 'Kailali', 0),
(239, 2, 'Kakarvita', 0),
(240, 2, 'Kalaiya', 0),
(241, 2, 'Makawanpur', 0),
(242, 2, 'Morang', 0),
(243, 2, 'Nawalparasi', 0),
(244, 2, 'Parbat', 0),
(245, 2, 'Nuwakot', 0),
(246, 2, 'Palpa', 0),
(247, 2, 'Pyuthan', 0),
(248, 2, 'Ramechhap', 0),
(249, 2, 'Udaypur', 0),
(250, 2, 'Trishuli', 0),
(251, 2, 'Tanahu', 0),
(252, 2, 'Syanja', 0),
(253, 2, 'Surkhet', 0),
(254, 2, 'Sunsari', 0),
(255, 2, 'Siraha', 0),
(256, 2, 'Sindhuli', 0),
(257, 2, 'Simara', 0),
(258, 2, 'Sarlahi', 0),
(259, 2, 'Saptari', 0),
(260, 2, 'Salyan', 0),
(261, 2, 'Rupandehi', 0),
(262, 2, 'Jajarkot', 0),
(263, 9, 'Audit/Tax Consultation', 0),
(264, 10, 'Hydropower ', 0),
(265, 10, 'Housing/Real Estate', 0),
(266, 10, 'Distribution/Retail/Wholesale', 0),
(267, 2, 'Kathmandu', 0),
(268, 15, 'Kathmandu Valley', 0),
(269, 15, 'Pokhara Region', 0),
(270, 3, 'BBS', 0),
(271, 3, 'B.Tech', 0),
(272, 3, 'M.Ed', 0),
(273, 3, 'ACCA', 0),
(274, 3, 'B.IT', 0),
(275, 3, 'B.A', 0),
(276, 3, 'M.A', 0),
(277, 9, 'Security/Defense', 0),
(278, 5, 'Corporation', 0),
(279, 5, 'Joint Venture', 0),
(280, 5, 'Association', 0),
(281, 10, 'FMCG/Manufacturing', 0),
(282, 10, 'Security Providers', 0),
(283, 3, 'M.Sc', 0),
(284, 3, 'PhD/Doctorate', 0),
(285, 3, 'MBBS', 0),
(286, 3, 'BHM', 0),
(287, 10, 'Embassies', 0),
(288, 10, 'Handicraft Manufacturing', 0),
(289, 3, 'Bachelor Running', 0),
(290, 3, 'Master Running', 0),
(291, 9, 'Agriculture/Dairy', 0),
(292, 3, 'MBA General', 0),
(293, 3, 'MBA Marketing', 0),
(294, 3, 'MBA Finance', 0),
(295, 3, 'MBA Human Resource Management', 0),
(296, 6, 'Non-Governmental', 0),
(297, 5, 'Others', 0),
(298, 9, 'Administration', 0),
(299, 2, 'kathmandu', 0),
(300, 4, 'Don\'t disclose', 0),
(301, 12, 'Part Time', 0),
(302, 10, 'Manufacturing', 0),
(303, 10, 'Service', 0),
(304, 16, 'Fresher Jobs', 5),
(305, 16, 'Walk-in Jobs', 6),
(306, 16, 'MBA- MT Jobs', 7),
(307, 16, 'Manufacturing Jobs', 2),
(308, 16, 'ICT Jobs', 1),
(309, 16, 'Hospitality Jobs', 3),
(310, 16, 'Int’l Jobs', 4),
(311, 16, 'I/NGOs Jobs', 8),
(312, 17, 'Entry Level', 1),
(313, 17, 'Mid Level', 2),
(314, 17, 'Senior Level', 3),
(315, 17, 'Top Level', 4);

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `orgname` varchar(200) NOT NULL,
  `organization_code` varchar(255) NOT NULL,
  `organization_name` varchar(200) DEFAULT NULL,
  `organization_type` int(50) DEFAULT NULL,
  `organization_address` varchar(100) DEFAULT NULL,
  `organization_size` varchar(100) NOT NULL,
  `organization_description` text NOT NULL,
  `organization_phone` varchar(50) DEFAULT NULL,
  `organization_fax` varchar(25) DEFAULT NULL,
  `organization_pobox` varchar(25) DEFAULT NULL,
  `organization_website` varchar(50) DEFAULT NULL,
  `organization_logo` varchar(50) DEFAULT NULL,
  `organization_banner` varchar(100) DEFAULT NULL,
  `organization_facebook` varchar(200) NOT NULL,
  `organization_linkedin` varchar(200) NOT NULL,
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_designation` varchar(50) DEFAULT NULL,
  `contact_email` varchar(50) DEFAULT NULL,
  `contact_mobile` varchar(50) DEFAULT NULL,
  `alternate_contact_name` varchar(50) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime NOT NULL,
  `last_accessed` datetime NOT NULL,
  `isActivated` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `activation_code` varchar(50) NOT NULL,
  `token` varchar(150) DEFAULT NULL,
  `joindate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`id`, `username`, `email`, `password`, `orgname`, `organization_code`, `organization_name`, `organization_type`, `organization_address`, `organization_size`, `organization_description`, `organization_phone`, `organization_fax`, `organization_pobox`, `organization_website`, `organization_logo`, `organization_banner`, `organization_facebook`, `organization_linkedin`, `contact_name`, `contact_designation`, `contact_email`, `contact_mobile`, `alternate_contact_name`, `date_created`, `date_modified`, `last_accessed`, `isActivated`, `activation_code`, `token`, `joindate`) VALUES
(2, 'dac@info.com', 'dac@info.com', '25f9e794323b453885f5181f1b624d0b', 'Digital Agency Catmandu', 'digital-agency-catmandu-2', 'Digital Agency Catmandu', 119, 'Baluwatar, Kathmandu, Nepal', '0-10', '<p>TEsting for information</p>', '987654321', NULL, '', 'digitalagencycatmandu.com', '9063company_logo.png', '5216easymandu.png', 'https://www.facebook.com/', 'https://www.linkedin.com/', 'Sanjeev Singh', 'MD', '', '', '', '2019-03-14 10:30:32', '0000-00-00 00:00:00', '2019-04-10 11:00:39', 'Yes', '', NULL, '2019-03-14'),
(3, 'admin@amin.com', 'admin@amin.com', '6ebe76c9fb411be97b3b0d48b791a7c9', 'my company', 'my-company-3', 'my company', NULL, NULL, '', '', '987654321', NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, '2019-03-22 10:26:00', '0000-00-00 00:00:00', '2019-03-22 16:12:28', 'Yes', '', NULL, '2019-03-22');

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fields`
--

INSERT INTO `fields` (`id`, `title`) VALUES
(2, 'Job Location'),
(3, 'Education'),
(4, 'Salary Range'),
(5, 'Ownership'),
(6, 'Organization Type'),
(7, 'Organization Size'),
(8, 'Nationality'),
(9, 'Funtional Area'),
(11, 'Education Level'),
(15, 'Job Region'),
(16, 'Job Type'),
(17, 'Job Level');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `eid` int(11) DEFAULT NULL,
  `displayname` varchar(150) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `jobtitle` varchar(150) DEFAULT NULL,
  `jobcategory` int(11) DEFAULT NULL,
  `preferredgender` enum('Male','Female','Male/Female','Both') NOT NULL DEFAULT 'Male',
  `requiredno` varchar(150) DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pmm` int(11) DEFAULT NULL,
  `pdd` int(11) DEFAULT NULL,
  `pyy` int(11) DEFAULT NULL,
  `post_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedate` date NOT NULL,
  `apmm` int(11) DEFAULT NULL,
  `apdd` int(11) DEFAULT NULL,
  `apyy` int(11) DEFAULT NULL,
  `applybefore` date NOT NULL,
  `salaryrange` varchar(25) DEFAULT NULL,
  `exprequire` varchar(10) NOT NULL,
  `noexperience` varchar(100) DEFAULT NULL,
  `education` int(11) DEFAULT NULL,
  `joblevel` varchar(15) DEFAULT NULL,
  `jobtype` varchar(15) DEFAULT NULL,
  `jobtype2` varchar(15) DEFAULT NULL,
  `jobtype3` varchar(15) DEFAULT NULL,
  `jobtype4` varchar(15) NOT NULL,
  `otherstype` varchar(50) NOT NULL,
  `joblocation` varchar(250) DEFAULT NULL,
  `brief` text,
  `background` text,
  `specification` text,
  `requirements` text,
  `howtoapply` text,
  `acceptonline` enum('Yes','No') DEFAULT 'No',
  `onlineap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `emailap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `postap` enum('Yes','No') NOT NULL DEFAULT 'No',
  `video_cv` varchar(10) NOT NULL,
  `isNewspaperJob` text,
  `job_display_in` varchar(50) DEFAULT '',
  `isWalkin` enum('0','1') NOT NULL DEFAULT '0',
  `pobox` text,
  `adminPosted` enum('1','0') NOT NULL DEFAULT '0',
  `complogo` varchar(150) NOT NULL,
  `banner_image` varchar(200) DEFAULT NULL,
  `post_status` varchar(100) NOT NULL,
  `apply_by_faculty` varchar(100) DEFAULT NULL,
  `apply_by_age` varchar(100) NOT NULL,
  `from_age` int(11) NOT NULL,
  `to_age` int(11) NOT NULL,
  `postedin` varchar(100) NOT NULL,
  `orgemail` varchar(100) NOT NULL,
  `no_of_views` varchar(100) DEFAULT NULL,
  `required_education` varchar(200) NOT NULL,
  `expected_faculty` text NOT NULL,
  `other_faculty` varchar(200) NOT NULL,
  `slc_docs` int(11) DEFAULT NULL,
  `docs_11_12` int(11) DEFAULT NULL,
  `bachelor_docs` int(11) DEFAULT NULL,
  `masters_docs` int(11) DEFAULT NULL,
  `isEmailed` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `eid`, `displayname`, `slug`, `jobtitle`, `jobcategory`, `preferredgender`, `requiredno`, `date_added`, `pmm`, `pdd`, `pyy`, `post_date`, `updatedate`, `apmm`, `apdd`, `apyy`, `applybefore`, `salaryrange`, `exprequire`, `noexperience`, `education`, `joblevel`, `jobtype`, `jobtype2`, `jobtype3`, `jobtype4`, `otherstype`, `joblocation`, `brief`, `background`, `specification`, `requirements`, `howtoapply`, `acceptonline`, `onlineap`, `emailap`, `postap`, `video_cv`, `isNewspaperJob`, `job_display_in`, `isWalkin`, `pobox`, `adminPosted`, `complogo`, `banner_image`, `post_status`, `apply_by_faculty`, `apply_by_age`, `from_age`, `to_age`, `postedin`, `orgemail`, `no_of_views`, `required_education`, `expected_faculty`, `other_faculty`, `slc_docs`, `docs_11_12`, `bachelor_docs`, `masters_docs`, `isEmailed`) VALUES
(3, 2, NULL, 'testing-job', 'Testing Job', 298, 'Male', '5', '2019-03-21 07:56:26', 3, 23, 2019, '2019-03-22 18:15:00', '2019-03-21', 4, 20, 2019, '2019-04-20', '198', 'No', '', NULL, '313', '309', '', '', '', '', '199,188,186', NULL, NULL, 'testing', 'testing', NULL, 'No', 'No', 'No', 'No', 'No', NULL, '', '0', NULL, '', '', NULL, 'public', NULL, '-', 0, 0, '', '', NULL, 'Not Required', '', '', NULL, NULL, NULL, NULL, '1'),
(4, 2, NULL, 'job-title', 'Job Title', 291, 'Male/Female', '1', '2019-03-27 07:35:17', 3, 21, 2019, '2019-03-20 18:15:00', '2019-03-27', 4, 20, 2019, '2019-04-20', '198', 'No', '', NULL, '313', '', '', '', '', '', '188', NULL, NULL, '', '', NULL, 'No', 'No', 'No', 'No', 'No', NULL, '', '0', NULL, '', '', NULL, 'public', NULL, '-', 0, 0, '', '', NULL, 'Not Required', '', '', NULL, NULL, NULL, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `seeker`
--

CREATE TABLE `seeker` (
  `id` int(11) NOT NULL,
  `email` varchar(35) DEFAULT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `summary` text,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `address_permanent` varchar(255) DEFAULT NULL,
  `address_current` varchar(255) DEFAULT NULL,
  `phone_cell` varchar(25) DEFAULT NULL,
  `phone_resisdance` varchar(25) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `dob` date NOT NULL,
  `marital_status` enum('Married','Single') DEFAULT 'Single',
  `nationality` int(11) DEFAULT NULL,
  `highest_qualification` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `have_work_experience` enum('Yes','No') DEFAULT 'No',
  `experience_years` int(11) DEFAULT NULL,
  `experience_months` int(11) DEFAULT NULL,
  `cjobposiiton` varchar(100) NOT NULL,
  `keyskills` text NOT NULL,
  `profile_summary` text NOT NULL,
  `desired_industry` varchar(255) DEFAULT NULL,
  `desired_functional_area` varchar(255) DEFAULT NULL,
  `desired_role` varchar(100) DEFAULT NULL,
  `desired_job_type` varchar(50) DEFAULT NULL,
  `desired_employment_type` varchar(100) DEFAULT NULL,
  `desired_shift` varchar(100) NOT NULL,
  `desired_expected_salary` int(11) NOT NULL,
  `desired_job_location` varchar(100) NOT NULL,
  `past_employer` varchar(100) NOT NULL,
  `current_employer` varchar(100) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `facebook` varchar(150) NOT NULL,
  `linkedin` varchar(150) NOT NULL,
  `resume` varchar(150) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime NOT NULL,
  `last_accessed` datetime NOT NULL,
  `isActivated` enum('1','0') NOT NULL DEFAULT '0',
  `activation_code` varchar(50) NOT NULL,
  `lastaccess` datetime NOT NULL,
  `token` varchar(150) NOT NULL,
  `oauth_provider` varchar(100) NOT NULL,
  `oauth_uid` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `locale` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker`
--

INSERT INTO `seeker` (`id`, `email`, `username`, `password`, `summary`, `fname`, `mname`, `lname`, `address_permanent`, `address_current`, `phone_cell`, `phone_resisdance`, `gender`, `dob`, `marital_status`, `nationality`, `highest_qualification`, `faculty`, `have_work_experience`, `experience_years`, `experience_months`, `cjobposiiton`, `keyskills`, `profile_summary`, `desired_industry`, `desired_functional_area`, `desired_role`, `desired_job_type`, `desired_employment_type`, `desired_shift`, `desired_expected_salary`, `desired_job_location`, `past_employer`, `current_employer`, `profile_picture`, `facebook`, `linkedin`, `resume`, `date_created`, `date_modified`, `last_accessed`, `isActivated`, `activation_code`, `lastaccess`, `token`, `oauth_provider`, `oauth_uid`, `link`, `locale`) VALUES
(2, 'binaya619@gmail.com', 'binaya619@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, 'Binaya', '', 'shrestha', NULL, 'Bailahhen, Lalitpur, nepal', '9849748017', NULL, 'Male', '1989-05-25', 'Single', NULL, 'Masters', '', 'No', 2, NULL, 'developer', '', '', NULL, NULL, NULL, NULL, NULL, '', 77, '', 'Longtail', 'Dac', '7566company_logo.png', 'facebook.com', 'linkedin.com', '8145xerafy-dot-wedge-datasheet_cn.pdf', '2019-03-26 18:15:00', '2019-04-10 00:00:00', '0000-00-00 00:00:00', '1', '1535209236', '2019-04-10 11:06:48', '', '', '', '', ''),
(3, 'shresthasanjay1@gmail.com', 'shresthasanjay1@gmail.com', '6ebe76c9fb411be97b3b0d48b791a7c9', NULL, 'sanjay', '', 'shrestha', NULL, '1307 commonwealth ave', '9849748017', NULL, 'Male', '1936-02-01', 'Single', NULL, '0', 'bachelor', 'No', 3, NULL, 'developer', '', '', NULL, NULL, NULL, NULL, NULL, '', 192, '', '', '', '', '', '', '7402wpdatabase.txt', '2019-03-26 18:15:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '2013308506', '0000-00-00 00:00:00', '', '', '', '', ''),
(6, 'binaya_619@hotmail.com', '', NULL, NULL, 'Bnay', '', 'Shrestha', NULL, 'Bailahhen, Lalitpur, nepal', '9849748017', NULL, 'Male', '0000-00-00', 'Single', NULL, 'Bachelor', '', 'No', 4, NULL, 'developer', '', '', NULL, NULL, NULL, NULL, NULL, '', 77, '', 'Longtail', 'Dac', '', 'https://www.facebook.com/binaya619', '', '', '2019-04-09 05:21:02', '2019-04-17 00:00:00', '0000-00-00 00:00:00', '1', '', '0000-00-00 00:00:00', '', 'facebook', '10157447453035139', '', ''),
(5, 'binaya619@gmail.com', '', NULL, NULL, 'binaya', NULL, 'shrestha', NULL, NULL, NULL, NULL, 'Male', '0000-00-00', 'Single', NULL, '0', '', 'No', NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, '', 0, '', '', '', '', '', '', '', '2019-04-03 10:55:23', '2019-04-04 16:54:00', '0000-00-00 00:00:00', '1', '', '0000-00-00 00:00:00', '', 'google', '100700451091808342399', 'https://plus.google.com/+binayashresthabnay', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_education`
--

CREATE TABLE `seeker_education` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `education_program` varchar(50) DEFAULT NULL,
  `graduationyear` int(11) DEFAULT NULL,
  `instution` varchar(150) DEFAULT NULL,
  `board` varchar(150) DEFAULT NULL,
  `marks_secured_in` enum('Percentage','CGPA') NOT NULL,
  `marks_secured` varchar(50) NOT NULL,
  `graduation_month` varchar(20) NOT NULL,
  `current_studying` enum('1','0') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_education`
--

INSERT INTO `seeker_education` (`id`, `sid`, `degree`, `education_program`, `graduationyear`, `instution`, `board`, `marks_secured_in`, `marks_secured`, `graduation_month`, `current_studying`) VALUES
(21, 2, '29', 'BE Computer', 2019, 'CITE', 'Tribhuvan University', 'CGPA', '3.2', '', ''),
(20, 2, '26', 'BE Computer', 2018, '', '', 'Percentage', '72', '', '1'),
(19, 2, '25', '+2', 2016, '', '', 'Percentage', '60', '', ''),
(26, 6, '30', 'BE', 2018, 'CITE', 'Purbanchal University', 'CGPA', '3.4', 'August', '1'),
(25, 6, '24', '+2', 2007, 'AVM', 'HSEB', 'Percentage', '72', 'January', '');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_experience`
--

CREATE TABLE `seeker_experience` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `title` varchar(225) NOT NULL,
  `company` varchar(150) DEFAULT NULL,
  `location` varchar(200) NOT NULL,
  `frommonth` varchar(20) DEFAULT NULL,
  `fromyear` varchar(20) DEFAULT NULL,
  `tomonth` varchar(20) DEFAULT NULL,
  `toyear` varchar(20) DEFAULT NULL,
  `currently_working` int(11) DEFAULT NULL,
  `roles_and_responsibilities` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_experience`
--

INSERT INTO `seeker_experience` (`id`, `sid`, `position`, `title`, `company`, `location`, `frommonth`, `fromyear`, `tomonth`, `toyear`, `currently_working`, `roles_and_responsibilities`) VALUES
(3, 6, 'Entry Level', 'Developer', 'Longtail', 'Patandhoka', 'August', '2013', 'January', '2015', 1, '<p>1st and 2nd</p>');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_language`
--

CREATE TABLE `seeker_language` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `lang` varchar(50) DEFAULT NULL,
  `reading` varchar(20) DEFAULT NULL,
  `writing` varchar(20) DEFAULT NULL,
  `speaking` varchar(20) DEFAULT NULL,
  `listening` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_language`
--

INSERT INTO `seeker_language` (`id`, `sid`, `lang`, `reading`, `writing`, `speaking`, `listening`) VALUES
(3, 6, 'Nepali', 'Excellent', 'Excellent', 'Excellent', 'Bad');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_reference`
--

CREATE TABLE `seeker_reference` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `reference_name` varchar(100) DEFAULT NULL,
  `position` varchar(100) NOT NULL,
  `organization_name` varchar(100) NOT NULL,
  `mobile_number` varchar(25) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `other_number` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_reference`
--

INSERT INTO `seeker_reference` (`id`, `sid`, `reference_name`, `position`, `organization_name`, `mobile_number`, `email`, `other_number`) VALUES
(3, 6, 'Bishwas bajracharya', 'MD', 'Longtail', '987654321', 'info@longtail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `seeker_training`
--

CREATE TABLE `seeker_training` (
  `id` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `institution` varchar(100) DEFAULT NULL,
  `course` varchar(150) DEFAULT NULL,
  `frommonth` varchar(20) DEFAULT NULL,
  `fromyear` int(11) DEFAULT NULL,
  `tomonth` varchar(20) DEFAULT NULL,
  `toyear` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker_training`
--

INSERT INTO `seeker_training` (`id`, `sid`, `institution`, `course`, `frommonth`, `fromyear`, `tomonth`, `toyear`) VALUES
(5, 6, 'ABC', 'basic computer cuorse', 'April', 2006, 'July', 2006),
(6, 6, 'NIIT', 'Php course', 'September', 2012, 'December', 2012);

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblnewsletter`
--

CREATE TABLE `tblnewsletter` (
  `newsid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `newstitle` text NOT NULL,
  `newscontents` longtext NOT NULL,
  `newsdate` datetime NOT NULL,
  `newsstatus` varchar(30) NOT NULL,
  `publish` enum('1','0') DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `topbanner`
--

CREATE TABLE `topbanner` (
  `id` int(11) NOT NULL,
  `leftlink` varchar(100) NOT NULL,
  `leftimage` varchar(100) NOT NULL,
  `rightlink` varchar(100) NOT NULL,
  `rightimage` varchar(100) NOT NULL,
  `jobseeker` varchar(100) NOT NULL,
  `employer` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `modules` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `modules`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$eyQmdzZaaF.XDGqaeXp05uRka5/nx7jZg6FuYgQ376rSdhUiME/qi', '', 'masanjeev@gmail.com.np', NULL, NULL, NULL, '51YhFP6IFSi1CuCHW5Nttu', 1467791269, 1494332548, 0, 'Admin ', '', 'DAC', '', ''),
(2, '127.0.0.1', NULL, '$2y$08$O7WzYpYEa3Bm1fe4MPj11.BPDHHktjQzr.D0DgsaS3VUaL9jD.C9W', NULL, 'admin@financejobnepal.com', NULL, NULL, NULL, '5.X1scpV7hfaWS9VGYvZxO', 1494413182, 1555495320, 1, 'Roshan', 'Aacharya', 'Finance Job Nepal', '6226783', ''),
(3, '', 'user', '$2y$08$67pyVQlhZ2lnhKKURoaj.ONomY7enWAjNRyqTP9AFJTmOUjvdAwD.', NULL, 'user@financejobnepal.com', NULL, NULL, NULL, 'pcKMFoCXMxW6VG5ApcqLwu', 0, 1530687528, 1, 'Guest', '', 'Finance Job Nepal', '9841', ''),
(4, '', 'recruiter', '$2y$08$dTdJg2DIf/R7SFq.AgmhQOfXjucCV/yzxV97NMZwrSNP5hAwyurR.', NULL, 'recruiter@financejobnepal.com', NULL, NULL, NULL, 'esx33ZrGIKfdCaj9KDS2Ge', 1522035435, 1552193057, 1, 'Recruiter', '', 'Finance Job Nepal', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(94, 1, 1),
(95, 2, 1),
(96, 3, 2),
(97, 4, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dropdown`
--
ALTER TABLE `dropdown`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker`
--
ALTER TABLE `seeker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_education`
--
ALTER TABLE `seeker_education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_experience`
--
ALTER TABLE `seeker_experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_language`
--
ALTER TABLE `seeker_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_reference`
--
ALTER TABLE `seeker_reference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seeker_training`
--
ALTER TABLE `seeker_training`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblnewsletter`
--
ALTER TABLE `tblnewsletter`
  ADD PRIMARY KEY (`newsid`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topbanner`
--
ALTER TABLE `topbanner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dropdown`
--
ALTER TABLE `dropdown`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=316;

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seeker`
--
ALTER TABLE `seeker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `seeker_education`
--
ALTER TABLE `seeker_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `seeker_experience`
--
ALTER TABLE `seeker_experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seeker_language`
--
ALTER TABLE `seeker_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seeker_reference`
--
ALTER TABLE `seeker_reference`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seeker_training`
--
ALTER TABLE `seeker_training`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblnewsletter`
--
ALTER TABLE `tblnewsletter`
  MODIFY `newsid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topbanner`
--
ALTER TABLE `topbanner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
