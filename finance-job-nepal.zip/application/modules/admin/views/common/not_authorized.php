<?php
  $page='';
?>  
  <div class="login-box">
        <div style="text-align: center;font-size: 18px;padding-bottom: 9px;color: #0db142;font-weight: bold;">
          ACCESS DENIED
        </div> 
    <div class="login-box-body">
      <p class="login-box-msg" style="padding: 0px;">Sorry, you are not authorized to access this page.</p>       
    </div>
    <!-- /.login-box-body -->
  </div>
  <!-- /.login-box -->