      <div class="row">
        <div class="col-xs-12">
           
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo lang('edit_user_heading');?>
          <?php //echo lang('create_user_subheading');?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
           <!-- <div id="infoMessage"><?php echo $message;?></div> -->
            <?php if($message){ ?>
             <div class="alert alert-info alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                 <?php echo $message;?>
              </div> 
             <?php } ?> 

            <?php echo form_open(uri_string(),array('class'=>'form-horizontal'));?>

              <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label"><?php echo lang('edit_user_fname_label', 'first_name');?> </label>
                  <div class="col-sm-5">
                  <?php $first_name['class'] = "form-control";
                   echo form_input($first_name);?>
                  </div>
                </div>

                 <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label"><?php echo lang('edit_user_lname_label', 'last_name');?> </label>
                  <div class="col-sm-5">
                  <?php $last_name['class'] = "form-control";
                   echo form_input($last_name);?>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label"><?php echo lang('edit_user_company_label', 'company');?> </label>
                  <div class="col-sm-5">
                  <?php $company['class'] = "form-control";
                   echo form_input($company);?>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label"><?php echo lang('edit_user_phone_label', 'phone');?> </label>
                  <div class="col-sm-5">
                  <?php $phone['class'] = "form-control";
                   echo form_input($phone);?>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label"><?php echo lang('edit_user_password_label', 'password');?> </label>
                  <div class="col-sm-5">
                  <?php $password['class'] = "form-control";
                   echo form_input($password);?>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label"><?php echo lang('edit_user_password_confirm_label', 'password_confirm');?> </label>
                  <div class="col-sm-5">
                  <?php $password_confirm['class'] = "form-control";
                   echo form_input($password_confirm);?>
                  </div>
                </div>

                    <?php if ($this->ion_auth->is_admin()): ?>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label"><?php echo lang('edit_user_groups_heading');?></label>
                  <div class="col-sm-5">
                  <?php foreach ($groups as $group):?>
              <label class="checkbox col-sm-2 control-label">
              <?php
                  $gID=$group['id'];
                  $checked = null;
                  $item = null;
                  foreach($currentGroups as $grp) {
                      if ($gID == $grp->id) {
                          $checked= ' checked="checked"';
                          $readonly = 'disabled="disabled"';
                      break;
                      }
                  }
              ?>
              <input <?php echo $readonly;?> type="checkbox" name="groups[]" value="<?php echo $group['id'];?>"<?php echo $checked;?>>
              <?php echo htmlspecialchars($group['name'],ENT_QUOTES,'UTF-8');?>
              </label>
          <?php endforeach?>
                  </div>
                </div>
 <?php endif ?>

          

       <?php echo form_hidden('id', $user->id);?>
      <?php echo form_hidden($csrf); ?>


                
                
               
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-success">Update</button>
                <?php echo form_close();?>
              </div></div></div></div>
              <!-- /.box-footer -->
    
          

