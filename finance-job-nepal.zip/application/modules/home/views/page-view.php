<div class="col-md-9">
    <div class="normalwrap">
        <div class="normal-title">
            <h2><?php echo $title; ?></h2>
        </div>

        <div class="normal-contain">
             <p><?php echo stripslashes($content); ?></p>
        </div>
    </div>
</div>
